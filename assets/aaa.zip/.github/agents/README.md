# Agents Directory

Custom agent definitions for GitHub Copilot.

## Available Agents

### @pr-review
**Main orchestrator agent** - Coordinates comprehensive PR review

**File**: `pr-review.agent.md`

**What it does**:
- Extracts Jira ID from branch name
- Retrieves git diff with caching
- Acquires Jira requirements from user
- Spawns 3 review agents in parallel
- Aggregates and classifies findings
- Generates structured report

**Usage**: `@pr-review Review this PR`

---

### @requirement-coverage
**Requirements analyst** - Compares Jira vs implementation

**File**: `requirement-coverage.agent.md`

**What it does**:
- Extracts requirements from Jira description
- Matches requirements against code changes
- Classifies as: implemented, partial, missing
- Suggests improvements

**Usage**: `@requirement-coverage Check requirements coverage`

---

### @code-quality
**Code quality expert** - Evaluates code structure and patterns

**File**: `code-quality.agent.md`

**What it does**:
- Analyzes code structure and organization
- Identifies design pattern issues
- Evaluates test coverage
- Detects edge cases and regressions

**Usage**: `@code-quality Evaluate code quality`

---

### @business-logic
**Business analyst** - Validates business logic

**File**: `business-logic.agent.md`

**What it does**:
- Identifies missing business edge cases
- Validates implicit assumptions
- Detects logical gaps
- Analyzes user flow issues

**Usage**: `@business-logic Validate business logic`

---

### @fix-planning
**Fix planner** - Generates step-by-step resolution plan

**File**: `fix-planning.agent.md`

**What it does**:
- Prioritizes fixes by severity
- Identifies dependencies between fixes
- Estimates effort for each fix
- Creates actionable step-by-step plan

**Usage**: Handoff from @pr-review after review completion

---

### @fix-implementation
**Fix implementer** - Automatically implements fixes

**File**: `fix-implementation.agent.md`

**What it does**:
- Generates code fixes for identified issues
- Presents changes for user approval
- Applies approved changes
- Runs tests to verify fixes
- Creates commits

**Usage**: Handoff from @pr-review after review completion

---

## Agent Architecture

```
@pr-review (Orchestrator)
    ├── Uses: branch-parser skill
    ├── Uses: diff-retriever skill
    ├── Uses: jira-context skill
    ├── Spawns: @requirement-coverage
    ├── Spawns: @code-quality
    ├── Spawns: @business-logic
    ├── Uses: aggregator skill
    └── Handoffs:
        ├── @fix-planning (generate resolution plan)
        └── @fix-implementation (auto-implement fixes)
```

## Creating New Agents

1. Create `your-agent.agent.md` in this directory
2. Add YAML frontmatter:
```yaml
---
name: your-agent
description: What your agent does
persona: Role of the agent
---
```
3. Write agent instructions and behavior
4. Reference from other agents if needed

## Agent Format

Each agent file follows this structure:

1. **YAML Frontmatter** - Metadata and configuration
2. **Role Description** - What the agent does
3. **Input/Output** - Expected data format
4. **Process** - Step-by-step logic
5. **Examples** - Usage examples

See existing agents for templates.
