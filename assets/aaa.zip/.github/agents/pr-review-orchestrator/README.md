# PR Review Orchestrator Agent

> Production-grade multi-agent system for comprehensive PR code review

## Overview

The PR Review Orchestrator Agent is a sophisticated multi-agent system that performs comprehensive code reviews by coordinating specialized review agents. It analyzes code changes against business requirements, evaluates code quality, and validates business logic.

## Architecture

```
PRReviewAgent (Main Agent)
├── Orchestrator Core
│   ├── Context Acquisition Phase
│   │   ├── Branch Parser Skill
│   │   ├── Diff Retriever Skill (with caching)
│   │   └── Jira Context Skill
│   │
│   ├── Review Phase (Parallel Execution)
│   │   ├── Requirement Coverage Agent
│   │   ├── Code Quality Agent
│   │   └── Business Logic Agent
│   │
│   └── Aggregation & Reporting Phase
│       ├── Aggregator
│       └── Report Generator
│
└── Utilities
    ├── Logger
    ├── Cache Manager
    └── Config Manager
```

## Features

✅ **Multi-Agent Orchestration**: Coordinates 3 specialized review agents in parallel
✅ **Intelligent Caching**: SHA256-keyed filesystem cache for git diffs  
✅ **Deterministic Output**: Structured JSON reports with TypeScript types  
✅ **Severity Classification**: Critical / NotImplemented / NiceToFix  
✅ **Comprehensive Analysis**: Requirements, code quality, business logic  
✅ **Production-Ready**: Error handling, logging, configuration management  

## Installation

```bash
# Install dependencies
cd agents/pr-review-orchestrator
npm install

# Build TypeScript
npm run build
```

## Usage

### As a Node Module

```typescript
import { createPRReviewAgent } from './agents/pr-review-orchestrator/agent';

// Create agent instance
const agent = createPRReviewAgent({
  repoPath: process.cwd(),
  baseBranch: 'main',
  cacheEnabled: true,
});

// Execute review
const report = await agent.execute({
  repoPath: '/path/to/repo',
  baseBranch: 'main',
  skipCache: false,
});

if (report) {
  console.log(`Review complete: ${report.summary.totalFindings} findings`);
  
  // Access structured findings
  report.findings.critical.forEach(finding => {
    console.log(`Critical: ${finding.description}`);
  });
}
```

### As a CLI Tool

```bash
# Run from command line
node agents/pr-review-orchestrator/agent.js

# Or add to package.json scripts:
npm run pr-review
```

### Configuration

Configure via constructor or environment variables:

```typescript
const agent = createPRReviewAgent({
  repoPath: '/path/to/repo',
  baseBranch: 'main',
  cacheEnabled: true,
  cacheDir: '.copilot/cache/pr-review',
  logsDir: '.copilot/logs/pr-review',
  reportsDir: '.copilot/reports',
  timeout: 30000,
  logging: {
    level: 'info',
    enableConsole: true,
    enableFile: true,
  },
  jira: {
    baseUrl: process.env.JIRA_BASE_URL,
    authToken: process.env.JIRA_AUTH_TOKEN,
    projectKey: process.env.JIRA_PROJECT_KEY,
  },
});
```

### Environment Variables

```bash
# Optional Jira API integration
JIRA_BASE_URL=https://your-domain.atlassian.net
JIRA_AUTH_TOKEN=your-api-token
JIRA_PROJECT_KEY=C1234
```

## Components

### Core Agents

#### 1. Requirement Coverage Agent
Analyzes code changes against Jira requirements:
- Extracts requirements from Jira description
- Matches requirements to code implementation
- Classifies as: Implemented / Partial / Missing
- Suggests improvements

#### 2. Code Quality Agent
Evaluates code structure and patterns:
- Code structure analysis
- Design pattern compliance
- Test coverage assessment
- Regression detection
- Anti-pattern identification

#### 3. Business Logic Agent
Validates from business perspective:
- Edge case identification
- Assumption validation
- Logical gap detection
- User flow analysis

### Skills

#### Branch Parser
Extracts Jira ID from branch names:
- Supports: `feature/C1234-43224-desc`, `bug/PROJ-123-fix`
- Fallback: Prompts user for Jira ID

#### Diff Retriever
Retrieves git diff with caching:
- Cache key: SHA256(repo + branch + jiraId + commit)
- Cache hit: <5ms, miss: <500ms
- Automatic invalidation on new commits

#### Jira Context Acquirer
Acquires Jira issue description:
- Current: User prompt (multiline input)
- Future: Jira REST API integration ready

### Utilities

#### Cache Manager
Filesystem-based caching:
- Location: `.copilot/cache/pr-review/`
- Format: JSON
- Automatic pruning and cleanup

#### Logger
Structured logging system:
- Levels: debug, info, warn, error
- Console + file output
- Location: `.copilot/logs/pr-review/`

#### Report Generator
Generates final review reports:
- Console formatted output
- JSON file export
- Location: `.copilot/reports/`

## Output Format

### Console Output

```
======================================================================
📊 PR REVIEW REPORT
======================================================================

🏷️  Jira: C1234-43224
🌿 Branch: feature/C1234-43224-add-authentication
⏱️  Duration: 12.5s

📈 SUMMARY
   Total Findings: 8
   🔴 Critical: 2
   🟡 Not Implemented: 3
   🔵 Nice to Fix: 3
   📁 Files Analyzed: 5
   ✅ Test Coverage: partial

🔴 CRITICAL ISSUES
   1. No null check before accessing user.email property
      File: src/auth/Login.tsx:45
      → Add optional chaining: user.email?.

💡 NEXT ACTIONS
   1. Create Plan to Fix Below Issues
   2. Implement Below Issues in Agent Mode
======================================================================
```

### JSON Output

```json
{
  "metadata": {
    "branchName": "feature/C1234-43224-add-auth",
    "jiraId": "C1234-43224",
    "timestamp": "2026-04-08T14:39:00Z",
    "reviewDuration": "12.5s",
    "reportPath": ".copilot/reports/pr-review-C1234-43224-1234567890.json"
  },
  "findings": {
    "critical": [...],
    "notImplemented": [...],
    "niceToFix": [...]
  },
  "summary": {
    "totalFindings": 8,
    "criticalCount": 2,
    "notImplementedCount": 3,
    "niceToFixCount": 3,
    "filesAnalyzed": 5,
    "testCoverage": "partial"
  },
  "actions": [...]
}
```

## Performance

- **Total execution**: <20s (typical PR)
- **Context acquisition**: <1s (with cache)
- **Parallel review**: <15s (3 agents)
- **Aggregation**: <100ms
- **Report generation**: <50ms

## API

### PRReviewAgent

#### Methods

**`async execute(options): Promise<ReviewReport | null>`**
- Main execution method
- Returns: Structured review report or null on failure

**`getMetadata(): AgentMetadata`**
- Returns agent information and configuration

**`async healthCheck(): Promise<boolean>`**
- Checks if required dependencies are available

#### Factory

**`createPRReviewAgent(config?): PRReviewAgent`**
- Factory function for creating agent instances

## Error Handling

The agent includes comprehensive error handling:

| Error Scenario | Behavior |
|----------------|----------|
| Jira ID not found | Prompt user for manual input |
| Empty git diff | Stop with explanation |
| Missing Jira description | Block until provided |
| Agent timeout | Continue with partial results + warning |
| Cache corruption | Clear cache + regenerate |

## Extending the Agent

### Adding a New Review Agent

1. Create agent directory:
```bash
mkdir agents/pr-review-orchestrator/agents/my-new-agent
```

2. Implement agent class:
```typescript
// agents/my-new-agent/agent.ts
import type { SharedContext } from '../../types';
import type { Logger } from '../../utils/logger';

export class MyNewAgent {
  constructor(private logger: Logger) {}

  async analyze(context: SharedContext): Promise<MyReport> {
    // Your analysis logic
    return { findings: [] };
  }
}
```

3. Add to orchestrator:
```typescript
// core/orchestrator.ts
import { MyNewAgent } from '../agents/my-new-agent/agent';

// In executeReviewAgents method:
const myNewReport = await this.executeMyNewAgent(context);
```

### Adding a New Skill

Skills are utility functions for context acquisition:

```typescript
// skills/my-skill.ts
import type { AgentResult } from '../types';
import type { Logger } from '../utils/logger';

export class MySkill {
  constructor(private logger: Logger) {}

  async execute(input: any): Promise<AgentResult<MyResult>> {
    // Skill logic
    return {
      success: true,
      data: { ... },
      metadata: { ... },
    };
  }
}
```

## Testing

```bash
# Run tests
npm test

# Run specific test suite
npm test -- agents/requirement-coverage

# Integration test
npm run test:integration
```

## Troubleshooting

### "Could not extract Jira ID from branch"
- Ensure branch follows: `{type}/{CODE}-{ID}-{desc}`
- Or provide Jira ID when prompted

### "Empty git diff"
- Ensure commits exist on branch
- Check base branch is correct

### "Agent timeout"
- Increase timeout in config
- Check for very large diffs

## Contributing

1. Follow TypeScript strict mode
2. Add comprehensive types
3. Include error handling
4. Write unit tests
5. Update documentation

## License

MIT

## Related Documentation

- [Architecture Details](./ARCHITECTURE.md) (coming soon)
- [API Reference](./API.md) (coming soon)
- [Development Guide](./DEVELOPMENT.md) (coming soon)

---

**Built for production | Type-safe | Extensible**
