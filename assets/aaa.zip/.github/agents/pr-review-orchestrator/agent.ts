/**
 * PR Review Orchestrator Agent
 *
 * Main entry point for the PR review orchestration agent.
 * This agent coordinates multiple specialized review agents to perform
 * comprehensive code review based on git diffs and Jira requirements.
 */

import { OrchestratorCore } from './core/orchestrator';
import { AgentConfig, ReviewReport } from './types';
import { Logger } from './utils/logger';
import { ConfigManager } from './config/config-manager';

export class PRReviewAgent {
  private orchestrator: OrchestratorCore;
  private logger: Logger;
  private config: AgentConfig;

  constructor(config?: Partial<AgentConfig>) {
    this.config = ConfigManager.load(config);
    this.logger = new Logger(this.config.logging);
    this.orchestrator = new OrchestratorCore(this.config, this.logger);
  }

  /**
   * Main agent execution method
   *
   * @param options - Optional execution parameters
   * @returns ReviewReport - Structured review findings
   */
  async execute(options: {
    repoPath?: string;
    baseBranch?: string;
    skipCache?: boolean;
  } = {}): Promise<ReviewReport | null> {
    this.logger.info('PR Review Agent starting...');

    try {
      const report = await this.orchestrator.orchestrate({
        repoPath: options.repoPath || process.cwd(),
        baseBranch: options.baseBranch || 'main',
        skipCache: options.skipCache || false,
      });

      if (report) {
        this.logger.info('PR Review Agent completed successfully');
        return report;
      } else {
        this.logger.error('PR Review Agent failed to generate report');
        return null;
      }
    } catch (error) {
      this.logger.error('PR Review Agent encountered an error', error);
      return null;
    }
  }

  /**
   * Get agent metadata
   */
  getMetadata() {
    return {
      name: 'PR Review Orchestrator Agent',
      version: '1.0.0',
      description: 'Multi-agent system for comprehensive PR review',
      capabilities: [
        'Branch parsing and Jira ID extraction',
        'Git diff retrieval with caching',
        'Requirement coverage analysis',
        'Code quality assessment',
        'Business logic validation',
        'Severity classification',
        'Fix planning and implementation',
      ],
      config: this.config,
    };
  }

  /**
   * Health check
   */
  async healthCheck(): Promise<boolean> {
    try {
      // Check if git is available
      const { execSync } = require('child_process');
      execSync('git --version', { stdio: 'ignore' });
      return true;
    } catch {
      return false;
    }
  }
}

/**
 * Factory function for creating agent instances
 */
export function createPRReviewAgent(config?: Partial<AgentConfig>): PRReviewAgent {
  return new PRReviewAgent(config);
}

/**
 * CLI entry point
 */
export async function runCLI() {
  const agent = createPRReviewAgent();

  console.log('\n' + '='.repeat(70));
  console.log('🤖 PR Review Orchestrator Agent');
  console.log('='.repeat(70) + '\n');

  const report = await agent.execute();

  if (report) {
    console.log('\n✅ Review completed successfully!');
    console.log(`📊 Report saved to: ${report.metadata.reportPath || 'output'}`);
    process.exit(0);
  } else {
    console.log('\n❌ Review failed. Check logs for details.');
    process.exit(1);
  }
}

// Run CLI if executed directly
if (require.main === module) {
  runCLI().catch((error) => {
    console.error('Fatal error:', error);
    process.exit(1);
  });
}

export default PRReviewAgent;
