/**
 * Filesystem-based Cache Manager
 *
 * Provides caching for git diffs to avoid recomputation when commits haven't changed.
 * Cache key: {repo}-{branch}-{jiraId}-{lastCommitHash}
 */

import * as fs from 'fs/promises';
import * as path from 'path';
import * as crypto from 'crypto';

export interface CacheEntry {
  diff: string;
  changedFiles: string[];
  timestamp: string;
  commitHash: string;
  stats: {
    additions: number;
    deletions: number;
    filesChanged: number;
  };
}

export interface CacheConfig {
  cacheDir: string;
  ttl?: number; // Time to live in milliseconds (default: no expiry)
  maxSize?: number; // Max cache size in MB (default: 100MB)
}

export class CacheManager {
  private config: CacheConfig;
  private cacheDir: string;

  constructor(config: Partial<CacheConfig> = {}) {
    this.config = {
      cacheDir: config.cacheDir || '.copilot/cache/pr-review',
      ttl: config.ttl,
      maxSize: config.maxSize || 100,
    };
    this.cacheDir = this.config.cacheDir;
  }

  /**
   * Initialize cache directory
   */
  async initialize(): Promise<void> {
    try {
      await fs.mkdir(this.cacheDir, { recursive: true });
    } catch (error) {
      throw new Error(`Failed to initialize cache directory: ${error}`);
    }
  }

  /**
   * Generate cache key from context
   */
  generateCacheKey(params: {
    repo: string;
    branch: string;
    jiraId: string;
    commitHash: string;
  }): string {
    const data = `${params.repo}-${params.branch}-${params.jiraId}-${params.commitHash}`;
    return crypto.createHash('sha256').update(data).digest('hex');
  }

  /**
   * Get cached entry
   */
  async get(cacheKey: string): Promise<CacheEntry | null> {
    const filePath = path.join(this.cacheDir, `${cacheKey}.json`);

    try {
      const data = await fs.readFile(filePath, 'utf-8');
      const entry: CacheEntry = JSON.parse(data);

      // Check TTL if configured
      if (this.config.ttl) {
        const age = Date.now() - new Date(entry.timestamp).getTime();
        if (age > this.config.ttl) {
          await this.delete(cacheKey);
          return null;
        }
      }

      return entry;
    } catch (error) {
      if ((error as any).code === 'ENOENT') {
        return null; // Cache miss
      }
      // Cache corruption - delete and return null
      await this.delete(cacheKey).catch(() => {});
      return null;
    }
  }

  /**
   * Set cache entry
   */
  async set(cacheKey: string, entry: CacheEntry): Promise<void> {
    const filePath = path.join(this.cacheDir, `${cacheKey}.json`);

    try {
      await fs.writeFile(filePath, JSON.stringify(entry, null, 2), 'utf-8');
    } catch (error) {
      throw new Error(`Failed to write cache entry: ${error}`);
    }
  }

  /**
   * Delete cache entry
   */
  async delete(cacheKey: string): Promise<void> {
    const filePath = path.join(this.cacheDir, `${cacheKey}.json`);
    try {
      await fs.unlink(filePath);
    } catch (error) {
      // Ignore if file doesn't exist
      if ((error as any).code !== 'ENOENT') {
        throw error;
      }
    }
  }

  /**
   * Clear all cache entries
   */
  async clear(): Promise<void> {
    try {
      const files = await fs.readdir(this.cacheDir);
      await Promise.all(
        files
          .filter((file) => file.endsWith('.json'))
          .map((file) => fs.unlink(path.join(this.cacheDir, file)))
      );
    } catch (error) {
      throw new Error(`Failed to clear cache: ${error}`);
    }
  }

  /**
   * Get cache statistics
   */
  async getStats(): Promise<{
    totalEntries: number;
    totalSize: number; // in bytes
    oldestEntry: string | null;
    newestEntry: string | null;
  }> {
    try {
      const files = await fs.readdir(this.cacheDir);
      const jsonFiles = files.filter((file) => file.endsWith('.json'));

      if (jsonFiles.length === 0) {
        return {
          totalEntries: 0,
          totalSize: 0,
          oldestEntry: null,
          newestEntry: null,
        };
      }

      let totalSize = 0;
      let oldest: Date | null = null;
      let newest: Date | null = null;

      for (const file of jsonFiles) {
        const filePath = path.join(this.cacheDir, file);
        const stats = await fs.stat(filePath);
        totalSize += stats.size;

        if (!oldest || stats.mtime < oldest) {
          oldest = stats.mtime;
        }
        if (!newest || stats.mtime > newest) {
          newest = stats.mtime;
        }
      }

      return {
        totalEntries: jsonFiles.length,
        totalSize,
        oldestEntry: oldest?.toISOString() || null,
        newestEntry: newest?.toISOString() || null,
      };
    } catch (error) {
      throw new Error(`Failed to get cache stats: ${error}`);
    }
  }

  /**
   * Prune cache based on size or age
   */
  async prune(): Promise<{ deletedCount: number }> {
    const stats = await this.getStats();
    const maxSizeBytes = this.config.maxSize! * 1024 * 1024; // Convert MB to bytes

    if (stats.totalSize <= maxSizeBytes) {
      return { deletedCount: 0 };
    }

    // Delete oldest entries until under max size
    const files = await fs.readdir(this.cacheDir);
    const jsonFiles = files.filter((file) => file.endsWith('.json'));

    // Get file stats with paths
    const fileStats = await Promise.all(
      jsonFiles.map(async (file) => {
        const filePath = path.join(this.cacheDir, file);
        const stat = await fs.stat(filePath);
        return { path: filePath, mtime: stat.mtime, size: stat.size };
      })
    );

    // Sort by modification time (oldest first)
    fileStats.sort((a, b) => a.mtime.getTime() - b.mtime.getTime());

    let currentSize = stats.totalSize;
    let deletedCount = 0;

    for (const file of fileStats) {
      if (currentSize <= maxSizeBytes) {
        break;
      }

      await fs.unlink(file.path);
      currentSize -= file.size;
      deletedCount++;
    }

    return { deletedCount };
  }
}

/**
 * Singleton cache manager instance
 */
export const defaultCacheManager = new CacheManager();
