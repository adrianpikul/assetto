/**
 * Observability Logger
 *
 * Provides structured logging for orchestrator execution.
 * Logs stored in .copilot/logs/pr-review/{timestamp}.json
 */

import * as fs from 'fs/promises';
import * as path from 'path';
import type { LogEntry } from '../types/shared-context';

export interface LoggerConfig {
  logDir: string;
  enableConsole: boolean;
  enableFile: boolean;
}

export class Logger {
  private config: LoggerConfig;
  private logDir: string;
  private sessionId: string;
  private sessionLogs: LogEntry[] = [];

  constructor(config: Partial<LoggerConfig> = {}) {
    this.config = {
      logDir: config.logDir || '.copilot/logs/pr-review',
      enableConsole: config.enableConsole ?? true,
      enableFile: config.enableFile ?? true,
    };
    this.logDir = this.config.logDir;
    this.sessionId = new Date().toISOString().replace(/[:.]/g, '-');
  }

  /**
   * Initialize logging directory
   */
  async initialize(): Promise<void> {
    if (this.config.enableFile) {
      try {
        await fs.mkdir(this.logDir, { recursive: true });
      } catch (error) {
        console.error(`Failed to initialize log directory: ${error}`);
      }
    }
  }

  /**
   * Log skill execution
   */
  skill(
    skillName: string,
    event: 'start' | 'complete' | 'error',
    data?: any
  ): void {
    this.log({
      timestamp: new Date().toISOString(),
      phase: 'skill',
      component: skillName,
      event,
      message: `Skill ${skillName} ${event}`,
      data,
    });
  }

  /**
   * Log agent execution
   */
  agent(
    agentName: string,
    event: 'start' | 'complete' | 'error',
    data?: any
  ): void {
    this.log({
      timestamp: new Date().toISOString(),
      phase: 'agent',
      component: agentName,
      event,
      message: `Agent ${agentName} ${event}`,
      data,
    });
  }

  /**
   * Log aggregation step
   */
  aggregation(event: 'start' | 'complete' | 'error', data?: any): void {
    this.log({
      timestamp: new Date().toISOString(),
      phase: 'aggregation',
      component: 'aggregation-layer',
      event,
      message: `Aggregation ${event}`,
      data,
    });
  }

  /**
   * Log orchestration event
   */
  orchestration(
    message: string,
    event: 'start' | 'complete' | 'error',
    data?: any
  ): void {
    this.log({
      timestamp: new Date().toISOString(),
      phase: 'orchestration',
      component: 'orchestrator',
      event,
      message,
      data,
    });
  }

  /**
   * Generic log method
   */
  log(entry: LogEntry): void {
    this.sessionLogs.push(entry);

    if (this.config.enableConsole) {
      const color = entry.event === 'error' ? '\x1b[31m' : '\x1b[36m';
      const reset = '\x1b[0m';
      console.log(
        `${color}[${entry.phase}:${entry.component}]${reset} ${entry.message}`
      );
      if (entry.data && entry.event === 'error') {
        console.error(entry.data);
      }
    }
  }

  /**
   * Persist logs to file
   */
  async flush(): Promise<void> {
    if (!this.config.enableFile || this.sessionLogs.length === 0) {
      return;
    }

    const logFile = path.join(this.logDir, `${this.sessionId}.json`);

    try {
      await fs.writeFile(
        logFile,
        JSON.stringify(
          {
            sessionId: this.sessionId,
            startTime: this.sessionLogs[0]?.timestamp,
            endTime: this.sessionLogs[this.sessionLogs.length - 1]?.timestamp,
            totalEntries: this.sessionLogs.length,
            logs: this.sessionLogs,
          },
          null,
          2
        ),
        'utf-8'
      );
    } catch (error) {
      console.error(`Failed to write log file: ${error}`);
    }
  }

  /**
   * Get all logs for current session
   */
  getLogs(): LogEntry[] {
    return [...this.sessionLogs];
  }

  /**
   * Get error logs only
   */
  getErrors(): LogEntry[] {
    return this.sessionLogs.filter((log) => log.event === 'error');
  }

  /**
   * Get execution summary
   */
  getSummary(): {
    totalLogs: number;
    errors: number;
    skills: number;
    agents: number;
    duration: number; // milliseconds
  } {
    const errors = this.getErrors().length;
    const skills = this.sessionLogs.filter((log) => log.phase === 'skill')
      .length;
    const agents = this.sessionLogs.filter((log) => log.phase === 'agent')
      .length;

    const startTime = this.sessionLogs[0]
      ? new Date(this.sessionLogs[0].timestamp).getTime()
      : Date.now();
    const endTime = this.sessionLogs[this.sessionLogs.length - 1]
      ? new Date(
          this.sessionLogs[this.sessionLogs.length - 1].timestamp
        ).getTime()
      : Date.now();

    return {
      totalLogs: this.sessionLogs.length,
      errors,
      skills,
      agents,
      duration: endTime - startTime,
    };
  }
}

/**
 * Default logger instance
 */
export const defaultLogger = new Logger();
