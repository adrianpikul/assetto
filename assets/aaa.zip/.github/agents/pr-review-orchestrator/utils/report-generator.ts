/**
 * Report Generator
 * Generates final review report with formatting
 */

import * as fs from 'fs/promises';
import * as path from 'path';
import type {
  AgentConfig,
  SharedContext,
  ReviewReport,
  CategorizedFindings,
  ReviewMetadata,
  ReviewSummary,
} from '../types';
import type { Logger } from './logger';

export class ReportGenerator {
  constructor(
    private config: AgentConfig,
    private logger: Logger
  ) {}

  async generate(
    context: SharedContext,
    findings: CategorizedFindings,
    startTime: number
  ): Promise<ReviewReport> {
    const duration = ((Date.now() - startTime) / 1000).toFixed(1);

    const metadata: ReviewMetadata = {
      branchName: context.branchName,
      jiraId: context.jiraId,
      timestamp: new Date().toISOString(),
      reviewDuration: `${duration}s`,
    };

    const summary: ReviewSummary = {
      totalFindings:
        findings.critical.length +
        findings.notImplemented.length +
        findings.niceToFix.length,
      criticalCount: findings.critical.length,
      notImplementedCount: findings.notImplemented.length,
      niceToFixCount: findings.niceToFix.length,
      filesAnalyzed: context.changedFiles.length,
      testCoverage: this.assessTestCoverage(context),
    };

    const report: ReviewReport = {
      metadata,
      findings,
      summary,
      actions: [
        {
          id: 'fix-planning',
          label: 'Create Plan to Fix Below Issues',
          description: 'Generate step-by-step resolution plan',
        },
        {
          id: 'fix-implementation',
          label: 'Implement Below Issues in Agent Mode',
          description: 'Apply code changes automatically',
        },
      ],
      context,
    };

    // Save report to file
    await this.saveReport(report);

    // Display console report
    this.displayConsoleReport(report);

    return report;
  }

  private assessTestCoverage(context: SharedContext): 'none' | 'partial' | 'good' {
    const testFiles = context.changedFiles.filter((f) =>
      f.includes('.test.') || f.includes('.spec.') || f.includes('__tests__')
    );

    if (testFiles.length === 0) return 'none';
    if (testFiles.length < context.changedFiles.length / 2) return 'partial';
    return 'good';
  }

  private async saveReport(report: ReviewReport): Promise<void> {
    try {
      await fs.mkdir(this.config.reportsDir, { recursive: true });

      const filename = `pr-review-${report.metadata.jiraId}-${Date.now()}.json`;
      const filepath = path.join(this.config.reportsDir, filename);

      await fs.writeFile(filepath, JSON.stringify(report, null, 2), 'utf-8');

      report.metadata.reportPath = filepath;
      this.logger.info(`Report saved to: ${filepath}`);
    } catch (error) {
      this.logger.error('Failed to save report', error);
    }
  }

  private displayConsoleReport(report: ReviewReport): void {
    console.log('\n' + '='.repeat(70));
    console.log('📊 PR REVIEW REPORT');
    console.log('='.repeat(70));
    console.log(`\n🏷️  Jira: ${report.metadata.jiraId}`);
    console.log(`🌿 Branch: ${report.metadata.branchName}`);
    console.log(`⏱️  Duration: ${report.metadata.reviewDuration}`);

    console.log('\n📈 SUMMARY');
    console.log(`   Total Findings: ${report.summary.totalFindings}`);
    console.log(`   🔴 Critical: ${report.summary.criticalCount}`);
    console.log(`   🟡 Not Implemented: ${report.summary.notImplementedCount}`);
    console.log(`   🔵 Nice to Fix: ${report.summary.niceToFixCount}`);
    console.log(`   📁 Files Analyzed: ${report.summary.filesAnalyzed}`);
    console.log(`   ✅ Test Coverage: ${report.summary.testCoverage}`);

    if (report.findings.critical.length > 0) {
      console.log('\n🔴 CRITICAL ISSUES');
      report.findings.critical.forEach((f, i) => {
        console.log(`   ${i + 1}. ${f.description}`);
        if (f.file) console.log(`      File: ${f.file}${f.line ? `:${f.line}` : ''}`);
        if (f.recommendation) console.log(`      → ${f.recommendation}`);
      });
    }

    if (report.findings.notImplemented.length > 0) {
      console.log('\n🟡 NOT IMPLEMENTED');
      report.findings.notImplemented.forEach((f, i) => {
        console.log(`   ${i + 1}. ${f.description}`);
        if (f.recommendation) console.log(`      → ${f.recommendation}`);
      });
    }

    console.log('\n💡 NEXT ACTIONS');
    report.actions.forEach((action, i) => {
      console.log(`   ${i + 1}. ${action.label}`);
      console.log(`      ${action.description}`);
    });

    console.log('\n' + '='.repeat(70));
    console.log(`Full report saved to: ${report.metadata.reportPath || this.config.reportsDir}`);
    console.log('='.repeat(70) + '\n');
  }
}
