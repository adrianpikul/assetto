/**
 * Diff Retriever Skill
 * Retrieves git diff with caching
 */

import { execSync } from 'child_process';
import type {
  AgentResult,
  DiffRetrievalResult,
  AgentError,
  AgentConfig,
} from '../types';
import type { Logger } from '../utils/logger';
import { CacheManager } from '../utils/cache-manager';

export class DiffRetriever {
  private cacheManager: CacheManager;

  constructor(
    private config: AgentConfig,
    private logger: Logger
  ) {
    this.cacheManager = new CacheManager({
      cacheDir: config.cacheDir,
    });
  }

  async retrieve(input: {
    jiraId: string;
    branchName: string;
    baseBranch: string;
    repoPath: string;
    skipCache?: boolean;
  }): Promise<AgentResult<DiffRetrievalResult>> {
    const startTime = Date.now();

    try {
      await this.cacheManager.initialize();

      const commitHash = execSync('git rev-parse HEAD', {
        cwd: input.repoPath,
        encoding: 'utf-8',
      }).trim();

      // Check cache unless skipped
      if (!input.skipCache) {
        const cacheKey = this.cacheManager.generateCacheKey({
          repo: input.repoPath.split('/').pop() || 'repo',
          branch: input.branchName,
          jiraId: input.jiraId,
          commitHash,
        });

        const cached = await this.cacheManager.get(cacheKey);
        if (cached) {
          this.logger.debug('[diff-retriever] Cache hit');
          return {
            success: true,
            data: {
              diff: cached.diff,
              changedFiles: cached.changedFiles,
              cacheHit: true,
              commitHash: cached.commitHash,
              stats: cached.stats,
            },
            metadata: {
              agentName: 'diff-retriever',
              executionTime: Date.now() - startTime,
              timestamp: new Date().toISOString(),
            },
          };
        }
      }

      // Cache miss or skipped - retrieve from git
      this.logger.debug('[diff-retriever] Retrieving from git');
      const baseCommit = execSync(`git merge-base HEAD origin/${input.baseBranch}`, {
        cwd: input.repoPath,
        encoding: 'utf-8',
      }).trim();

      const diff = execSync(`git diff ${baseCommit}..HEAD`, {
        cwd: input.repoPath,
        encoding: 'utf-8',
        maxBuffer: 10 * 1024 * 1024,
      });

      const changedFiles = execSync(`git diff --name-only ${baseCommit}..HEAD`, {
        cwd: input.repoPath,
        encoding: 'utf-8',
      })
        .trim()
        .split('\n')
        .filter((f) => f.length > 0);

      const statsOutput = execSync(`git diff --shortstat ${baseCommit}..HEAD`, {
        cwd: input.repoPath,
        encoding: 'utf-8',
      });

      const stats = this.parseDiffStats(statsOutput);

      const result: DiffRetrievalResult = {
        diff,
        changedFiles,
        cacheHit: false,
        commitHash,
        stats,
      };

      // Cache the result if caching is enabled
      if (!input.skipCache) {
        const cacheKey = this.cacheManager.generateCacheKey({
          repo: input.repoPath.split('/').pop() || 'repo',
          branch: input.branchName,
          jiraId: input.jiraId,
          commitHash,
        });

        await this.cacheManager.set(cacheKey, {
          diff,
          changedFiles,
          timestamp: new Date().toISOString(),
          commitHash,
          stats,
        });
      }

      return {
        success: true,
        data: result,
        metadata: {
          agentName: 'diff-retriever',
          executionTime: Date.now() - startTime,
          timestamp: new Date().toISOString(),
        },
      };
    } catch (error) {
      const agentError: AgentError = {
        code: 'DIFF_RETRIEVAL_ERROR',
        message: `Failed to retrieve diff: ${error}`,
        recoverable: false,
      };

      return {
        success: false,
        error: agentError,
        metadata: {
          agentName: 'diff-retriever',
          executionTime: Date.now() - startTime,
          timestamp: new Date().toISOString(),
        },
      };
    }
  }

  private parseDiffStats(statsOutput: string): {
    additions: number;
    deletions: number;
    filesChanged: number;
  } {
    const match = statsOutput.match(
      /(\d+) files? changed(?:, (\d+) insertions?\(\+\))?(?:, (\d+) deletions?\(-\))?/
    );

    if (!match) {
      return { additions: 0, deletions: 0, filesChanged: 0 };
    }

    return {
      filesChanged: parseInt(match[1] || '0', 10),
      additions: parseInt(match[2] || '0', 10),
      deletions: parseInt(match[3] || '0', 10),
    };
  }
}
