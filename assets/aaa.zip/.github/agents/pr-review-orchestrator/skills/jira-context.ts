/**
 * Jira Context Acquirer Skill
 * Acquires Jira issue description (user prompt + API-ready)
 */

import * as readline from 'readline';
import type {
  AgentResult,
  JiraContextResult,
  AgentError,
  AgentConfig,
} from '../types';
import type { Logger } from '../utils/logger';

export class JiraContextAcquirer {
  constructor(
    private config: AgentConfig,
    private logger: Logger
  ) {}

  async acquire(input: {
    jiraId: string;
  }): Promise<AgentResult<JiraContextResult>> {
    const startTime = Date.now();

    try {
      // Future: Try Jira API if configured
      // if (this.config.jira?.baseUrl) {
      //   const apiResult = await this.fetchFromAPI(input.jiraId);
      //   if (apiResult) return apiResult;
      // }

      // Current: User prompt
      const description = await this.promptUser(input.jiraId);

      if (!description || description.trim().length === 0) {
        const error: AgentError = {
          code: 'EMPTY_JIRA_DESCRIPTION',
          message: `Jira description cannot be empty for ${input.jiraId}`,
          recoverable: true,
        };

        return {
          success: false,
          error,
          metadata: {
            agentName: 'jira-context',
            executionTime: Date.now() - startTime,
            timestamp: new Date().toISOString(),
          },
        };
      }

      return {
        success: true,
        data: {
          jiraId: input.jiraId,
          description,
          source: 'user-input',
        },
        metadata: {
          agentName: 'jira-context',
          executionTime: Date.now() - startTime,
          timestamp: new Date().toISOString(),
        },
      };
    } catch (error) {
      const agentError: AgentError = {
        code: 'JIRA_CONTEXT_ERROR',
        message: `Failed to acquire Jira context: ${error}`,
        recoverable: false,
      };

      return {
        success: false,
        error: agentError,
        metadata: {
          agentName: 'jira-context',
          executionTime: Date.now() - startTime,
          timestamp: new Date().toISOString(),
        },
      };
    }
  }

  private async promptUser(jiraId: string): Promise<string> {
    console.log(`\n${'='.repeat(60)}`);
    console.log(`📋 Jira Context Required: ${jiraId}`);
    console.log(`${'='.repeat(60)}`);
    console.log('Please provide the Jira issue description/requirements below.');
    console.log('(Enter a blank line when done)\n');

    const rl = readline.createInterface({
      input: process.stdin,
      output: process.stdout,
    });

    const lines: string[] = [];

    return new Promise((resolve) => {
      rl.on('line', (line) => {
        if (line.trim() === '' && lines.length > 0) {
          rl.close();
          resolve(lines.join('\n'));
        } else {
          lines.push(line);
        }
      });

      rl.on('close', () => {
        if (lines.length > 0) {
          resolve(lines.join('\n'));
        } else {
          resolve('');
        }
      });
    });
  }
}
