/**
 * Git Branch Parser Implementation
 *
 * Extracts project code and Jira ID from branch names.
 */

import type {
  BranchParseResult,
  SkillResult,
  SkillError,
} from '../../../../src/agents/types/shared-context';

/**
 * Regex patterns for branch name parsing
 */
const BRANCH_PATTERNS = [
  // With prefix: feature/C1234-43224-description
  /^(?<type>feature|bug|hotfix|refactor|chore)\/(?<projectCode>[A-Z][A-Z0-9]+)-(?<issueNumber>\d+)/i,
  // Direct format: C1234-43224-description
  /^(?<projectCode>[A-Z][A-Z0-9]+)-(?<issueNumber>\d+)/i,
];

export async function parseBranchName(
  branchName: string
): Promise<SkillResult<BranchParseResult>> {
  const startTime = Date.now();

  try {
    // Try each pattern
    for (const pattern of BRANCH_PATTERNS) {
      const match = branchName.match(pattern);

      if (match && match.groups) {
        const { projectCode, issueNumber, type } = match.groups;
        const jiraId = `${projectCode}-${issueNumber}`;

        const result: BranchParseResult = {
          projectCode: projectCode.toUpperCase(),
          jiraId: jiraId.toUpperCase(),
          branchName,
          branchType: (type?.toLowerCase() as any) || 'unknown',
        };

        return {
          success: true,
          data: result,
          metadata: {
            skillName: 'git-branch-parser',
            executionTime: Date.now() - startTime,
            timestamp: new Date().toISOString(),
          },
        };
      }
    }

    // No pattern matched
    const error: SkillError = {
      code: 'JIRA_ID_NOT_FOUND',
      message: `Could not extract Jira ID from branch name: ${branchName}`,
      details: {
        branchName,
        supportedFormats: [
          'feature/C1234-43224-description',
          'bug/PROJ-123-description',
          'C1234-43224-description',
        ],
      },
      recoverable: true, // User can provide Jira ID manually
    };

    return {
      success: false,
      error,
      metadata: {
        skillName: 'git-branch-parser',
        executionTime: Date.now() - startTime,
        timestamp: new Date().toISOString(),
      },
    };
  } catch (error) {
    const skillError: SkillError = {
      code: 'PARSING_ERROR',
      message: `Unexpected error parsing branch name: ${error}`,
      recoverable: false,
    };

    return {
      success: false,
      error: skillError,
      metadata: {
        skillName: 'git-branch-parser',
        executionTime: Date.now() - startTime,
        timestamp: new Date().toISOString(),
      },
    };
  }
}

/**
 * Extract Jira ID directly from a string (useful for commit message scanning)
 */
export function extractJiraId(text: string): string | null {
  const pattern = /([A-Z][A-Z0-9]+-\d+)/i;
  const match = text.match(pattern);
  return match ? match[1].toUpperCase() : null;
}

/**
 * Validate branch name format
 */
export function isValidBranchFormat(branchName: string): boolean {
  return BRANCH_PATTERNS.some((pattern) => pattern.test(branchName));
}
