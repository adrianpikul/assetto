/**
 * Code Quality Agent Implementation
 *
 * Analyzes code structure, patterns, tests, and potential regressions.
 * Production version would use LLM + static analysis tools.
 */

import type {
  SharedContext,
  CodeQualityReport,
  Finding,
  TestCoverageItem,
} from '../../../../../src/agents/types/shared-context';

export async function analyzeCodeQuality(
  context: SharedContext
): Promise<CodeQualityReport> {
  const startTime = Date.now();

  try {
    const report: CodeQualityReport = {
      structure: await analyzeStructure(context),
      patterns: await analyzePatterns(context),
      tests: await analyzeTestCoverage(context),
      edgeCases: await analyzeEdgeCases(context),
      regressions: await analyzeRegressions(context),
    };

    console.log(
      `[code-quality-agent] Analysis complete in ${Date.now() - startTime}ms`
    );

    return report;
  } catch (error) {
    console.error(`[code-quality-agent] Error: ${error}`);

    return {
      structure: [],
      patterns: [],
      tests: [],
      edgeCases: [],
      regressions: [],
    };
  }
}

async function analyzeStructure(context: SharedContext): Promise<Finding[]> {
  const findings: Finding[] = [];

  // Check for long files (heuristic: file size in diff)
  const diffLines = context.gitDiff.split('\n');
  const fileChanges = new Map<string, number>();

  for (const line of diffLines) {
    if (line.startsWith('+++')) {
      const file = line.replace('+++ b/', '').trim();
      fileChanges.set(file, 0);
    } else if (line.startsWith('+') && !line.startsWith('+++')) {
      const files = Array.from(fileChanges.keys());
      if (files.length > 0) {
        const currentFile = files[files.length - 1];
        fileChanges.set(currentFile, fileChanges.get(currentFile)! + 1);
      }
    }
  }

  for (const [file, additions] of fileChanges) {
    if (additions > 200) {
      findings.push({
        id: `struct-${generateId()}`,
        source: 'code-quality-agent',
        category: 'file-length',
        file,
        description: `Large file with ${additions} line additions`,
        recommendation:
          'Consider splitting into smaller, focused modules',
        severity: 'niceToFix',
      });
    }
  }

  return findings;
}

async function analyzePatterns(context: SharedContext): Promise<Finding[]> {
  const findings: Finding[] = [];

  // Check for common anti-patterns in diff
  const antiPatterns = [
    {
      pattern: /console\.log\(/g,
      category: 'debug-code',
      description: 'Console.log statement found',
      recommendation: 'Remove debug logs before committing',
      severity: 'niceToFix' as const,
    },
    {
      pattern: /TODO|FIXME/g,
      category: 'todo-comment',
      description: 'TODO/FIXME comment found',
      recommendation: 'Create Jira ticket or resolve before merging',
      severity: 'niceToFix' as const,
    },
    {
      pattern: /any\s*\)/g,
      category: 'typescript-any',
      description: 'TypeScript "any" type used',
      recommendation: 'Use specific types for better type safety',
      severity: 'niceToFix' as const,
    },
  ];

  for (const ap of antiPatterns) {
    const matches = context.gitDiff.match(ap.pattern);
    if (matches && matches.length > 0) {
      findings.push({
        id: `pattern-${generateId()}`,
        source: 'code-quality-agent',
        category: ap.category,
        description: `${ap.description} (${matches.length} occurrence(s))`,
        recommendation: ap.recommendation,
        severity: ap.severity,
      });
    }
  }

  return findings;
}

async function analyzeTestCoverage(
  context: SharedContext
): Promise<TestCoverageItem[]> {
  const coverage: TestCoverageItem[] = [];

  const sourceFiles = context.changedFiles.filter(
    (f) =>
      !f.includes('.test.') &&
      !f.includes('.spec.') &&
      !f.includes('__tests__') &&
      (f.endsWith('.ts') ||
        f.endsWith('.tsx') ||
        f.endsWith('.js') ||
        f.endsWith('.jsx'))
  );

  for (const file of sourceFiles) {
    const baseName = file.replace(/\.(ts|tsx|js|jsx)$/, '');
    const testFile = context.changedFiles.find(
      (f) =>
        f.includes(baseName) &&
        (f.includes('.test.') ||
          f.includes('.spec.') ||
          f.includes('__tests__'))
    );

    if (!testFile) {
      coverage.push({
        file,
        coverage: 'none',
        missingTests: ['No test file found'],
      });
    } else {
      coverage.push({
        file,
        testFile,
        coverage: 'partial',
        missingTests: ['Review test completeness manually'],
      });
    }
  }

  return coverage;
}

async function analyzeEdgeCases(context: SharedContext): Promise<Finding[]> {
  const findings: Finding[] = [];

  // Check for common edge case patterns
  const edgeCasePatterns = [
    {
      missing: /\.\w+\s*(?!\?\.)/g,
      present: /\?\./g,
      category: 'null-handling',
      description: 'Property access without optional chaining',
      recommendation: 'Consider using optional chaining (?.)',
    },
    {
      missing: /\.length\s*>/g,
      present: /\.length\s*===\s*0/g,
      category: 'array-check',
      description: 'Array length check may not handle empty arrays',
      recommendation: 'Use explicit checks for empty arrays',
    },
  ];

  // Simplified check (production would use AST analysis)
  const diffContent = context.gitDiff;

  if (!diffContent.includes('try') && !diffContent.includes('catch')) {
    findings.push({
      id: `edge-${generateId()}`,
      source: 'code-quality-agent',
      category: 'error-handling',
      description: 'No error handling (try/catch) found in new code',
      recommendation: 'Add appropriate error handling',
      severity: 'critical',
    });
  }

  return findings;
}

async function analyzeRegressions(context: SharedContext): Promise<Finding[]> {
  const findings: Finding[] = [];

  // Check for breaking changes to shared utilities
  const criticalFiles = ['api', 'utils', 'services', 'hooks'];

  for (const file of context.changedFiles) {
    if (criticalFiles.some((cf) => file.includes(cf))) {
      findings.push({
        id: `regress-${generateId()}`,
        source: 'code-quality-agent',
        category: 'shared-utility-change',
        file,
        description: `Changes to shared utility: ${file}`,
        recommendation: 'Verify all usages of this utility still work',
        severity: 'critical',
      });
    }
  }

  // Check for schema/interface changes
  if (context.gitDiff.includes('interface ') || context.gitDiff.includes('type ')) {
    findings.push({
      id: `regress-${generateId()}`,
      source: 'code-quality-agent',
      category: 'type-change',
      description: 'TypeScript interface/type definitions modified',
      recommendation: 'Review all usages for breaking changes',
      severity: 'critical',
    });
  }

  return findings;
}

function generateId(): string {
  return Math.random().toString(36).substring(2, 9);
}

/**
 * Production Enhancement:
 *
 * Integrate with static analysis tools:
 * - ESLint for JavaScript/TypeScript
 * - Pylint for Python
 * - SonarQube for comprehensive analysis
 * - Custom AST parsers for deep pattern matching
 *
 * Use LLM for semantic analysis:
 * - Understanding code intent
 * - Identifying SOLID violations
 * - Suggesting architectural improvements
 * - Detecting subtle regression risks
 */
