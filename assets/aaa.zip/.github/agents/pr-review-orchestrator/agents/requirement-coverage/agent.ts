/**
 * Requirement Coverage Agent Implementation
 *
 * Analyzes code changes against Jira requirements.
 * In production, this would use an LLM to perform semantic analysis.
 */

import type {
  SharedContext,
  RequirementCoverageReport,
  RequirementItem,
} from '../../../../../src/agents/types/shared-context';

/**
 * Analyze requirement coverage
 *
 * NOTE: This is a simplified implementation demonstrating the structure.
 * Production version would:
 * 1. Use LLM to parse Jira description and extract requirements
 * 2. Use LLM to analyze code and match against requirements
 * 3. Employ semantic understanding for better matching
 */
export async function analyzeRequirementCoverage(
  context: SharedContext
): Promise<RequirementCoverageReport> {
  const startTime = Date.now();

  try {
    // Step 1: Extract requirements from Jira description
    const requirements = extractRequirements(context.jiraDescription);

    // Step 2: Analyze code coverage for each requirement
    const implemented: RequirementItem[] = [];
    const partial: RequirementItem[] = [];
    const missing: RequirementItem[] = [];

    for (const req of requirements) {
      const coverage = analyzeRequirementInCode(req, context);

      if (coverage.status === 'implemented') {
        implemented.push(coverage);
      } else if (coverage.status === 'partial') {
        partial.push(coverage);
      } else {
        missing.push(coverage);
      }
    }

    // Step 3: Generate improvement suggestions
    const improvements = generateImprovements(context, {
      implemented,
      partial,
      missing,
    });

    const report: RequirementCoverageReport = {
      implemented,
      partial,
      missing,
      improvements,
    };

    console.log(
      `[requirement-coverage-agent] Analysis complete in ${Date.now() - startTime}ms`
    );

    return report;
  } catch (error) {
    console.error(`[requirement-coverage-agent] Error: ${error}`);

    // Return empty report on error
    return {
      implemented: [],
      partial: [],
      missing: [],
      improvements: [`Error during analysis: ${error}`],
    };
  }
}

/**
 * Extract discrete requirements from Jira description
 *
 * Production: Use LLM to semantically parse requirements
 */
function extractRequirements(jiraDescription: string): string[] {
  const requirements: string[] = [];

  // Simple heuristic: Look for bullet points, numbered lists, or line breaks
  const lines = jiraDescription.split(/\n|\\n/).map((l) => l.trim());

  for (const line of lines) {
    // Match bullet points (-, *, •)
    if (/^[-*•]\s+/.test(line)) {
      requirements.push(line.replace(/^[-*•]\s+/, ''));
    }
    // Match numbered lists (1. 2. etc.)
    else if (/^\d+\.\s+/.test(line)) {
      requirements.push(line.replace(/^\d+\.\s+/, ''));
    }
    // Match "should", "must", "implement" keywords
    else if (
      /\b(should|must|implement|add|create|fix|update)\b/i.test(line) &&
      line.length > 20
    ) {
      requirements.push(line);
    }
  }

  // If no structured requirements found, use full description
  if (requirements.length === 0) {
    requirements.push(jiraDescription);
  }

  return requirements;
}

/**
 * Analyze if requirement is covered in code
 *
 * Production: Use LLM for semantic code analysis
 */
function analyzeRequirementInCode(
  requirement: string,
  context: SharedContext
): RequirementItem {
  const { gitDiff, changedFiles } = context;

  // Simple keyword matching (production would use LLM)
  const keywords = extractKeywords(requirement);
  const matchedInDiff = keywords.some((kw) =>
    gitDiff.toLowerCase().includes(kw.toLowerCase())
  );

  // Check for tests
  const hasTests = changedFiles.some(
    (file) =>
      file.includes('.test.') ||
      file.includes('.spec.') ||
      file.includes('__tests__')
  );

  // Find evidence in diff
  const evidence = findEvidenceInDiff(keywords, gitDiff, changedFiles);

  // Classify
  if (matchedInDiff && hasTests && evidence) {
    return {
      requirement,
      status: 'implemented',
      evidence,
      notes: 'Requirement appears to be fully implemented with tests',
    };
  } else if (matchedInDiff && evidence) {
    return {
      requirement,
      status: 'partial',
      evidence,
      notes: hasTests
        ? 'Implementation found but may be incomplete'
        : 'Implementation found but missing tests',
    };
  } else {
    return {
      requirement,
      status: 'missing',
      notes: 'No implementation found in changed files',
    };
  }
}

/**
 * Extract keywords from requirement text
 */
function extractKeywords(requirement: string): string[] {
  // Remove common words
  const stopWords = new Set([
    'a',
    'an',
    'the',
    'is',
    'are',
    'be',
    'to',
    'and',
    'or',
    'for',
    'with',
    'should',
    'must',
  ]);

  const words = requirement
    .toLowerCase()
    .replace(/[^a-z0-9\s]/g, ' ')
    .split(/\s+/)
    .filter((w) => w.length > 3 && !stopWords.has(w));

  return [...new Set(words)]; // Deduplicate
}

/**
 * Find evidence of implementation in diff
 */
function findEvidenceInDiff(
  keywords: string[],
  diff: string,
  changedFiles: string[]
): string | undefined {
  // Simple heuristic: find files mentioning keywords
  for (const file of changedFiles) {
    for (const keyword of keywords) {
      if (diff.includes(keyword) && diff.includes(file)) {
        return file;
      }
    }
  }

  return undefined;
}

/**
 * Generate improvement suggestions
 */
function generateImprovements(
  context: SharedContext,
  analysis: {
    implemented: RequirementItem[];
    partial: RequirementItem[];
    missing: RequirementItem[];
  }
): string[] {
  const suggestions: string[] = [];

  // Check for missing tests
  const hasTestFiles = context.changedFiles.some(
    (file) =>
      file.includes('.test.') ||
      file.includes('.spec.') ||
      file.includes('__tests__')
  );

  if (!hasTestFiles && analysis.implemented.length > 0) {
    suggestions.push('Add unit tests to verify implemented requirements');
  }

  // Check for partial implementations
  if (analysis.partial.length > 0) {
    suggestions.push(
      `Complete ${analysis.partial.length} partially implemented requirement(s)`
    );
  }

  // Check for missing requirements
  if (analysis.missing.length > 0) {
    suggestions.push(
      `Implement ${analysis.missing.length} missing requirement(s) from Jira`
    );
  }

  // Check for documentation
  const hasDocChanges = context.changedFiles.some(
    (file) =>
      file.endsWith('.md') ||
      file.toLowerCase().includes('readme') ||
      file.toLowerCase().includes('docs')
  );

  if (!hasDocChanges && analysis.implemented.length > 2) {
    suggestions.push('Consider adding documentation for new features');
  }

  return suggestions;
}

/**
 * Production Integration Point:
 *
 * Replace the heuristic functions above with LLM calls:
 *
 * async function extractRequirementsWithLLM(jiraDescription: string): Promise<string[]> {
 *   const prompt = `Extract discrete, actionable requirements from this Jira description:
 *
 *   ${jiraDescription}
 *
 *   Return a JSON array of requirement strings.`;
 *
 *   const response = await callLLM(prompt);
 *   return JSON.parse(response);
 * }
 *
 * async function analyzeRequirementWithLLM(
 *   requirement: string,
 *   code: string,
 *   changedFiles: string[]
 * ): Promise<RequirementItem> {
 *   const prompt = `Analyze if this requirement is implemented in the code:
 *
 *   Requirement: ${requirement}
 *
 *   Code changes:
 *   ${code}
 *
 *   Changed files: ${changedFiles.join(', ')}
 *
 *   Return JSON: {status: 'implemented'|'partial'|'missing', evidence: string, notes: string}`;
 *
 *   const response = await callLLM(prompt);
 *   return JSON.parse(response);
 * }
 */
