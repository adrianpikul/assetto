/**
 * Type definitions for PR Review Orchestrator Agent
 */

// ============================================================================
// Agent Configuration
// ============================================================================

export interface AgentConfig {
  repoPath: string;
  baseBranch: string;
  cacheEnabled: boolean;
  cacheDir: string;
  logsDir: string;
  reportsDir: string;
  timeout: number;
  logging: LoggingConfig;
  jira?: JiraConfig;
}

export interface LoggingConfig {
  level: 'debug' | 'info' | 'warn' | 'error';
  enableConsole: boolean;
  enableFile: boolean;
}

export interface JiraConfig {
  baseUrl?: string;
  authToken?: string;
  projectKey?: string;
}

// ============================================================================
// Shared Context
// ============================================================================

export interface SharedContext {
  branchName: string;
  projectCode: string;
  jiraId: string;
  gitDiff: string;
  changedFiles: string[];
  jiraDescription: string;
  metadata: ContextMetadata;
}

export interface ContextMetadata {
  lastCommitHash: string;
  timestamp: string;
  cacheHit: boolean;
  baseBranch: string;
  repoPath: string;
}

// ============================================================================
// Agent Results
// ============================================================================

export interface AgentResult<T> {
  success: boolean;
  data?: T;
  error?: AgentError;
  metadata: {
    agentName: string;
    executionTime: number;
    timestamp: string;
  };
}

export interface AgentError {
  code: string;
  message: string;
  details?: any;
  recoverable: boolean;
}

// ============================================================================
// Review Findings
// ============================================================================

export interface Finding {
  id: string;
  source: AgentType;
  category: string;
  file?: string;
  line?: number;
  description: string;
  recommendation?: string;
  codeSnippet?: string;
  severity?: SeverityLevel;
}

export type AgentType =
  | 'requirement-coverage'
  | 'code-quality'
  | 'business-logic'
  | 'orchestrator';

export type SeverityLevel = 'critical' | 'notImplemented' | 'niceToFix';

// ============================================================================
// Agent Reports
// ============================================================================

export interface RequirementCoverageReport {
  implemented: RequirementItem[];
  partial: RequirementItem[];
  missing: RequirementItem[];
  improvements: string[];
}

export interface RequirementItem {
  requirement: string;
  status: 'implemented' | 'partial' | 'missing';
  evidence?: string;
  notes?: string;
}

export interface CodeQualityReport {
  structure: Finding[];
  patterns: Finding[];
  tests: TestCoverageItem[];
  edgeCases: Finding[];
  regressions: Finding[];
}

export interface TestCoverageItem {
  file: string;
  testFile?: string;
  coverage: 'none' | 'partial' | 'good' | 'excellent';
  missingTests: string[];
}

export interface BusinessLogicReport {
  edgeCases: Finding[];
  assumptions: Finding[];
  logicalGaps: Finding[];
  userFlowIssues: Finding[];
}

// ============================================================================
// Final Report
// ============================================================================

export interface ReviewReport {
  metadata: ReviewMetadata;
  findings: CategorizedFindings;
  summary: ReviewSummary;
  actions: PostReviewAction[];
  context: SharedContext;
}

export interface ReviewMetadata {
  branchName: string;
  jiraId: string;
  timestamp: string;
  reviewDuration: string;
  reportPath?: string;
}

export interface CategorizedFindings {
  critical: Finding[];
  notImplemented: Finding[];
  niceToFix: Finding[];
}

export interface ReviewSummary {
  totalFindings: number;
  criticalCount: number;
  notImplementedCount: number;
  niceToFixCount: number;
  filesAnalyzed: number;
  testCoverage: 'none' | 'partial' | 'good';
}

export interface PostReviewAction {
  id: string;
  label: string;
  description: string;
  handler?: string;
}

// ============================================================================
// Branch Parsing
// ============================================================================

export interface BranchParseResult {
  projectCode: string;
  jiraId: string;
  branchName: string;
  branchType?: 'feature' | 'bug' | 'hotfix' | 'refactor' | 'unknown';
}

// ============================================================================
// Diff Retrieval
// ============================================================================

export interface DiffRetrievalResult {
  diff: string;
  changedFiles: string[];
  cacheHit: boolean;
  commitHash: string;
  stats: {
    additions: number;
    deletions: number;
    filesChanged: number;
  };
}

// ============================================================================
// Jira Context
// ============================================================================

export interface JiraContextResult {
  jiraId: string;
  description: string;
  source: 'user-input' | 'api' | 'cache';
  metadata?: {
    issueType?: string;
    status?: string;
    assignee?: string;
    priority?: string;
  };
}

// ============================================================================
// Cache
// ============================================================================

export interface CacheEntry {
  diff: string;
  changedFiles: string[];
  timestamp: string;
  commitHash: string;
  stats: {
    additions: number;
    deletions: number;
    filesChanged: number;
  };
}

// ============================================================================
// Logging
// ============================================================================

export interface LogEntry {
  timestamp: string;
  level: 'debug' | 'info' | 'warn' | 'error';
  component: string;
  message: string;
  data?: any;
}

// ============================================================================
// Orchestration
// ============================================================================

export type OrchestratorPhase =
  | 'initialization'
  | 'context-acquisition'
  | 'context-validation'
  | 'parallel-review'
  | 'aggregation'
  | 'finalization'
  | 'error';

export interface OrchestrationState {
  phase: OrchestratorPhase;
  startTime: number;
  logs: LogEntry[];
  errors: AgentError[];
}
