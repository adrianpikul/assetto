/**
 * Configuration Manager
 */

import { AgentConfig } from '../types';

export class ConfigManager {
  /**
   * Load configuration with defaults
   */
  static load(userConfig?: Partial<AgentConfig>): AgentConfig {
    const defaultConfig: AgentConfig = {
      repoPath: process.cwd(),
      baseBranch: 'main',
      cacheEnabled: true,
      cacheDir: '.copilot/cache/pr-review',
      logsDir: '.copilot/logs/pr-review',
      reportsDir: '.copilot/reports',
      timeout: 30000,
      logging: {
        level: 'info',
        enableConsole: true,
        enableFile: true,
      },
      jira: {
        baseUrl: process.env.JIRA_BASE_URL,
        authToken: process.env.JIRA_AUTH_TOKEN,
        projectKey: process.env.JIRA_PROJECT_KEY,
      },
    };

    return {
      ...defaultConfig,
      ...userConfig,
      logging: {
        ...defaultConfig.logging,
        ...userConfig?.logging,
      },
      jira: {
        ...defaultConfig.jira,
        ...userConfig?.jira,
      },
    };
  }
}
