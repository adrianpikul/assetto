/**
 * Orchestrator Core
 *
 * Coordinates all review agents and manages execution flow
 */

import { execSync } from 'child_process';
import {
  AgentConfig,
  SharedContext,
  ReviewReport,
  OrchestrationState,
  RequirementCoverageReport,
  CodeQualityReport,
  BusinessLogicReport,
} from '../types';
import { Logger } from '../utils/logger';
import { BranchParser } from '../skills/branch-parser';
import { DiffRetriever } from '../skills/diff-retriever';
import { JiraContextAcquirer } from '../skills/jira-context';
import { RequirementCoverageAgent } from '../agents/requirement-coverage/agent';
import { CodeQualityAgent } from '../agents/code-quality/agent';
import { BusinessLogicAgent } from '../agents/business-logic/agent';
import { Aggregator } from './aggregator';
import { ReportGenerator } from '../utils/report-generator';

export class OrchestratorCore {
  private config: AgentConfig;
  private logger: Logger;
  private state: OrchestrationState;

  constructor(config: AgentConfig, logger: Logger) {
    this.config = config;
    this.logger = logger;
    this.state = {
      phase: 'initialization',
      startTime: Date.now(),
      logs: [],
      errors: [],
    };
  }

  /**
   * Main orchestration flow
   */
  async orchestrate(options: {
    repoPath: string;
    baseBranch: string;
    skipCache: boolean;
  }): Promise<ReviewReport | null> {
    try {
      // Phase 1: Context Acquisition
      this.state.phase = 'context-acquisition';
      this.logger.info('Starting context acquisition...');

      const context = await this.acquireContext(options);
      if (!context) {
        this.logger.error('Failed to acquire context');
        return null;
      }

      // Phase 2: Context Validation
      this.state.phase = 'context-validation';
      const validationError = this.validateContext(context);
      if (validationError) {
        this.logger.error(`Context validation failed: ${validationError}`);
        return null;
      }

      // Phase 3: Parallel Review
      this.state.phase = 'parallel-review';
      this.logger.info('Executing review agents in parallel...');

      const agentReports = await this.executeReviewAgents(context);

      // Phase 4: Aggregation
      this.state.phase = 'aggregation';
      this.logger.info('Aggregating findings...');

      const aggregator = new Aggregator(this.logger);
      const aggregatedFindings = await aggregator.aggregate(
        context,
        agentReports,
        this.state.startTime
      );

      // Phase 5: Finalization
      this.state.phase = 'finalization';
      this.logger.info('Generating final report...');

      const reportGenerator = new ReportGenerator(this.config, this.logger);
      const report = await reportGenerator.generate(
        context,
        aggregatedFindings,
        this.state.startTime
      );

      this.logger.info('Review orchestration completed successfully');
      return report;
    } catch (error) {
      this.state.phase = 'error';
      this.logger.error('Orchestration error', error);
      return null;
    }
  }

  /**
   * Acquire all necessary context
   */
  private async acquireContext(options: {
    repoPath: string;
    baseBranch: string;
    skipCache: boolean;
  }): Promise<SharedContext | null> {
    try {
      // 1. Get current branch
      const branchName = execSync('git branch --show-current', {
        cwd: options.repoPath,
        encoding: 'utf-8',
      }).trim();

      this.logger.debug(`Current branch: ${branchName}`);

      // 2. Parse branch to extract Jira ID
      const branchParser = new BranchParser(this.logger);
      const parseResult = await branchParser.parse(branchName);

      if (!parseResult.success || !parseResult.data) {
        this.logger.error('Failed to parse branch name', parseResult.error);
        return null;
      }

      const { projectCode, jiraId } = parseResult.data;

      // 3. Retrieve git diff
      const diffRetriever = new DiffRetriever(this.config, this.logger);
      const diffResult = await diffRetriever.retrieve({
        jiraId,
        branchName,
        baseBranch: options.baseBranch,
        repoPath: options.repoPath,
        skipCache: options.skipCache,
      });

      if (!diffResult.success || !diffResult.data) {
        this.logger.error('Failed to retrieve diff', diffResult.error);
        return null;
      }

      // 4. Acquire Jira context
      const jiraAcquirer = new JiraContextAcquirer(this.config, this.logger);
      const jiraResult = await jiraAcquirer.acquire({ jiraId });

      if (!jiraResult.success || !jiraResult.data) {
        this.logger.error('Failed to acquire Jira context', jiraResult.error);
        return null;
      }

      // Build shared context
      const context: SharedContext = {
        branchName,
        projectCode,
        jiraId,
        gitDiff: diffResult.data.diff,
        changedFiles: diffResult.data.changedFiles,
        jiraDescription: jiraResult.data.description,
        metadata: {
          lastCommitHash: diffResult.data.commitHash,
          timestamp: new Date().toISOString(),
          cacheHit: diffResult.data.cacheHit,
          baseBranch: options.baseBranch,
          repoPath: options.repoPath,
        },
      };

      this.logger.info('Context acquired successfully', {
        jiraId: context.jiraId,
        filesChanged: context.changedFiles.length,
        cacheHit: context.metadata.cacheHit,
      });

      return context;
    } catch (error) {
      this.logger.error('Error acquiring context', error);
      return null;
    }
  }

  /**
   * Validate context completeness
   */
  private validateContext(context: SharedContext): string | null {
    if (!context.jiraId) return 'Missing Jira ID';
    if (!context.gitDiff || context.gitDiff.trim().length === 0)
      return 'Empty git diff';
    if (!context.jiraDescription || context.jiraDescription.trim().length === 0)
      return 'Missing Jira description';
    if (context.changedFiles.length === 0) return 'No changed files detected';

    return null;
  }

  /**
   * Execute all review agents in parallel
   */
  private async executeReviewAgents(context: SharedContext): Promise<{
    requirementCoverage: RequirementCoverageReport;
    codeQuality: CodeQualityReport;
    businessLogic: BusinessLogicReport;
  }> {
    const [requirementCoverage, codeQuality, businessLogic] = await Promise.all([
      this.executeRequirementCoverageAgent(context),
      this.executeCodeQualityAgent(context),
      this.executeBusinessLogicAgent(context),
    ]);

    return {
      requirementCoverage,
      codeQuality,
      businessLogic,
    };
  }

  /**
   * Execute Requirement Coverage Agent
   */
  private async executeRequirementCoverageAgent(
    context: SharedContext
  ): Promise<RequirementCoverageReport> {
    this.logger.info('[requirement-coverage] Starting analysis...');
    const agent = new RequirementCoverageAgent(this.logger);
    const report = await agent.analyze(context);
    this.logger.info('[requirement-coverage] Analysis complete', {
      implemented: report.implemented.length,
      partial: report.partial.length,
      missing: report.missing.length,
    });
    return report;
  }

  /**
   * Execute Code Quality Agent
   */
  private async executeCodeQualityAgent(
    context: SharedContext
  ): Promise<CodeQualityReport> {
    this.logger.info('[code-quality] Starting analysis...');
    const agent = new CodeQualityAgent(this.logger);
    const report = await agent.analyze(context);
    this.logger.info('[code-quality] Analysis complete', {
      structure: report.structure.length,
      patterns: report.patterns.length,
      tests: report.tests.length,
    });
    return report;
  }

  /**
   * Execute Business Logic Agent
   */
  private async executeBusinessLogicAgent(
    context: SharedContext
  ): Promise<BusinessLogicReport> {
    this.logger.info('[business-logic] Starting analysis...');
    const agent = new BusinessLogicAgent(this.logger);
    const report = await agent.analyze(context);
    this.logger.info('[business-logic] Analysis complete', {
      edgeCases: report.edgeCases.length,
      assumptions: report.assumptions.length,
      logicalGaps: report.logicalGaps.length,
    });
    return report;
  }
}
