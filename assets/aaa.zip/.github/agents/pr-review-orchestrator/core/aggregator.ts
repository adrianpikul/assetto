/**
 * Aggregation Layer Implementation
 *
 * Collects, deduplicates, and classifies findings from all review agents.
 */

import * as crypto from 'crypto';
import type {
  SharedContext,
  RequirementCoverageReport,
  CodeQualityReport,
  BusinessLogicReport,
  AggregatedReviewReport,
  Finding,
  CategorizedFindings,
  ReviewSummary,
  SeverityLevel,
} from '../../../../src/agents/types/shared-context';

export interface AgentReports {
  requirementCoverage: RequirementCoverageReport;
  codeQuality: CodeQualityReport;
  businessLogic: BusinessLogicReport;
}

export async function aggregateFindings(
  context: SharedContext,
  reports: AgentReports,
  startTime: number
): Promise<AggregatedReviewReport> {
  // Step 1: Collect all findings
  const allFindings = collectFindings(reports);

  // Step 2: Deduplicate
  const deduplicated = deduplicateFindings(allFindings);

  // Step 3: Classify by severity
  const categorized = classifyBySeverity(deduplicated, context);

  // Step 4: Generate summary
  const summary = generateSummary(categorized, context, reports);

  // Step 5: Create final report
  const report: AggregatedReviewReport = {
    metadata: {
      branchName: context.branchName,
      jiraId: context.jiraId,
      timestamp: new Date().toISOString(),
      reviewDuration: `${((Date.now() - startTime) / 1000).toFixed(1)}s`,
    },
    findings: categorized,
    summary,
    actions: [
      {
        label: 'Create Plan to Fix Below Issues',
        agentId: 'fix-planning-agent',
        description: 'Generate step-by-step resolution plan',
      },
      {
        label: 'Implement Below Issues in Agent Mode',
        agentId: 'fix-implementation-agent',
        description: 'Apply code changes automatically',
      },
    ],
  };

  return report;
}

/**
 * Collect all findings from agent reports
 */
function collectFindings(reports: AgentReports): Finding[] {
  const findings: Finding[] = [];

  // From requirement coverage
  for (const item of reports.requirementCoverage.missing) {
    findings.push({
      id: generateId(),
      source: 'requirement-coverage-agent',
      category: 'missing-requirement',
      description: `Missing requirement: ${item.requirement}`,
      recommendation: item.notes || 'Implement this requirement from Jira',
      severity: 'notImplemented',
    });
  }

  for (const item of reports.requirementCoverage.partial) {
    findings.push({
      id: generateId(),
      source: 'requirement-coverage-agent',
      category: 'partial-requirement',
      description: `Partial implementation: ${item.requirement}`,
      recommendation: item.notes || 'Complete this requirement',
      file: item.evidence,
      severity: 'notImplemented',
    });
  }

  // From code quality
  findings.push(...reports.codeQuality.structure);
  findings.push(...reports.codeQuality.patterns);
  findings.push(...reports.codeQuality.edgeCases);
  findings.push(...reports.codeQuality.regressions);

  // Convert test coverage to findings
  for (const test of reports.codeQuality.tests) {
    if (test.coverage === 'none') {
      findings.push({
        id: generateId(),
        source: 'code-quality-agent',
        category: 'missing-tests',
        file: test.file,
        description: `No tests found for ${test.file}`,
        recommendation: 'Add unit tests for new functionality',
        severity: 'notImplemented',
      });
    }
  }

  // From business logic
  findings.push(...reports.businessLogic.edgeCases);
  findings.push(...reports.businessLogic.assumptions);
  findings.push(...reports.businessLogic.logicalGaps);
  findings.push(...reports.businessLogic.userFlowIssues);

  return findings;
}

/**
 * Deduplicate findings
 */
function deduplicateFindings(findings: Finding[]): Finding[] {
  const seen = new Map<string, Finding>();

  for (const finding of findings) {
    // Generate deduplication key
    const key = generateDeduplicationKey(finding);

    if (seen.has(key)) {
      // Merge with existing finding
      const existing = seen.get(key)!;

      // Keep higher severity
      if (compareSeverity(finding.severity, existing.severity) > 0) {
        existing.severity = finding.severity;
      }

      // Merge recommendations
      if (finding.recommendation && existing.recommendation !== finding.recommendation) {
        existing.recommendation += `; ${finding.recommendation}`;
      }
    } else {
      seen.set(key, { ...finding });
    }
  }

  return Array.from(seen.values());
}

/**
 * Generate deduplication key
 */
function generateDeduplicationKey(finding: Finding): string {
  const parts = [
    finding.file || 'global',
    finding.line?.toString() || 'noLine',
    finding.category,
    finding.description.toLowerCase().substring(0, 50), // First 50 chars
  ];

  return crypto.createHash('md5').update(parts.join('|')).digest('hex');
}

/**
 * Compare severity levels (higher is worse)
 */
function compareSeverity(
  a: SeverityLevel | undefined,
  b: SeverityLevel | undefined
): number {
  const order: Record<SeverityLevel, number> = {
    critical: 3,
    notImplemented: 2,
    niceToFix: 1,
  };

  return (order[a || 'niceToFix'] || 0) - (order[b || 'niceToFix'] || 0);
}

/**
 * Classify findings by severity with strict rules
 */
function classifyBySeverity(
  findings: Finding[],
  context: SharedContext
): CategorizedFindings {
  const critical: Finding[] = [];
  const notImplemented: Finding[] = [];
  const niceToFix: Finding[] = [];

  for (const finding of findings) {
    const severity = determineSeverity(finding, context);

    if (severity === 'critical') {
      critical.push({ ...finding, severity: 'critical' });
    } else if (severity === 'notImplemented') {
      notImplemented.push({ ...finding, severity: 'notImplemented' });
    } else {
      niceToFix.push({ ...finding, severity: 'niceToFix' });
    }
  }

  return { critical, notImplemented, niceToFix };
}

/**
 * Determine final severity with override rules
 */
function determineSeverity(
  finding: Finding,
  context: SharedContext
): SeverityLevel {
  // Override Rule 1: Security issues → Always Critical
  if (
    finding.category.includes('security') ||
    finding.category.includes('auth') ||
    finding.description.toLowerCase().includes('security') ||
    finding.description.toLowerCase().includes('vulnerability')
  ) {
    return 'critical';
  }

  // Override Rule 2: Data loss/integrity → Always Critical
  if (
    finding.category.includes('data-loss') ||
    finding.category.includes('null-handling') ||
    finding.category.includes('concurrent-modification') ||
    finding.description.toLowerCase().includes('data loss') ||
    finding.description.toLowerCase().includes('null pointer')
  ) {
    return 'critical';
  }

  // Override Rule 3: Regressions in shared code → Critical
  if (
    finding.category.includes('regression') ||
    finding.category.includes('shared-utility-change') ||
    finding.category.includes('api-change')
  ) {
    return 'critical';
  }

  // Override Rule 4: Missing Jira requirements → NotImplemented
  if (
    finding.source === 'requirement-coverage-agent' ||
    finding.category.includes('missing-requirement') ||
    finding.category.includes('partial-requirement')
  ) {
    return 'notImplemented';
  }

  // Override Rule 5: Missing tests for new features → NotImplemented
  if (finding.category === 'missing-tests') {
    return 'notImplemented';
  }

  // Override Rule 6: Style/debug code → NiceToFix
  if (
    finding.category.includes('style') ||
    finding.category.includes('debug-code') ||
    finding.category.includes('todo-comment') ||
    finding.category.includes('file-length')
  ) {
    return 'niceToFix';
  }

  // Default: Use agent-assigned severity or default to niceToFix
  return finding.severity || 'niceToFix';
}

/**
 * Generate summary statistics
 */
function generateSummary(
  categorized: CategorizedFindings,
  context: SharedContext,
  reports: AgentReports
): ReviewSummary {
  // Calculate test coverage
  const testCoverage = calculateTestCoverage(reports.codeQuality.tests);

  return {
    totalFindings:
      categorized.critical.length +
      categorized.notImplemented.length +
      categorized.niceToFix.length,
    criticalCount: categorized.critical.length,
    notImplementedCount: categorized.notImplemented.length,
    niceToFixCount: categorized.niceToFix.length,
    filesAnalyzed: context.changedFiles.length,
    testCoverage,
  };
}

/**
 * Calculate overall test coverage
 */
function calculateTestCoverage(
  tests: Array<{ coverage: string }>
): 'none' | 'partial' | 'good' {
  if (tests.length === 0) return 'none';

  const goodCount = tests.filter((t) => t.coverage === 'good' || t.coverage === 'excellent').length;
  const noneCount = tests.filter((t) => t.coverage === 'none').length;

  if (goodCount === tests.length) return 'good';
  if (noneCount === tests.length) return 'none';
  return 'partial';
}

function generateId(): string {
  return crypto.randomBytes(4).toString('hex');
}
