# GitHub Copilot Configuration

This directory contains the GitHub Copilot agent and skill definitions for this repository.

## Structure

```
.github/
├── copilot-instructions.md      # Repository-wide Copilot instructions
├── agents/                       # Custom agent definitions
│   ├── pr-review.agent.md       # Main PR review orchestrator
│   ├── requirement-coverage.agent.md
│   ├── code-quality.agent.md
│   └── business-logic.agent.md
└── skills/                       # Reusable skills
    ├── branch-parser/
    ├── diff-retriever/
    ├── jira-context/
    └── aggregator/
```

## Quick Start

### PR Review

```
@pr-review Review this PR
```

This invokes the main orchestrator agent that:
1. Extracts Jira ID from branch name
2. Retrieves git diff (cached)
3. Asks you for Jira requirements
4. Runs 3 specialized review agents in parallel
5. Aggregates and classifies findings
6. Generates comprehensive report

### Individual Reviews

```
@requirement-coverage Check if I implemented all requirements
@code-quality Evaluate my code quality
@business-logic Validate my business logic
```

## Agents

### Main Orchestrator

**@pr-review** - Comprehensive PR review agent
- Coordinates multiple specialized agents
- Manages execution flow
- Produces structured reports

### Sub-Agents

**@requirement-coverage** - Requirements analyst
- Compares Jira requirements vs implementation
- Identifies: implemented, partial, missing

**@code-quality** - Code quality expert
- Evaluates structure, patterns, test coverage
- Identifies regressions and edge cases

**@business-logic** - Business analyst
- Validates business logic correctness
- Identifies assumptions and logical gaps

## Skills

**branch-parser** - Extract Jira ID from branch names
- Format: `feature/C1234-43224-description`

**diff-retriever** - Retrieve git diff with caching
- Performance: <5ms cached, <500ms uncached

**jira-context** - Acquire Jira issue description
- Current: user prompt
- Future: Jira API integration

**aggregator** - Aggregate and classify findings
- Deduplicates findings
- Classifies: Critical / NotImplemented / NiceToFix

## Documentation

- **[copilot-instructions.md](./copilot-instructions.md)** - Usage guide and conventions
- **[agents/](./agents/)** - Agent definitions with persona and behavior
- **[skills/](./skills/)** - Skill definitions with input/output contracts

## Branch Naming Convention

For automatic Jira ID extraction:

```
{type}/{PROJECT_CODE}-{ISSUE_NUMBER}-{description}
```

Examples:
- `feature/C1234-43224-add-authentication`
- `bug/PROJ-123-fix-login`
- `hotfix/C1234-567-critical-fix`

## Cache & Reports

Generated files:
- Cache: `.copilot/cache/pr-review/`
- Logs: `.copilot/logs/pr-review/`
- Reports: `.copilot/reports/`

To clear cache:
```bash
rm -rf .copilot/cache/
```

## Adding New Agents

1. Create `.github/agents/my-agent.agent.md`
2. Define agent frontmatter (name, description, persona)
3. Write agent instructions and behavior
4. Reference from other agents if needed

## Adding New Skills

1. Create `.github/skills/my-skill/`
2. Add `SKILL.md` with frontmatter
3. Document input/output contracts
4. Reference from agents that use it

## References

- [GitHub Copilot Agent Structure Guide](https://dev.to/pwd9000/github-copilot-instructions-vs-prompts-vs-custom-agents-vs-skills-vs-x-vs-why-339l)
- [Root Documentation](../CLEAN_STRUCTURE.md)

---

**Standard GitHub Copilot structure | Production-ready | Extensible**
