---
name: jira-context
description: Acquires Jira issue description via user prompt. Designed for future Jira REST API integration.
license: MIT
---

# Jira Context Skill

Acquires Jira issue description to provide requirements context.

## Current Implementation

**User Prompt Strategy**: Prompts user to provide Jira description

## Input

```json
{
  "jiraId": "C1234-43224"
}
```

## Output

```json
{
  "jiraId": "C1234-43224",
  "description": "Implement authentication with JWT tokens...",
  "source": "user-input"
}
```

## User Prompt Flow

1. Display Jira ID to user
2. Prompt: "Please provide the Jira description for {jiraId}:"
3. Accept multiline input (blank line to finish)
4. Validate non-empty
5. Return structured result

## Error Handling

**Empty description**:
- Return error `EMPTY_JIRA_DESCRIPTION`
- Recoverable: re-prompt user

## Future: Jira API Integration

Extensible design for API integration:

```typescript
interface JiraAPIConfig {
  baseUrl: string;
  authToken: string;
  projectKey: string;
}
```

**Migration path**:
1. Add `JiraAPIClient` class
2. Try API first: `GET /rest/api/3/issue/{jiraId}`
3. Fallback to user prompt if API fails
4. Cache API responses (1 hour TTL)

## Usage Example

```
Acquire context for C1234-43224

Prompt:
============================================================
📋 Jira Context Required: C1234-43224
============================================================
Please provide the Jira issue description/requirements below.
(Enter a blank line when done)

User input:
Implement user authentication with:
- Login with email/password
- Logout functionality
- Session management (24h expiry)

[blank line]

Output:
{
  "jiraId": "C1234-43224",
  "description": "Implement user authentication with:...",
  "source": "user-input"
}
```

## With API (Future)

```
Acquire context for C1234-43224

API call: GET /rest/api/3/issue/C1234-43224
→ Success

Output:
{
  "jiraId": "C1234-43224",
  "description": "Implement authentication...",
  "source": "api",
  "metadata": {
    "issueType": "Story",
    "status": "In Progress",
    "priority": "High"
  }
}
```
