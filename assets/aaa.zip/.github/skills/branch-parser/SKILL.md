---
name: branch-parser
description: Extracts project code and Jira ID from git branch names following standard naming conventions
license: MIT
---

# Branch Parser Skill

Extracts structured information from git branch names.

## Supported Formats

- `feature/C1234-43224-description`
- `bug/PROJ-123-fix-issue`
- `hotfix/C1234-43224-critical-fix`
- `C1234-43224-direct-format` (no prefix)

## Input

Current git branch name (string)

## Output

```json
{
  "projectCode": "C1234",
  "jiraId": "C1234-43224",
  "branchName": "feature/C1234-43224-something-to-do",
  "branchType": "feature"
}
```

## Error Handling

If Jira ID cannot be extracted:
- Return error with code `JIRA_ID_NOT_FOUND`
- Mark as recoverable (user can provide manually)

## Usage

```
Current branch: feature/C1234-43224-add-authentication
Extract: { projectCode: "C1234", jiraId: "C1234-43224", branchType: "feature" }
```

## Pattern Matching

Uses regex patterns:
1. `{type}/{CODE}-{NUM}-{desc}` (e.g., feature/C1234-43224-add-auth)
2. `{CODE}-{NUM}-{desc}` (e.g., C1234-43224-add-auth)

Where:
- `{type}`: feature | bug | hotfix | refactor | chore
- `{CODE}`: 1+ uppercase letters/digits
- `{NUM}`: 1+ digits
