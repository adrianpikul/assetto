/**
 * Jira Context Acquisition Implementation
 *
 * Currently uses user prompts, designed for future Jira API integration.
 */

import * as readline from 'readline';
import type {
  JiraContextResult,
  SkillResult,
  SkillError,
} from '../../../../src/agents/types/shared-context';

export interface JiraContextInput {
  jiraId: string;
  skipPrompt?: boolean; // For testing
  fallbackDescription?: string; // For testing
}

/**
 * Future: Jira API Configuration
 */
export interface JiraAPIConfig {
  baseUrl: string;
  authToken: string;
  projectKey: string;
  cacheTTL?: number; // milliseconds, default: 1 hour
}

/**
 * Acquire Jira context (currently via user prompt)
 */
export async function acquireJiraContext(
  input: JiraContextInput
): Promise<SkillResult<JiraContextResult>> {
  const startTime = Date.now();

  try {
    // Future: Try API first
    // const apiResult = await tryJiraAPI(input.jiraId);
    // if (apiResult) return apiResult;

    // Current: User prompt
    if (input.skipPrompt && input.fallbackDescription) {
      // Testing mode
      return createSuccessResult(
        input.jiraId,
        input.fallbackDescription,
        'user-input',
        startTime
      );
    }

    const description = await promptUserForDescription(input.jiraId);

    if (!description || description.trim().length === 0) {
      const error: SkillError = {
        code: 'EMPTY_JIRA_DESCRIPTION',
        message: `Jira description cannot be empty for ${input.jiraId}`,
        recoverable: true,
      };

      return {
        success: false,
        error,
        metadata: {
          skillName: 'jira-context',
          executionTime: Date.now() - startTime,
          timestamp: new Date().toISOString(),
        },
      };
    }

    return createSuccessResult(
      input.jiraId,
      description,
      'user-input',
      startTime
    );
  } catch (error) {
    const skillError: SkillError = {
      code: 'JIRA_CONTEXT_ERROR',
      message: `Failed to acquire Jira context: ${error}`,
      recoverable: false,
    };

    return {
      success: false,
      error: skillError,
      metadata: {
        skillName: 'jira-context',
        executionTime: Date.now() - startTime,
        timestamp: new Date().toISOString(),
      },
    };
  }
}

/**
 * Prompt user for Jira description
 */
async function promptUserForDescription(jiraId: string): Promise<string> {
  console.log(`\n${'='.repeat(60)}`);
  console.log(`📋 Jira Context Required: ${jiraId}`);
  console.log(`${'='.repeat(60)}`);
  console.log(
    'Please provide the Jira issue description/requirements below.'
  );
  console.log('(Enter a blank line when done)\n');

  const rl = readline.createInterface({
    input: process.stdin,
    output: process.stdout,
  });

  const lines: string[] = [];

  return new Promise((resolve) => {
    rl.on('line', (line) => {
      if (line.trim() === '' && lines.length > 0) {
        rl.close();
        resolve(lines.join('\n'));
      } else {
        lines.push(line);
      }
    });

    rl.on('close', () => {
      if (lines.length > 0) {
        resolve(lines.join('\n'));
      } else {
        resolve('');
      }
    });
  });
}

/**
 * Create success result
 */
function createSuccessResult(
  jiraId: string,
  description: string,
  source: 'user-input' | 'api' | 'cache',
  startTime: number
): SkillResult<JiraContextResult> {
  return {
    success: true,
    data: {
      jiraId,
      description,
      source,
    },
    metadata: {
      skillName: 'jira-context',
      executionTime: Date.now() - startTime,
      timestamp: new Date().toISOString(),
    },
  };
}

/**
 * Future: Jira API Integration
 */
/*
class JiraAPIClient {
  private config: JiraAPIConfig;

  constructor(config: JiraAPIConfig) {
    this.config = config;
  }

  async fetchIssue(jiraId: string): Promise<JiraContextResult | null> {
    try {
      const response = await fetch(
        `${this.config.baseUrl}/rest/api/3/issue/${jiraId}`,
        {
          headers: {
            'Authorization': `Bearer ${this.config.authToken}`,
            'Content-Type': 'application/json',
          },
        }
      );

      if (!response.ok) {
        return null;
      }

      const data = await response.json();

      return {
        jiraId,
        description: data.fields.description || '',
        source: 'api',
        metadata: {
          issueType: data.fields.issuetype?.name,
          status: data.fields.status?.name,
          assignee: data.fields.assignee?.displayName,
          priority: data.fields.priority?.name,
        },
      };
    } catch (error) {
      console.error(`Jira API error: ${error}`);
      return null;
    }
  }
}

async function tryJiraAPI(jiraId: string): Promise<SkillResult<JiraContextResult> | null> {
  // Check for API config in environment
  const apiConfig = loadJiraAPIConfig();
  if (!apiConfig) return null;

  const client = new JiraAPIClient(apiConfig);
  const result = await client.fetchIssue(jiraId);

  if (result) {
    return {
      success: true,
      data: result,
      metadata: {
        skillName: 'jira-context',
        executionTime: 0,
        timestamp: new Date().toISOString(),
      },
    };
  }

  return null;
}

function loadJiraAPIConfig(): JiraAPIConfig | null {
  const baseUrl = process.env.JIRA_BASE_URL;
  const authToken = process.env.JIRA_AUTH_TOKEN;
  const projectKey = process.env.JIRA_PROJECT_KEY;

  if (!baseUrl || !authToken || !projectKey) {
    return null;
  }

  return { baseUrl, authToken, projectKey };
}
*/
