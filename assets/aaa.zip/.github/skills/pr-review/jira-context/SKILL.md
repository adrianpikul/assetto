---
name: jira-context
description: Acquires Jira issue description for PR review. Currently prompts user, designed for future Jira API integration.
license: MIT
allowed-tools:
  - bash
---

# Jira Context Acquisition Skill

## Purpose

Acquires Jira issue description to provide business requirements context for code review.

## Current Implementation

**User Prompt Strategy**: Prompts the user to provide the Jira description for the extracted Jira ID.

## Future Extension: Jira API

Designed with extensibility for Jira REST API integration:

```typescript
interface JiraAPIConfig {
  baseUrl: string;
  authToken: string;
  projectKey: string;
}
```

Future API integration will:
1. Authenticate with Jira
2. Fetch issue details via GET /rest/api/3/issue/{jiraId}
3. Extract description, acceptance criteria, subtasks
4. Cache responses to reduce API calls

## Input

```typescript
{
  jiraId: string;
  skipPrompt?: boolean; // For testing
}
```

## Output

```typescript
{
  jiraId: string;
  description: string;
  source: 'user-input' | 'api' | 'cache';
  metadata?: {
    issueType?: string;    // "Story", "Bug", "Task"
    status?: string;        // "In Progress", "Done"
    assignee?: string;
    priority?: string;      // "High", "Medium", "Low"
  }
}
```

## User Prompt Flow

1. Display Jira ID to user
2. Prompt: "Please provide the Jira description for {jiraId}:"
3. Accept multiline input
4. Validate non-empty description
5. Return structured result

## Error Handling

### Empty Description
If user provides empty description:
- Returns error `code: "EMPTY_JIRA_DESCRIPTION"`
- Orchestrator blocks review until valid description provided

### API Failure (Future)
If Jira API call fails:
- Falls back to user prompt
- Logs API error for debugging
- Continues with user-provided description

## Caching Strategy (Future)

Once API integration is added:
- Cache Jira responses for 1 hour
- Cache key: `jira-{jiraId}-{timestamp}`
- Invalidate on explicit user request

## Implementation

See `jira-context.ts` for TypeScript implementation.

## Migration Path to API

Current implementation uses `getUserInput()` abstraction:

```typescript
async function getUserInput(prompt: string): Promise<string> {
  // Current: stdin/stdout
  // Future: Jira API call with fallback to user prompt
  return await promptUser(prompt);
}
```

To migrate to API:
1. Add `JiraAPIClient` class
2. Replace `getUserInput()` with `fetchFromAPI()`
3. Add fallback: API → Cache → User Prompt
4. No changes needed in orchestrator

## Examples

### Example 1: User Input
```typescript
Input: { jiraId: "C1234-43224" }

Prompt: "Please provide the Jira description for C1234-43224:"
User Input: "Implement authentication with JWT tokens. 
             Users should be able to login and logout.
             Session should persist for 24 hours."

Output: {
  jiraId: "C1234-43224",
  description: "Implement authentication with JWT tokens...",
  source: "user-input"
}
```

### Example 2: API (Future)
```typescript
Input: { jiraId: "C1234-43224" }

API Call: GET /rest/api/3/issue/C1234-43224

Output: {
  jiraId: "C1234-43224",
  description: "Implement authentication with JWT tokens...",
  source: "api",
  metadata: {
    issueType: "Story",
    status: "In Progress",
    assignee: "john.doe",
    priority: "High"
  }
}
```
