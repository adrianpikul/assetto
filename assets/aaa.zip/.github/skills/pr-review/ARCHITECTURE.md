# PR Review Agent Orchestration System - Architecture

## Overview

This is a production-grade, multi-agent PR review orchestration system designed for local VSCode + GitHub Copilot environments. The system follows GitHub Copilot skills architecture principles with deterministic outputs, parallel execution, and robust failure handling.

## Architecture Diagram

```
┌─────────────────────────────────────────────────────────────────┐
│                    ORCHESTRATOR AGENT                            │
│  (Main coordinator - execution flow & error handling)            │
└────────────┬────────────────────────────────────────────────────┘
             │
             ├──[Sequential Phase 1: Context Acquisition]──────────┐
             │                                                      │
             ├──► Skill: Git Branch Parser                         │
             │    Input:  current branch name                      │
             │    Output: {projectCode, jiraId, branchName}        │
             │                                                      │
             ├──► Skill: Git Diff Retriever (with caching)         │
             │    Input:  {jiraId, branchName, lastCommit}         │
             │    Output: {diff, changedFiles, cacheHit}           │
             │                                                      │
             └──► Skill: Jira Context Acquisition                  │
                  Input:  {jiraId}                                 │
                  Output: {description, extensible for API}        │
                                                                    │
             ┌────────────────────────────────────────────────────┘
             │
             ├──[Phase 2: Context Validation & Error Handling]─────
             │   • Validate all required context fields
             │   • Handle missing Jira ID → ask user
             │   • Handle empty diff → stop with explanation
             │   • Handle missing Jira description → block review
             │
             ├──[Phase 3: Parallel Review Execution]───────────────┐
             │                                                      │
             ├──► Agent: Requirement Coverage                      │
             │    │ Input:  SharedContext                          │
             │    │ Output: RequirementCoverageReport              │
             │    │         {implemented[], partial[], missing[],  │
             │    │          improvements[]}                       │
             │    │                                                 │
             ├──► Agent: Code Quality                              │
             │    │ Input:  SharedContext                          │
             │    │ Output: CodeQualityReport                      │
             │    │         {structure[], patterns[], tests[],     │
             │    │          edgeCases[], regressions[]}           │
             │    │                                                 │
             └──► Agent: Business Logic                            │
                  │ Input:  SharedContext                          │
                  │ Output: BusinessLogicReport                    │
                  │         {edgeCases[], assumptions[],           │
                  │          logicalGaps[], userFlowIssues[]}      │
                  │                                                 │
                  └──────────────┬─────────────────────────────────┘
                                 │
                  ┌──────────────▼──────────────────────────────┐
                  │   AGGREGATION LAYER                         │
                  │   • Collect all agent outputs               │
                  │   • Deduplicate findings                    │
                  │   • Classify by severity:                   │
                  │     - Critical (breaking, logic errors)     │
                  │     - NotImplemented (missing features)     │
                  │     - NiceToFix (improvements)              │
                  └──────────────┬──────────────────────────────┘
                                 │
                  ┌──────────────▼──────────────────────────────┐
                  │   STRUCTURED OUTPUT                         │
                  │   {                                         │
                  │     critical: Finding[],                    │
                  │     notImplemented: Finding[],              │
                  │     niceToFix: Finding[],                   │
                  │     metadata: {...}                         │
                  │   }                                         │
                  └──────────────┬──────────────────────────────┘
                                 │
                  ┌──────────────▼──────────────────────────────┐
                  │   POST-REVIEW ACTIONS (User-triggered)      │
                  │                                             │
                  │   [Create Plan to Fix Below Issues]         │
                  │   └──► Fix Planning Agent                   │
                  │         Generates step-by-step resolution   │
                  │                                             │
                  │   [Implement Below Issues in Agent Mode]    │
                  │   └──► Fix Implementation Agent             │
                  │         Applies code changes automatically  │
                  └─────────────────────────────────────────────┘
```

## Core Components

### 1. Shared Context Object

```typescript
interface SharedContext {
  branchName: string;
  projectCode: string;
  jiraId: string;
  gitDiff: string;
  changedFiles: string[];
  jiraDescription: string;
  metadata: {
    lastCommitHash: string;
    timestamp: string;
    cacheHit: boolean;
  };
}
```

All agents consume this immutable context instead of relying on implicit state.

### 2. Skills (Tool Layer)

Skills are **composable, single-purpose tools** with explicit contracts:

- **Git Branch Parser**: Extracts `$projectCode-$jiraId` from branch names
- **Git Diff Retriever**: Gets diff with filesystem caching
- **Jira Context**: Acquires Jira description (user prompt → extensible to API)

Each skill is a folder in `.github/skills/pr-review/` containing:
- `SKILL.md` - GitHub Copilot skill definition
- Implementation files (TypeScript)
- Tests and examples

### 3. Review Agents (Analysis Layer)

Specialized agents that analyze code and produce **structured reports**:

#### Requirement Coverage Agent
- Compares Jira description vs implementation
- Outputs: `{implemented[], partial[], missing[], improvements[]}`

#### Code Quality Agent
- Verifies project rules, patterns, test coverage
- Outputs: `{structure[], patterns[], tests[], edgeCases[], regressions[]}`

#### Business Logic Agent
- Evaluates from business/domain perspective
- Outputs: `{edgeCases[], assumptions[], logicalGaps[], userFlowIssues[]}`

All agents run **in parallel** for performance.

### 4. Aggregation Layer

Dedicated aggregation skill that:
- Collects all agent outputs
- Deduplicates findings (using content hash + similarity)
- Classifies by severity using strict rules

**Classification Rules:**
```typescript
Critical:
  - Breaking requirements
  - Incorrect business logic
  - Major security/data risks
  - Missing error handling in critical paths

NotImplemented:
  - Explicitly missing functionality from Jira
  - Required edge cases not covered
  - Specified requirements absent

NiceToFix:
  - Code style improvements
  - Performance optimizations
  - Non-blocking suggestions
  - Better naming/structure
```

### 5. Orchestrator Agent

The **master coordinator** responsible for:
- ✅ Executing skills in order
- ✅ Managing shared context lifecycle
- ✅ Spawning review agents in parallel
- ✅ Coordinating aggregation
- ✅ Failure handling with fallbacks
- ✅ Logging/observability

**Execution Flow:**
1. Parse branch → Extract Jira ID
2. Retrieve diff → Check cache
3. Acquire Jira description
4. Validate context → Handle failures
5. Spawn 3 review agents in parallel
6. Aggregate results → Classify severity
7. Return structured report
8. Offer post-review actions

### 6. Caching Mechanism

Filesystem-based cache to avoid recomputing diffs:

```typescript
Cache Key: {repo}-{branch}-{jiraId}-{lastCommitHash}
Location: .copilot/cache/pr-review/
Structure:
  {cacheKey}.json:
    {
      diff: string,
      changedFiles: string[],
      timestamp: string,
      commitHash: string
    }
```

Cache invalidation: automatic on new commits.

### 7. Failure Handling

Defined fallback behaviors:

| Failure Scenario | Behavior |
|-----------------|----------|
| Jira ID cannot be extracted | Ask user for Jira ID |
| Diff cannot be generated | Stop with explanation + diagnostics |
| Jira description missing | Block review until provided |
| Agent execution timeout | Continue with partial results + warning |
| Cache corruption | Clear cache + regenerate |

### 8. Observability

Built-in logging at decision points:

```typescript
interface LogEntry {
  timestamp: string;
  phase: 'skill' | 'agent' | 'aggregation' | 'orchestration';
  component: string;
  event: 'start' | 'complete' | 'error';
  data?: any;
}
```

Logs stored in `.copilot/logs/pr-review/{timestamp}.json`

## Output Format

Final structured output (JSON-serializable):

```json
{
  "metadata": {
    "branchName": "feature/C1234-43224-something",
    "jiraId": "C1234-43224",
    "timestamp": "2026-04-08T14:39:00Z",
    "reviewDuration": "12.5s"
  },
  "findings": {
    "critical": [
      {
        "id": "crit-001",
        "source": "business-logic-agent",
        "category": "incorrect-logic",
        "file": "src/components/Auth.tsx",
        "line": 45,
        "description": "Authentication bypass when userId is null",
        "recommendation": "Add null check before authentication"
      }
    ],
    "notImplemented": [
      {
        "id": "notimpl-001",
        "source": "requirement-coverage-agent",
        "requirement": "Password reset via email",
        "status": "missing",
        "priority": "high"
      }
    ],
    "niceToFix": [
      {
        "id": "nice-001",
        "source": "code-quality-agent",
        "category": "optimization",
        "file": "src/utils/validation.ts",
        "description": "Regex compiled on every call",
        "recommendation": "Extract to module-level constant"
      }
    ]
  },
  "summary": {
    "totalFindings": 3,
    "criticalCount": 1,
    "notImplementedCount": 1,
    "niceToFixCount": 1,
    "filesAnalyzed": 8,
    "testCoverage": "partial"
  },
  "actions": [
    {
      "label": "Create Plan to Fix Below Issues",
      "agentId": "fix-planning-agent",
      "description": "Generate step-by-step resolution plan"
    },
    {
      "label": "Implement Below Issues in Agent Mode",
      "agentId": "fix-implementation-agent",
      "description": "Apply code changes automatically"
    }
  ]
}
```

## Technology Stack

- **Language**: TypeScript (type safety + IDE support)
- **Skills**: GitHub Copilot SKILL.md format
- **Agent Communication**: Structured JSON messages
- **Caching**: Filesystem (JSON)
- **Execution**: Local VSCode environment (no cloud dependencies)

## Alignment with GitHub Copilot Principles

1. **Skills as Tools**: Each skill is a folder with `SKILL.md` + resources
2. **Autonomous Discovery**: Copilot auto-discovers skills based on descriptions
3. **Context Injection**: Skills loaded into context when relevant
4. **No Explicit Orchestration**: Orchestrator implemented as TypeScript coordinator
5. **Extensibility**: Skills can be added/removed independently

## Key Design Decisions

### Why TypeScript for Orchestration?
GitHub Copilot skills don't have built-in orchestration primitives. TypeScript provides:
- Type-safe context management
- Async/parallel execution control
- Deterministic error handling
- IDE integration

### Why Filesystem Caching?
- No external dependencies
- Works offline
- Fast cache lookups (<1ms)
- Easy cache invalidation

### Why Structured Outputs?
- Enables programmatic consumption
- Allows UI rendering
- Facilitates testing
- Ensures reproducibility

## Usage

```bash
# From VSCode Terminal or Copilot Chat
npm run pr-review

# Or trigger via Copilot:
@workspace Review this PR using the PR Review orchestration system
```

## Extension Points

1. **Custom Review Agents**: Add new agents in `.github/skills/pr-review/`
2. **Jira API Integration**: Replace user prompt with API calls
3. **CI/CD Integration**: Export JSON for GitHub Actions
4. **Custom Classification Rules**: Modify `aggregation/classifier.ts`
5. **Additional Caching Strategies**: Implement alternative cache backends

## Testing Strategy

- **Unit Tests**: Each skill + agent independently
- **Integration Tests**: End-to-end orchestration flow
- **Cache Tests**: Invalidation + corruption scenarios
- **Parallel Execution Tests**: Race condition verification

## Performance Targets

- Branch parsing: <10ms
- Diff retrieval (cached): <5ms
- Diff retrieval (uncached): <500ms
- Agent execution (parallel): <15s
- Aggregation: <100ms
- Total review time: <20s

## Security Considerations

- No credentials in cache
- Sanitize file paths
- Validate input branch names
- Rate limit Jira API calls (when implemented)
- Sandbox agent execution

## Limitations

1. **No Native Multi-Agent Orchestration**: GitHub Copilot doesn't expose multi-agent APIs, so orchestration is implemented in TypeScript
2. **Local Execution Only**: Requires local git repository and VSCode
3. **Manual Jira Input**: Initially requires user to provide Jira description
4. **Single Repository**: Designed for monorepo or single-repo workflows

## Future Enhancements

- [ ] Multi-repository support
- [ ] Jira REST API integration
- [ ] GitHub Actions integration
- [ ] Web UI for report visualization
- [ ] Historical trend analysis
- [ ] Custom rule engine
- [ ] Performance profiling dashboard
