---
name: code-quality-agent
description: Verifies code structure, patterns, test coverage, and identifies potential regressions.
license: MIT
allowed-tools:
  - bash
---

# Code Quality Agent

## Purpose

Analyzes code changes for adherence to project standards, design patterns, and best practices.

## Responsibilities

1. **Structure Analysis**: Code organization, modularity, naming conventions
2. **Pattern Compliance**: SOLID principles, design patterns, architectural consistency
3. **Test Coverage**: Presence and quality of tests, edge case coverage
4. **Regression Detection**: Changes that might break existing functionality

## Input

Consumes `SharedContext`:
- `gitDiff` - Code changes
- `changedFiles` - Modified files
- `jiraDescription` - Context for understanding intent

## Output

```typescript
{
  structure: Finding[];      // Code organization issues
  patterns: Finding[];       // Design pattern violations
  tests: TestCoverageItem[]; // Test coverage analysis
  edgeCases: Finding[];      // Missing edge case handling
  regressions: Finding[];    // Potential breaking changes
}
```

## Analysis Areas

### 1. Code Structure
- File/function length (flag functions >100 lines)
- Naming conventions (camelCase, PascalCase, descriptive names)
- Code duplication (DRY principle violations)
- Import organization

### 2. Design Patterns
- SOLID principles adherence
- Separation of concerns
- Single responsibility per component/function
- Proper abstraction levels

### 3. Test Coverage
- Unit tests for new functions/components
- Integration tests for feature flows
- Edge case testing
- Error path testing

### 4. Edge Cases
- Null/undefined handling
- Empty array/object handling
- Boundary conditions
- Error states

### 5. Regression Risks
- Changes to shared utilities
- Modifications to API contracts
- Database schema changes
- Breaking changes to public interfaces

## Severity Classification

Each finding includes initial severity (refined by aggregation layer):
- **Critical**: Security issues, data loss risks, breaking changes
- **NotImplemented**: Explicitly missing tests or error handling
- **NiceToFix**: Style, optimization, better naming

## Example Output

```json
{
  "structure": [
    {
      "id": "struct-001",
      "source": "code-quality-agent",
      "category": "function-length",
      "file": "src/utils/validation.ts",
      "line": 45,
      "description": "Function 'validateUserInput' is 150 lines long",
      "recommendation": "Extract sub-validators into separate functions",
      "severity": "niceToFix"
    }
  ],
  "patterns": [
    {
      "id": "pattern-001",
      "source": "code-quality-agent",
      "category": "solid-violation",
      "file": "src/components/UserProfile.tsx",
      "line": 30,
      "description": "Component handles both data fetching and rendering (SRP violation)",
      "recommendation": "Extract data fetching into custom hook",
      "severity": "niceToFix"
    }
  ],
  "tests": [
    {
      "file": "src/auth/Login.tsx",
      "testFile": "src/auth/Login.test.tsx",
      "coverage": "partial",
      "missingTests": [
        "Error state when API call fails",
        "Disabled submit button validation"
      ]
    },
    {
      "file": "src/auth/Logout.tsx",
      "coverage": "none",
      "missingTests": [
        "No test file found for Logout component"
      ]
    }
  ],
  "edgeCases": [
    {
      "id": "edge-001",
      "source": "code-quality-agent",
      "category": "null-handling",
      "file": "src/components/Avatar.tsx",
      "line": 12,
      "description": "No null check before accessing user.avatar.url",
      "recommendation": "Add optional chaining: user.avatar?.url",
      "severity": "critical"
    }
  ],
  "regressions": [
    {
      "id": "regress-001",
      "source": "code-quality-agent",
      "category": "api-change",
      "file": "src/api/endpoints.ts",
      "line": 67,
      "description": "Changed return type of getUserProfile from User to UserProfile",
      "recommendation": "Verify all call sites handle new type",
      "severity": "critical"
    }
  ]
}
```
