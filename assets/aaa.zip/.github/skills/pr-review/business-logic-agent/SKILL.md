---
name: business-logic-agent
description: Evaluates implementation from business/domain perspective, identifying logical gaps and incorrect assumptions.
license: MIT
allowed-tools:
  - bash
---

# Business Logic Agent

## Purpose

Analyzes code changes from a business domain perspective to identify logical flaws, incorrect assumptions, and user flow issues.

## Responsibilities

1. **Edge Case Identification**: Business scenarios not handled in code
2. **Assumption Validation**: Incorrect or unvalidated business assumptions
3. **Logical Gap Detection**: Missing business rules or incomplete flows
4. **User Flow Analysis**: Inconsistencies in user interaction patterns

## Input

Consumes `SharedContext`:
- `jiraDescription` - Business context and requirements
- `gitDiff` - Implementation code
- `changedFiles` - Modified components/services

## Output

```typescript
{
  edgeCases: Finding[];       // Missing business edge cases
  assumptions: Finding[];     // Potentially incorrect assumptions
  logicalGaps: Finding[];     // Incomplete business logic
  userFlowIssues: Finding[];  // User experience inconsistencies
}
```

## Analysis Approach

### 1. Edge Case Analysis
Simulate realistic business scenarios:
- What if user performs actions out of order?
- What if required data is missing?
- What if external services fail?
- What if concurrent users modify same data?

### 2. Assumption Validation
Challenge implicit assumptions:
- "Assumes email is always unique"
- "Assumes payment always succeeds"
- "Assumes user has permissions"
- "Assumes network is always available"

### 3. Logical Gap Detection
Identify missing business rules:
- State transitions not handled
- Required validations missing
- Incomplete error scenarios
- Missing authorization checks

### 4. User Flow Analysis
Verify user experience consistency:
- Can user recover from errors?
- Are loading states handled?
- Are success/failure messages clear?
- Is navigation consistent?

## Example Output

```json
{
  "edgeCases": [
    {
      "id": "edge-001",
      "source": "business-logic-agent",
      "category": "concurrent-modification",
      "file": "src/services/OrderService.ts",
      "line": 45,
      "description": "No handling for concurrent order modifications by multiple users",
      "recommendation": "Implement optimistic locking or version checks",
      "severity": "critical"
    },
    {
      "id": "edge-002",
      "source": "business-logic-agent",
      "category": "data-validation",
      "file": "src/components/CheckoutForm.tsx",
      "line": 89,
      "description": "No validation for maximum order quantity",
      "recommendation": "Add business rule: max 99 items per order",
      "severity": "notImplemented"
    }
  ],
  "assumptions": [
    {
      "id": "assume-001",
      "source": "business-logic-agent",
      "category": "implicit-assumption",
      "file": "src/auth/LoginService.ts",
      "line": 34,
      "description": "Assumes user.email is always populated, but can be null for SSO users",
      "recommendation": "Handle SSO users without email addresses",
      "severity": "critical"
    }
  ],
  "logicalGaps": [
    {
      "id": "gap-001",
      "source": "business-logic-agent",
      "category": "missing-rule",
      "file": "src/services/InventoryService.ts",
      "line": 67,
      "description": "No check for negative inventory after order cancellation",
      "recommendation": "Add validation: inventory cannot go negative",
      "severity": "critical"
    }
  ],
  "userFlowIssues": [
    {
      "id": "flow-001",
      "source": "business-logic-agent",
      "category": "error-recovery",
      "file": "src/components/PaymentForm.tsx",
      "line": 123,
      "description": "Payment failure doesn't provide retry option",
      "recommendation": "Add 'Try Again' button for failed payments",
      "severity": "niceToFix"
    }
  ]
}
```

## Severity Guidelines

- **Critical**: Data integrity risks, security issues, broken core flows
- **NotImplemented**: Business rules explicitly required but missing
- **NiceToFix**: UX improvements, better error messages, edge case refinements

## Realistic Scenario Simulation

Agent should mentally simulate:
- Normal flow (happy path)
- Error flows (all failure points)
- Edge cases (boundary conditions)
- Concurrent operations
- Missing/invalid data scenarios

## Performance Target

Execution time: <10 seconds (parallel with other agents)
