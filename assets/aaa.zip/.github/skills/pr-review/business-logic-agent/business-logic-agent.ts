/**
 * Business Logic Agent Implementation
 *
 * Evaluates implementation from business/domain perspective.
 * Production version would use LLM for deep semantic analysis.
 */

import type {
  SharedContext,
  BusinessLogicReport,
  Finding,
} from '../../../../src/agents/types/shared-context';

export async function analyzeBusinessLogic(
  context: SharedContext
): Promise<BusinessLogicReport> {
  const startTime = Date.now();

  try {
    const report: BusinessLogicReport = {
      edgeCases: await identifyEdgeCases(context),
      assumptions: await validateAssumptions(context),
      logicalGaps: await detectLogicalGaps(context),
      userFlowIssues: await analyzeUserFlows(context),
    };

    console.log(
      `[business-logic-agent] Analysis complete in ${Date.now() - startTime}ms`
    );

    return report;
  } catch (error) {
    console.error(`[business-logic-agent] Error: ${error}`);

    return {
      edgeCases: [],
      assumptions: [],
      logicalGaps: [],
      userFlowIssues: [],
    };
  }
}

async function identifyEdgeCases(context: SharedContext): Promise<Finding[]> {
  const findings: Finding[] = [];

  // Check for common missing edge cases
  const patterns = [
    {
      check: /\bemail\b/i,
      missing: /@/g,
      category: 'email-validation',
      description: 'Email field mentioned but no validation found',
      recommendation: 'Add email format validation',
    },
    {
      check: /\bdate\b|\btime\b/i,
      missing: /Invalid Date|isNaN/g,
      category: 'date-validation',
      description: 'Date/time handling without invalid date checks',
      recommendation: 'Validate date objects before use',
    },
    {
      check: /\bprice\b|\bamount\b|\bcost\b/i,
      missing: /parseFloat|Number/g,
      category: 'numeric-validation',
      description: 'Monetary values without numeric validation',
      recommendation: 'Validate and sanitize monetary amounts',
    },
  ];

  for (const pattern of patterns) {
    const hasCheck = pattern.check.test(context.gitDiff);
    const hasMissing = !pattern.missing.test(context.gitDiff);

    if (hasCheck && hasMissing) {
      findings.push({
        id: `edge-${generateId()}`,
        source: 'business-logic-agent',
        category: pattern.category,
        description: pattern.description,
        recommendation: pattern.recommendation,
        severity: 'critical',
      });
    }
  }

  // Check for concurrent modification handling
  if (
    context.gitDiff.includes('update') &&
    !context.gitDiff.includes('version') &&
    !context.gitDiff.includes('lock')
  ) {
    findings.push({
      id: `edge-${generateId()}`,
      source: 'business-logic-agent',
      category: 'concurrent-modification',
      description: 'Update operation without concurrency control',
      recommendation: 'Implement optimistic locking or version checks',
      severity: 'critical',
    });
  }

  return findings;
}

async function validateAssumptions(
  context: SharedContext
): Promise<Finding[]> {
  const findings: Finding[] = [];

  // Check for common implicit assumptions
  const assumptionPatterns = [
    {
      pattern: /\.email/g,
      assumption: 'Assumes email field always exists',
      recommendation:
        'Add null/undefined check or handle users without email',
    },
    {
      pattern: /\.length\s*>\s*0/g,
      assumption: 'Assumes array is never null/undefined',
      recommendation: 'Check array existence before accessing .length',
    },
    {
      pattern: /fetch\(|axios\./g,
      assumption: 'Assumes network calls always succeed',
      recommendation: 'Add timeout and error handling for network calls',
    },
    {
      pattern: /JSON\.parse/g,
      assumption: 'Assumes JSON is always valid',
      recommendation:
        'Wrap JSON.parse in try/catch to handle malformed data',
    },
  ];

  for (const ap of assumptionPatterns) {
    if (ap.pattern.test(context.gitDiff)) {
      findings.push({
        id: `assume-${generateId()}`,
        source: 'business-logic-agent',
        category: 'implicit-assumption',
        description: ap.assumption,
        recommendation: ap.recommendation,
        severity: 'critical',
      });
    }
  }

  return findings;
}

async function detectLogicalGaps(context: SharedContext): Promise<Finding[]> {
  const findings: Finding[] = [];

  // Check for missing business rules
  const businessRuleChecks = [
    {
      domain: /\bauth\b|\blogin\b/i,
      requiredPatterns: ['password', 'token', 'session'],
      missingRule: 'Authentication flow incomplete',
    },
    {
      domain: /\border\b|\bcheckout\b|\bpayment\b/i,
      requiredPatterns: ['validate', 'amount', 'confirm'],
      missingRule: 'Order processing flow incomplete',
    },
    {
      domain: /\bdelete\b|\bremove\b/i,
      requiredPatterns: ['confirm', 'authorization', 'permission'],
      missingRule: 'Delete operation lacks confirmation/authorization',
    },
  ];

  for (const check of businessRuleChecks) {
    if (check.domain.test(context.jiraDescription)) {
      const missingPatterns = check.requiredPatterns.filter(
        (p) => !new RegExp(p, 'i').test(context.gitDiff)
      );

      if (missingPatterns.length > 0) {
        findings.push({
          id: `gap-${generateId()}`,
          source: 'business-logic-agent',
          category: 'missing-rule',
          description: `${check.missingRule}: Missing ${missingPatterns.join(', ')}`,
          recommendation: `Implement missing business logic: ${missingPatterns.join(', ')}`,
          severity: 'notImplemented',
        });
      }
    }
  }

  // Check for state machine completeness
  if (context.gitDiff.includes('setState') || context.gitDiff.includes('status')) {
    if (!context.gitDiff.includes('switch') && !context.gitDiff.includes('case')) {
      findings.push({
        id: `gap-${generateId()}`,
        source: 'business-logic-agent',
        category: 'state-machine',
        description: 'State management without explicit state transitions',
        recommendation: 'Define clear state transition rules',
        severity: 'niceToFix',
      });
    }
  }

  return findings;
}

async function analyzeUserFlows(context: SharedContext): Promise<Finding[]> {
  const findings: Finding[] = [];

  // Check for user experience patterns
  const uxChecks = [
    {
      trigger: /submit|save|update/i,
      required: /loading|pending|disabled/i,
      issue: 'Form submission without loading state',
      recommendation: 'Add loading indicator during submission',
    },
    {
      trigger: /error|fail/i,
      required: /message|toast|alert/i,
      issue: 'Error handling without user notification',
      recommendation: 'Show error message to user',
    },
    {
      trigger: /success|complete/i,
      required: /message|redirect|navigate/i,
      issue: 'Success case without user feedback',
      recommendation: 'Show success message or redirect user',
    },
  ];

  for (const check of uxChecks) {
    if (check.trigger.test(context.gitDiff)) {
      if (!check.required.test(context.gitDiff)) {
        findings.push({
          id: `flow-${generateId()}`,
          source: 'business-logic-agent',
          category: 'user-feedback',
          description: check.issue,
          recommendation: check.recommendation,
          severity: 'niceToFix',
        });
      }
    }
  }

  // Check for error recovery options
  if (context.gitDiff.includes('catch') || context.gitDiff.includes('error')) {
    if (!context.gitDiff.includes('retry') && !context.gitDiff.includes('Try again')) {
      findings.push({
        id: `flow-${generateId()}`,
        source: 'business-logic-agent',
        category: 'error-recovery',
        description: 'Error handling without retry mechanism',
        recommendation: 'Consider adding retry option for transient failures',
        severity: 'niceToFix',
      });
    }
  }

  return findings;
}

function generateId(): string {
  return Math.random().toString(36).substring(2, 9);
}

/**
 * Production Enhancement:
 *
 * Use LLM for deep semantic analysis:
 *
 * async function analyzeWithLLM(context: SharedContext): Promise<BusinessLogicReport> {
 *   const prompt = `
 *     Analyze this code change from a business logic perspective:
 *
 *     Business Requirements:
 *     ${context.jiraDescription}
 *
 *     Code Changes:
 *     ${context.gitDiff}
 *
 *     Identify:
 *     1. Missing business edge cases
 *     2. Incorrect assumptions about business rules
 *     3. Logical gaps in implementation
 *     4. User flow inconsistencies
 *
 *     Return structured JSON with findings.
 *   `;
 *
 *   const response = await callLLM(prompt);
 *   return JSON.parse(response);
 * }
 *
 * Integrate with business domain models:
 * - Load domain-specific rules from configuration
 * - Validate against business constraints
 * - Check compliance with industry regulations
 */
