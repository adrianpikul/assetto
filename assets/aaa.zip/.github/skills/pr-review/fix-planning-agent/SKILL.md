---
name: fix-planning-agent
description: Generates step-by-step resolution plan for issues found during PR review.
license: MIT
---

# Fix Planning Agent

## Purpose

Creates actionable, prioritized plan to address all findings from PR review report.

## Input

Receives `AggregatedReviewReport` containing:
- Critical findings
- Not implemented requirements
- Nice-to-fix suggestions

## Output

```typescript
{
  plan: PlanStep[];
  estimatedEffort: string;
  priorityOrder: string[];
}

interface PlanStep {
  id: string;
  priority: 'high' | 'medium' | 'low';
  finding: Finding;
  action: string;
  files: string[];
  dependencies: string[];
  estimatedTime: string;
}
```

## Planning Strategy

### 1. Prioritization
Order fixes by impact:
1. **Critical**: Address immediately (security, data integrity)
2. **NotImplemented**: Complete missing requirements
3. **NiceToFix**: Improvements and optimizations

### 2. Dependency Analysis
Identify fix dependencies:
- Some fixes require others to be completed first
- Group related fixes together

### 3. Effort Estimation
Rough time estimates:
- Simple: <30min
- Medium: 30min-2h
- Complex: 2h+

## Example Output

```json
{
  "plan": [
    {
      "id": "step-1",
      "priority": "high",
      "finding": { /* critical finding */ },
      "action": "Add null check before accessing user.email property",
      "files": ["src/auth/Login.tsx"],
      "dependencies": [],
      "estimatedTime": "15 minutes"
    },
    {
      "id": "step-2",
      "priority": "high",
      "finding": { /* notImplemented */ },
      "action": "Implement password validation (min 8 characters, special char)",
      "files": ["src/auth/validation.ts", "src/auth/Login.tsx"],
      "dependencies": [],
      "estimatedTime": "45 minutes"
    }
  ],
  "estimatedEffort": "2-3 hours total",
  "priorityOrder": ["step-1", "step-2", "step-3", ..."]
}
```

## Usage

Triggered after PR review when user selects "Create Plan to Fix Below Issues".
