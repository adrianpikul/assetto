# PR Review System - Usage Guide

## Complete Walkthrough

This guide demonstrates how to use the PR Review Agent Orchestration System in a real development workflow.

## Prerequisites

1. **Git Repository**: Working in a local git repository
2. **Branch Convention**: Branch named as `{type}/{projectCode}-{issueId}-{description}`
3. **Commits**: At least one commit on your feature branch
4. **Node.js**: v18+ installed
5. **Dependencies**: Run `npm install` in project root

## Step-by-Step Usage

### Step 1: Set Up Your Feature Branch

```bash
# Create feature branch following naming convention
git checkout -b feature/C1234-43224-add-authentication

# Make your code changes
# ... edit files ...

# Commit your changes
git add .
git commit -m "C1234-43224: Implement JWT authentication"
```

### Step 2: Run PR Review

#### Option A: Command Line (Recommended)

```bash
# From project root
npm run pr-review
```

**What happens:**
1. System extracts Jira ID from branch name (`C1234-43224`)
2. Retrieves git diff (checks cache first)
3. Prompts you for Jira description:

```
============================================================
📋 Jira Context Required: C1234-43224
============================================================
Please provide the Jira issue description/requirements below.
(Enter a blank line when done)

```

4. You enter the requirements:

```
Implement user authentication with the following:
- Login with email and password
- Logout functionality
- Session management (24-hour expiry)
- Password validation (min 8 characters)

[Press Enter twice when done]
```

5. System runs 3 agents in parallel (~15s)
6. Displays comprehensive report

#### Option B: GitHub Copilot Chat

In VSCode Copilot Chat:

```
@workspace Review this PR using the PR Review orchestration system
```

Copilot will:
- Auto-discover the orchestrator skill
- Execute the review flow
- Display results in chat

#### Option C: Programmatic Usage

```typescript
// custom-review.ts
import { orchestrateReview } from './.github/skills/pr-review/orchestrator/orchestrator';

async function reviewMyPR() {
  const report = await orchestrateReview({
    repoPath: process.cwd(),
    baseBranch: 'main',
    skipCache: false,
  });

  if (report) {
    console.log('Review complete!');
    console.log(`Total findings: ${report.summary.totalFindings}`);
    
    // Process report programmatically
    if (report.summary.criticalCount > 0) {
      console.error('❌ Critical issues must be fixed before merge');
      process.exit(1);
    }
  }
}

reviewMyPR();
```

### Step 3: Review the Report

#### Console Output

```
======================================================================
📊 PR REVIEW REPORT
======================================================================

🏷️  Jira: C1234-43224
🌿 Branch: feature/C1234-43224-add-authentication
⏱️  Duration: 12.5s

📈 SUMMARY
   Total Findings: 8
   🔴 Critical: 2
   🟡 Not Implemented: 3
   🔵 Nice to Fix: 3
   📁 Files Analyzed: 5
   ✅ Test Coverage: partial

🔴 CRITICAL ISSUES
   1. No null check before accessing user.email property
      File: src/auth/Login.tsx:45
      → Add optional chaining: user.email?.

   2. Authentication flow missing error handling
      File: src/auth/AuthService.ts:67
      → Wrap API call in try/catch

🟡 NOT IMPLEMENTED
   1. Missing requirement: Password validation (min 8 characters)
      → Implement password validation from Jira requirements

   2. Missing requirement: Session management (24-hour expiry)
      → Add session expiry logic

   3. No tests found for Login.tsx
      → Add unit tests for new functionality

🔵 NICE TO FIX
   1. Console.log statement found (2 occurrences)
      → Remove debug logs before committing

   2. Function 'validateUserInput' is 150 lines long
      File: src/utils/validation.ts:45
      → Extract sub-validators into separate functions

   3. TypeScript "any" type used (3 occurrences)
      → Use specific types for better type safety

💡 NEXT ACTIONS
   1. Create Plan to Fix Below Issues
      Generate step-by-step resolution plan
   2. Implement Below Issues in Agent Mode
      Apply code changes automatically

======================================================================
Full report saved to: .copilot/logs/pr-review/
======================================================================
```

#### JSON Report

Full detailed report saved to:
`.copilot/reports/pr-review-C1234-43224-{timestamp}.json`

```json
{
  "metadata": { ... },
  "findings": {
    "critical": [ ... ],
    "notImplemented": [ ... ],
    "niceToFix": [ ... ]
  },
  "summary": { ... },
  "actions": [ ... ]
}
```

### Step 4: Address Findings

#### Option A: Manual Fixes

Review each finding and fix manually:

1. **Critical Issues First**
   ```typescript
   // Before (Critical)
   const email = user.email.toLowerCase();
   
   // After (Fixed)
   const email = user.email?.toLowerCase() ?? '';
   ```

2. **Implement Missing Requirements**
   ```typescript
   // Add password validation
   export function validatePassword(password: string): boolean {
     return password.length >= 8 && /[!@#$%^&*]/.test(password);
   }
   ```

3. **Add Missing Tests**
   ```typescript
   // Login.test.tsx
   describe('Login Component', () => {
     it('should handle null email gracefully', () => {
       // Test implementation
     });
   });
   ```

#### Option B: Use Fix Planning Agent

Generate a structured plan:

```bash
npm run pr-review-fix-plan
```

Output:
```json
{
  "plan": [
    {
      "id": "step-1",
      "priority": "high",
      "action": "Add null check for user.email",
      "files": ["src/auth/Login.tsx"],
      "estimatedTime": "10 minutes"
    },
    ...
  ],
  "estimatedEffort": "2-3 hours total"
}
```

#### Option C: Use Fix Implementation Agent

Auto-apply safe fixes:

```bash
# Dry run (show changes without applying)
npm run pr-review-fix --dry-run

# Interactive mode (review each change)
npm run pr-review-fix

# Auto-apply safe changes only
npm run pr-review-fix --auto-safe
```

### Step 5: Re-run Review

After fixes, run review again to verify:

```bash
npm run pr-review
```

Should show:
```
📈 SUMMARY
   Total Findings: 1  # Down from 8
   🔴 Critical: 0     # Fixed!
   🟡 Not Implemented: 0  # Complete!
   🔵 Nice to Fix: 1
```

### Step 6: Commit and Push

```bash
git add .
git commit -m "C1234-43224: Address PR review findings"
git push origin feature/C1234-43224-add-authentication
```

## Advanced Usage

### Caching

The system caches git diffs for performance:

```bash
# Cache location
ls .copilot/cache/pr-review/

# Clear cache manually
rm -rf .copilot/cache/pr-review/

# Disable cache for one run
npm run pr-review -- --skip-cache
```

Cache is automatically invalidated when:
- New commits are added
- Branch changes
- Manual cache clear

### Custom Base Branch

```bash
# Compare against develop instead of main
npm run pr-review -- --base-branch=develop
```

### Logs and Debugging

```bash
# View execution logs
cat .copilot/logs/pr-review/{timestamp}.json

# Logs include:
# - Skill execution timings
# - Agent outputs
# - Error traces
# - Decision points
```

### CI/CD Integration (Future)

```yaml
# .github/workflows/pr-review.yml
name: PR Review
on: pull_request

jobs:
  review:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v3
      - name: Run PR Review
        run: |
          npm install
          npm run pr-review
      - name: Upload Report
        uses: actions/upload-artifact@v3
        with:
          name: pr-review-report
          path: .copilot/reports/
```

## Troubleshooting

### "Could not extract Jira ID"

**Problem**: Branch name doesn't match convention

**Solutions**:
1. Rename branch: `git branch -m feature/C1234-43224-my-feature`
2. Manually provide Jira ID when prompted
3. Update branch patterns in `git-branch-parser.ts`

### "Empty git diff"

**Problem**: No changes detected

**Solutions**:
1. Ensure commits exist: `git log`
2. Check base branch: `git merge-base HEAD origin/main`
3. Force cache clear: `npm run pr-review -- --skip-cache`

### "Agent timeout"

**Problem**: Review taking too long (>30s)

**Solutions**:
1. Increase timeout: `export PR_REVIEW_TIMEOUT=60000`
2. Check diff size: `git diff --stat origin/main`
3. Review large diffs manually

### "Jira description required"

**Problem**: System needs requirements context

**Solution**: Provide Jira description when prompted. Format:
```
Implement feature X with:
- Requirement 1
- Requirement 2
- Edge case handling

Acceptance criteria:
- Unit tests
- Error handling
```

## Best Practices

### 1. Run Early and Often

```bash
# Run review before creating PR
git checkout -b feature/PROJ-123-my-feature
# ... make changes ...
git commit -m "PROJ-123: Initial implementation"
npm run pr-review  # Review early!
# ... fix issues ...
# ... push and create PR ...
```

### 2. Use Descriptive Jira Descriptions

Good:
```
Implement user authentication with JWT tokens.
Requirements:
- Login endpoint with email/password
- Token generation (24h expiry)
- Logout endpoint
- Password validation (min 8 chars, 1 special char)
Error handling:
- Invalid credentials → 401
- Missing fields → 400
```

Poor:
```
Add authentication
```

### 3. Review Critical Issues Immediately

Don't merge PRs with Critical findings unless explicitly justified.

### 4. Iterative Improvement

First run: 15 findings
Fix critical: 8 findings
Fix not-implemented: 3 findings
Final: 3 nice-to-fix (acceptable)

### 5. Save Reports for Documentation

```bash
# Archive reports for future reference
mkdir docs/pr-reviews/
cp .copilot/reports/*.json docs/pr-reviews/
```

## Integration with Development Workflow

```
┌─────────────────────────────────────────────────────────┐
│ 1. Create Feature Branch                                 │
│    git checkout -b feature/PROJ-123-my-feature          │
└──────────────────┬──────────────────────────────────────┘
                   │
┌──────────────────▼──────────────────────────────────────┐
│ 2. Implement Feature                                     │
│    - Write code                                          │
│    - Add tests                                           │
│    - Commit changes                                      │
└──────────────────┬──────────────────────────────────────┘
                   │
┌──────────────────▼──────────────────────────────────────┐
│ 3. Run PR Review                                         │
│    npm run pr-review                                     │
└──────────────────┬──────────────────────────────────────┘
                   │
           ┌───────┴────────┐
           │                │
    ┌──────▼─────┐   ┌─────▼──────┐
    │  Findings  │   │  Clean PR  │
    │  Detected  │   │  ✅        │
    └──────┬─────┘   └─────┬──────┘
           │                │
    ┌──────▼─────┐          │
    │ Fix Issues │          │
    └──────┬─────┘          │
           │                │
           └────────┬───────┘
                    │
         ┌──────────▼──────────┐
         │ 4. Push & Create PR │
         └─────────────────────┘
```

## Keyboard Shortcuts (VSCode)

```json
// Add to .vscode/keybindings.json
[
  {
    "key": "ctrl+shift+r",
    "command": "workbench.action.terminal.sendSequence",
    "args": { "text": "npm run pr-review\n" }
  }
]
```

Now `Ctrl+Shift+R` runs PR review instantly!

## FAQ

**Q: How long does a review take?**
A: Typically 10-20 seconds for most PRs.

**Q: Does it work offline?**
A: Yes! All processing is local (except future Jira API).

**Q: Can I customize severity rules?**
A: Yes, edit `aggregation/aggregation.ts` → `determineSeverity()`

**Q: Does it support other languages?**
A: Currently optimized for TypeScript/JavaScript. Python/Java support planned.

**Q: Can I skip certain checks?**
A: Yes, modify individual agent logic or disable agents in orchestrator.

---

**Need help?** Open an issue or see [README.md](./README.md) for more details.
