---
name: git-branch-parser
description: Extracts project code and Jira ID from git branch names. Handles formats like feature/C1234-43224-description, bug/C1234-43224-fix, etc.
license: MIT
allowed-tools:
  - bash
---

# Git Branch Parser Skill

## Purpose

Extracts structured information from git branch names following the convention:
`{prefix}/{projectCode}-{jiraId}-{description}`

## Supported Formats

- `feature/C1234-43224-something-to-do`
- `bug/C1234-43224-fix-issue`
- `hotfix/C1234-43224-critical-fix`
- `refactor/C1234-43224-cleanup-code`
- `C1234-43224-direct-format` (no prefix)

## Input

- Current git branch name

## Output

```json
{
  "projectCode": "C1234",
  "jiraId": "C1234-43224",
  "branchName": "feature/C1234-43224-something-to-do",
  "branchType": "feature"
}
```

## Usage

When PR review is requested, this skill is activated first to extract Jira context from the branch name.

## Error Handling

If no valid Jira ID is found:
1. Returns error with `code: "JIRA_ID_NOT_FOUND"`
2. Orchestrator prompts user for Jira ID
3. Review continues with user-provided ID

## Implementation

See `git-branch-parser.ts` for TypeScript implementation.

## Examples

### Example 1: Feature Branch
Input: `feature/C1234-43224-add-authentication`
Output:
```json
{
  "projectCode": "C1234",
  "jiraId": "C1234-43224",
  "branchName": "feature/C1234-43224-add-authentication",
  "branchType": "feature"
}
```

### Example 2: Bug Fix
Input: `bug/PROJ-123-fix-login`
Output:
```json
{
  "projectCode": "PROJ",
  "jiraId": "PROJ-123",
  "branchName": "bug/PROJ-123-fix-login",
  "branchType": "bug"
}
```

### Example 3: No Prefix
Input: `C1234-43224-direct-implementation`
Output:
```json
{
  "projectCode": "C1234",
  "jiraId": "C1234-43224",
  "branchName": "C1234-43224-direct-implementation",
  "branchType": "unknown"
}
```
