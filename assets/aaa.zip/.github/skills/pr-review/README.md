# PR Review Agent Orchestration System

> Production-grade, multi-agent PR review system for local VSCode + GitHub Copilot environments

## Overview

This system provides automated, comprehensive PR review through orchestrated collaboration between specialized AI agents. It analyzes code changes against business requirements, verifies code quality, and evaluates business logic correctness.

## ✨ Features

- **🎯 Intelligent Context Acquisition**: Extracts Jira ID from branch names, retrieves diffs with caching
- **🤖 Multi-Agent Analysis**: Parallel execution of specialized review agents
- **📊 Deterministic Outputs**: Structured JSON reports, not free-form text
- **⚡ Performance Optimized**: Filesystem caching, parallel execution (<20s total)
- **🔍 Comprehensive Coverage**: Requirements, code quality, business logic analysis
- **🎚️ Severity Classification**: Critical, NotImplemented, NiceToFix categorization
- **🔄 Post-Review Actions**: Fix planning and implementation agents
- **📝 Full Observability**: Execution logs, performance metrics, error traces

## 🏗️ Architecture

```
Orchestrator
├── Context Acquisition (Sequential)
│   ├── Git Branch Parser → Extract Jira ID
│   ├── Git Diff Retriever → Get changes (cached)
│   └── Jira Context → Get requirements
├── Review Agents (Parallel)
│   ├── Requirement Coverage Agent
│   ├── Code Quality Agent
│   └── Business Logic Agent
├── Aggregation Layer
│   ├── Collect findings
│   ├── Deduplicate
│   └── Classify by severity
└── Post-Review Actions
    ├── Fix Planning Agent
    └── Fix Implementation Agent
```

See [ARCHITECTURE.md](./ARCHITECTURE.md) for detailed design.

## 🚀 Quick Start

### Installation

```bash
# Clone repository
cd /c/projects/copilotAgents

# Install dependencies
npm install

# Compile TypeScript
npm run build
```

### Usage

#### Option 1: Command Line

```bash
# Run PR review on current branch
npm run pr-review

# With custom options
npm run pr-review -- --base-branch=develop
```

#### Option 2: GitHub Copilot Chat

```
@workspace Review this PR using the PR Review orchestration system
```

Copilot will:
1. Auto-discover skills based on descriptions
2. Execute orchestrator
3. Return structured report

#### Option 3: Programmatic

```typescript
import { orchestrateReview } from './.github/skills/pr-review/orchestrator/orchestrator';

const report = await orchestrateReview({
  repoPath: '/path/to/repo',
  baseBranch: 'main',
  skipCache: false,
});

console.log(report);
```

## 📋 Requirements

- **Branch Naming Convention**: `{prefix}/{projectCode}-{issueId}-{description}`
  - Examples: `feature/C1234-43224-add-auth`, `bug/PROJ-123-fix-login`
- **Git Repository**: Local git repository with commits
- **Node.js**: v18+ (for TypeScript execution)
- **TypeScript**: v5+ (included in devDependencies)

## 🔧 Configuration

### Environment Variables

```bash
# Optional: Customize cache/log directories
export PR_REVIEW_CACHE_DIR=".copilot/cache/pr-review"
export PR_REVIEW_LOG_DIR=".copilot/logs/pr-review"
export PR_REVIEW_TIMEOUT="30000"  # 30 seconds

# Future: Jira API integration
export JIRA_BASE_URL="https://your-domain.atlassian.net"
export JIRA_AUTH_TOKEN="your-api-token"
export JIRA_PROJECT_KEY="C1234"
```

### Skills Configuration

All skills auto-discovered from `.github/skills/pr-review/`:
- `git-branch-parser/`
- `git-diff-retriever/`
- `jira-context/`
- `requirement-coverage-agent/`
- `code-quality-agent/`
- `business-logic-agent/`
- `aggregation/`
- `orchestrator/`
- `fix-planning-agent/`
- `fix-implementation-agent/`

## 📊 Output Format

### Console Summary

```
======================================================================
📊 PR REVIEW REPORT
======================================================================

🏷️  Jira: C1234-43224
🌿 Branch: feature/C1234-43224-add-authentication
⏱️  Duration: 12.5s

📈 SUMMARY
   Total Findings: 8
   🔴 Critical: 2
   🟡 Not Implemented: 3
   🔵 Nice to Fix: 3
   📁 Files Analyzed: 5
   ✅ Test Coverage: partial

🔴 CRITICAL ISSUES
   1. No null check before accessing user.email property
      File: src/auth/Login.tsx:45
      → Add optional chaining: user.email?.

💡 NEXT ACTIONS
   1. Create Plan to Fix Below Issues
      Generate step-by-step resolution plan
   2. Implement Below Issues in Agent Mode
      Apply code changes automatically
======================================================================
```

### JSON Report

Full report saved to `.copilot/reports/pr-review-{jiraId}-{timestamp}.json`:

```json
{
  "metadata": {
    "branchName": "feature/C1234-43224-add-auth",
    "jiraId": "C1234-43224",
    "timestamp": "2026-04-08T14:39:00Z",
    "reviewDuration": "12.5s"
  },
  "findings": {
    "critical": [...],
    "notImplemented": [...],
    "niceToFix": [...]
  },
  "summary": {
    "totalFindings": 8,
    "criticalCount": 2,
    "notImplementedCount": 3,
    "niceToFixCount": 3,
    "filesAnalyzed": 5,
    "testCoverage": "partial"
  },
  "actions": [...]
}
```

## 🎯 Review Agents

### 1. Requirement Coverage Agent
- Extracts requirements from Jira description
- Verifies implementation completeness
- Identifies missing/partial functionality
- **Output**: `{implemented[], partial[], missing[], improvements[]}`

### 2. Code Quality Agent
- Analyzes code structure and patterns
- Verifies test coverage
- Identifies potential regressions
- Checks for edge case handling
- **Output**: `{structure[], patterns[], tests[], edgeCases[], regressions[]}`

### 3. Business Logic Agent
- Evaluates from business perspective
- Identifies logical gaps
- Validates assumptions
- Analyzes user flows
- **Output**: `{edgeCases[], assumptions[], logicalGaps[], userFlowIssues[]}`

## 🎨 Severity Classification

### 🔴 Critical
- Breaking requirements
- Incorrect business logic
- Security vulnerabilities
- Data integrity risks
- Regression in shared utilities

### 🟡 Not Implemented
- Missing Jira requirements
- Incomplete features
- Missing tests
- Required edge cases not covered

### 🔵 Nice to Fix
- Code style improvements
- Performance optimizations
- Better naming/structure
- UX enhancements (non-critical)

## 🚦 Failure Handling

| Scenario | Behavior |
|----------|----------|
| Jira ID not found | Prompt user for Jira ID |
| Empty git diff | Stop with explanation |
| Missing Jira description | Block until provided |
| Agent timeout | Continue with partial results + warning |
| Cache corruption | Clear cache + regenerate |

## 🔄 Post-Review Actions

### Fix Planning Agent
Generates step-by-step resolution plan:
- Prioritizes fixes by severity
- Estimates effort
- Identifies dependencies

**Trigger**: User selects "Create Plan to Fix Below Issues"

### Fix Implementation Agent
Automatically applies code changes:
- Generates fixes for identified issues
- Interactive approval mode
- Runs tests after changes
- Creates git commits

**Trigger**: User selects "Implement Below Issues in Agent Mode"

## 📈 Performance

- **Branch parsing**: <10ms
- **Diff retrieval (cached)**: <5ms
- **Diff retrieval (uncached)**: <500ms
- **Agent execution (parallel)**: <15s
- **Aggregation**: <100ms
- **Total review time**: <20s

## 🧪 Testing

```bash
# Run unit tests
npm test

# Test individual skills
npm test -- --grep="git-branch-parser"

# Integration test
npm run test:integration
```

## 🐛 Troubleshooting

### "Could not extract Jira ID from branch"
- Ensure branch follows naming convention
- Manually provide Jira ID when prompted

### "Empty git diff"
- Ensure you have commits on the branch
- Check that branch differs from base branch

### "Cache corruption detected"
- Cache automatically cleared
- Diff regenerated from git

### "Agent timeout"
- Increase timeout: `PR_REVIEW_TIMEOUT=60000`
- Check for very large diffs

## 🛣️ Roadmap

- [ ] Jira REST API integration
- [ ] Multi-repository support
- [ ] GitHub Actions integration
- [ ] Web UI for report visualization
- [ ] Custom classification rules engine
- [ ] Historical trend analysis
- [ ] Performance profiling dashboard
- [ ] Support for other issue trackers (Linear, Asana)

## 📚 Documentation

- [Architecture](./ARCHITECTURE.md) - System design and patterns
- [Skills](./*/SKILL.md) - Individual skill documentation
- [API Reference](./docs/API.md) - TypeScript interfaces (coming soon)

## 🤝 Contributing

1. Follow existing skill structure
2. Add comprehensive SKILL.md for new skills
3. Include TypeScript types
4. Add unit tests
5. Update this README

## 📄 License

MIT

## 🙋 Support

- GitHub Issues: Report bugs or request features
- Documentation: See individual SKILL.md files
- Examples: Check `examples/` directory

---

**Built with ❤️ for better code reviews**
