---
name: pr-review-orchestrator
description: Main coordinator for PR review system. Manages execution flow, parallel agent spawning, context management, and error handling.
license: MIT
allowed-tools:
  - bash
---

# PR Review Orchestrator

## Purpose

The orchestrator is the master coordinator that manages the entire PR review workflow, from context acquisition through final report generation.

## Execution Flow

```
1. Initialization
   ├─> Initialize logger
   ├─> Initialize cache
   └─> Start timing

2. Context Acquisition (Sequential)
   ├─> Parse branch name → Extract Jira ID
   ├─> Retrieve git diff (check cache first)
   └─> Acquire Jira description (user prompt)

3. Context Validation
   ├─> Validate all required fields
   ├─> Handle failures with fallbacks
   └─> Build SharedContext object

4. Parallel Review Execution
   ├─> Spawn Requirement Coverage Agent ─┐
   ├─> Spawn Code Quality Agent ─────────┼─> Run in parallel
   └─> Spawn Business Logic Agent ───────┘

5. Aggregation
   ├─> Collect all agent reports
   ├─> Deduplicate findings
   ├─> Classify by severity
   └─> Generate summary

6. Finalization
   ├─> Persist logs
   ├─> Return structured report
   └─> Display post-review actions
```

## Responsibilities

### 1. Skill Execution
Execute skills in correct order:
- Sequential for dependencies (branch → diff → Jira)
- Validate outputs before proceeding

### 2. Context Management
- Create immutable SharedContext
- Pass context to all agents
- Ensure context consistency

### 3. Parallel Agent Spawning
```typescript
// Execute agents in parallel for performance
const [reqCoverage, codeQuality, businessLogic] = await Promise.all([
  analyzeRequirementCoverage(context),
  analyzeCodeQuality(context),
  analyzeBusinessLogic(context),
]);
```

### 4. Error Handling
Implement fallback strategies:

| Error | Fallback |
|-------|----------|
| Jira ID not found | Prompt user for Jira ID |
| Empty diff | Stop with explanation |
| Jira description missing | Block until provided |
| Agent timeout | Continue with partial results + warning |
| Cache corruption | Clear + regenerate |

### 5. Observability
Log all decision points:
- Skill start/complete/error
- Agent spawn/complete/error
- Aggregation timing
- Final report generation

## Input

```typescript
{
  repoPath?: string;        // Default: current directory
  baseBranch?: string;      // Default: "main"
  skipCache?: boolean;      // Default: false
}
```

## Output

Returns `AggregatedReviewReport` (structured JSON)

## Usage

```bash
# From command line
npm run pr-review

# Programmatic
import { orchestrateReview } from './orchestrator';
const report = await orchestrateReview({ repoPath: '/path/to/repo' });
```

## Performance Targets

- Total execution: <20s
- Context acquisition: <1s (cached diff)
- Parallel review: <15s (all agents)
- Aggregation: <100ms

## Error Recovery

### Transient Errors
- Retry with exponential backoff
- Max 3 retries

### Fatal Errors
- Log error with full context
- Return partial report if possible
- Guide user on next steps

## Configuration

Optional environment variables:
```bash
PR_REVIEW_CACHE_DIR=".copilot/cache/pr-review"
PR_REVIEW_LOG_DIR=".copilot/logs/pr-review"
PR_REVIEW_TIMEOUT="30000"  # 30 seconds
```

## State Management

Orchestrator maintains execution state:
```typescript
{
  phase: 'initialization' | 'context-acquisition' | 'validation' |
         'parallel-review' | 'aggregation' | 'finalization' | 'error',
  logs: LogEntry[],
  errors: SkillError[],
  startTime: number
}
```

## Integration with GitHub Copilot

When triggered via Copilot:
```
@workspace Review this PR using the PR Review orchestration system
```

Copilot will:
1. Detect relevant skills based on descriptions
2. Load orchestrator skill
3. Execute orchestration flow
4. Return structured report to user
