/**
 * PR Review Orchestrator Implementation
 *
 * Main coordinator for the entire PR review workflow.
 */

import { execSync } from 'child_process';
import type {
  SharedContext,
  AggregatedReviewReport,
  OrchestrationContext,
  OrchestratorPhase,
} from '../../../../src/agents/types/shared-context';
import { Logger, defaultLogger } from '../../../../src/agents/utils/logger';
import { parseBranchName } from '../git-branch-parser/git-branch-parser';
import { retrieveGitDiff } from '../git-diff-retriever/git-diff-retriever';
import { acquireJiraContext } from '../jira-context/jira-context';
import { analyzeRequirementCoverage } from '../requirement-coverage-agent/requirement-coverage-agent';
import { analyzeCodeQuality } from '../code-quality-agent/code-quality-agent';
import { analyzeBusinessLogic } from '../business-logic-agent/business-logic-agent';
import { aggregateFindings, type AgentReports } from '../aggregation/aggregation';

export interface OrchestratorConfig {
  repoPath?: string;
  baseBranch?: string;
  skipCache?: boolean;
  logger?: Logger;
}

/**
 * Main orchestration entry point
 */
export async function orchestrateReview(
  config: OrchestratorConfig = {}
): Promise<AggregatedReviewReport | null> {
  const startTime = Date.now();
  const logger = config.logger || defaultLogger;
  const repoPath = config.repoPath || process.cwd();
  const baseBranch = config.baseBranch || 'main';

  // Initialize orchestration context
  const orchContext: OrchestrationContext = {
    phase: 'initialization',
    logs: [],
    errors: [],
    startTime,
  };

  try {
    await logger.initialize();
    logger.orchestration('Starting PR review orchestration', 'start');

    // Phase 1: Context Acquisition
    orchContext.phase = 'context-acquisition';
    const context = await acquireContext(repoPath, baseBranch, logger, config);

    if (!context) {
      logger.orchestration('Context acquisition failed', 'error');
      return null;
    }

    // Phase 2: Context Validation
    orchContext.phase = 'context-validation';
    const validationError = validateContext(context);

    if (validationError) {
      logger.orchestration(`Validation failed: ${validationError}`, 'error');
      console.error(`❌ Context validation failed: ${validationError}`);
      return null;
    }

    logger.orchestration('Context validated successfully', 'complete');

    // Phase 3: Parallel Review Execution
    orchContext.phase = 'parallel-review';
    logger.orchestration('Starting parallel agent execution', 'start');

    const reports = await executeReviewAgents(context, logger);

    logger.orchestration('All agents completed', 'complete');

    // Phase 4: Aggregation
    orchContext.phase = 'aggregation';
    logger.aggregation('start', { findingsCount: 'calculating' });

    const finalReport = await aggregateFindings(context, reports, startTime);

    logger.aggregation('complete', {
      totalFindings: finalReport.summary.totalFindings,
      critical: finalReport.summary.criticalCount,
      notImplemented: finalReport.summary.notImplementedCount,
      niceToFix: finalReport.summary.niceToFixCount,
    });

    // Phase 5: Finalization
    orchContext.phase = 'finalization';
    await logger.flush();

    logger.orchestration(
      `Review complete in ${finalReport.metadata.reviewDuration}`,
      'complete'
    );

    // Display report summary
    displayReportSummary(finalReport);

    return finalReport;
  } catch (error) {
    orchContext.phase = 'error';
    logger.orchestration(`Fatal error: ${error}`, 'error', error);
    console.error('❌ Fatal error during review:', error);
    await logger.flush();
    return null;
  }
}

/**
 * Phase 1: Acquire context (sequential execution)
 */
async function acquireContext(
  repoPath: string,
  baseBranch: string,
  logger: Logger,
  config: OrchestratorConfig
): Promise<SharedContext | null> {
  try {
    // Step 1: Get current branch
    logger.skill('git-branch-parser', 'start');

    const branchName = execSync('git branch --show-current', {
      cwd: repoPath,
      encoding: 'utf-8',
    }).trim();

    // Step 2: Parse branch name
    const parseResult = await parseBranchName(branchName);

    if (!parseResult.success || !parseResult.data) {
      logger.skill('git-branch-parser', 'error', parseResult.error);

      // Fallback: Ask user for Jira ID
      console.log(
        `\n⚠️  Could not extract Jira ID from branch: ${branchName}`
      );
      console.log('Please enter the Jira ID manually (e.g., C1234-43224): ');

      // In production, implement user input
      // For now, return null to indicate failure
      return null;
    }

    logger.skill('git-branch-parser', 'complete', parseResult.data);

    // Step 3: Retrieve git diff
    logger.skill('git-diff-retriever', 'start');

    const diffResult = await retrieveGitDiff({
      jiraId: parseResult.data.jiraId,
      branchName,
      baseBranch,
      repoPath,
    });

    if (!diffResult.success || !diffResult.data) {
      logger.skill('git-diff-retriever', 'error', diffResult.error);
      console.error(`❌ Failed to retrieve git diff: ${diffResult.error?.message}`);
      return null;
    }

    logger.skill('git-diff-retriever', 'complete', {
      cacheHit: diffResult.data.cacheHit,
      filesChanged: diffResult.data.changedFiles.length,
    });

    // Step 4: Acquire Jira context
    logger.skill('jira-context', 'start');

    const jiraResult = await acquireJiraContext({
      jiraId: parseResult.data.jiraId,
    });

    if (!jiraResult.success || !jiraResult.data) {
      logger.skill('jira-context', 'error', jiraResult.error);
      console.error(`❌ Failed to acquire Jira context: ${jiraResult.error?.message}`);
      return null;
    }

    logger.skill('jira-context', 'complete', { source: jiraResult.data.source });

    // Build SharedContext
    const context: SharedContext = {
      branchName,
      projectCode: parseResult.data.projectCode,
      jiraId: parseResult.data.jiraId,
      gitDiff: diffResult.data.diff,
      changedFiles: diffResult.data.changedFiles,
      jiraDescription: jiraResult.data.description,
      metadata: {
        lastCommitHash: diffResult.data.commitHash,
        timestamp: new Date().toISOString(),
        cacheHit: diffResult.data.cacheHit,
        baseBranch,
        repoPath,
      },
    };

    return context;
  } catch (error) {
    logger.orchestration('Context acquisition error', 'error', error);
    return null;
  }
}

/**
 * Phase 2: Validate context
 */
function validateContext(context: SharedContext): string | null {
  if (!context.jiraId) return 'Missing Jira ID';
  if (!context.gitDiff || context.gitDiff.trim().length === 0)
    return 'Empty git diff';
  if (!context.jiraDescription || context.jiraDescription.trim().length === 0)
    return 'Missing Jira description';
  if (context.changedFiles.length === 0) return 'No changed files detected';

  return null;
}

/**
 * Phase 3: Execute review agents in parallel
 */
async function executeReviewAgents(
  context: SharedContext,
  logger: Logger
): Promise<AgentReports> {
  // Spawn all agents in parallel
  const [requirementCoverage, codeQuality, businessLogic] = await Promise.all([
    (async () => {
      logger.agent('requirement-coverage-agent', 'start');
      const result = await analyzeRequirementCoverage(context);
      logger.agent('requirement-coverage-agent', 'complete', {
        implemented: result.implemented.length,
        partial: result.partial.length,
        missing: result.missing.length,
      });
      return result;
    })(),

    (async () => {
      logger.agent('code-quality-agent', 'start');
      const result = await analyzeCodeQuality(context);
      logger.agent('code-quality-agent', 'complete', {
        structure: result.structure.length,
        patterns: result.patterns.length,
        tests: result.tests.length,
      });
      return result;
    })(),

    (async () => {
      logger.agent('business-logic-agent', 'start');
      const result = await analyzeBusinessLogic(context);
      logger.agent('business-logic-agent', 'complete', {
        edgeCases: result.edgeCases.length,
        assumptions: result.assumptions.length,
        logicalGaps: result.logicalGaps.length,
      });
      return result;
    })(),
  ]);

  return {
    requirementCoverage,
    codeQuality,
    businessLogic,
  };
}

/**
 * Display report summary to console
 */
function displayReportSummary(report: AggregatedReviewReport): void {
  console.log('\n' + '='.repeat(70));
  console.log('📊 PR REVIEW REPORT');
  console.log('='.repeat(70));
  console.log(`\n🏷️  Jira: ${report.metadata.jiraId}`);
  console.log(`🌿 Branch: ${report.metadata.branchName}`);
  console.log(`⏱️  Duration: ${report.metadata.reviewDuration}`);

  console.log('\n📈 SUMMARY');
  console.log(`   Total Findings: ${report.summary.totalFindings}`);
  console.log(`   🔴 Critical: ${report.summary.criticalCount}`);
  console.log(`   🟡 Not Implemented: ${report.summary.notImplementedCount}`);
  console.log(`   🔵 Nice to Fix: ${report.summary.niceToFixCount}`);
  console.log(`   📁 Files Analyzed: ${report.summary.filesAnalyzed}`);
  console.log(`   ✅ Test Coverage: ${report.summary.testCoverage}`);

  if (report.findings.critical.length > 0) {
    console.log('\n🔴 CRITICAL ISSUES');
    report.findings.critical.forEach((f, i) => {
      console.log(`   ${i + 1}. ${f.description}`);
      if (f.file) console.log(`      File: ${f.file}${f.line ? `:${f.line}` : ''}`);
      if (f.recommendation) console.log(`      → ${f.recommendation}`);
    });
  }

  if (report.findings.notImplemented.length > 0) {
    console.log('\n🟡 NOT IMPLEMENTED');
    report.findings.notImplemented.forEach((f, i) => {
      console.log(`   ${i + 1}. ${f.description}`);
      if (f.recommendation) console.log(`      → ${f.recommendation}`);
    });
  }

  console.log('\n💡 NEXT ACTIONS');
  report.actions.forEach((action, i) => {
    console.log(`   ${i + 1}. ${action.label}`);
    console.log(`      ${action.description}`);
  });

  console.log('\n' + '='.repeat(70));
  console.log('Full report saved to: .copilot/logs/pr-review/');
  console.log('='.repeat(70) + '\n');
}

/**
 * Export for CLI usage
 */
if (require.main === module) {
  (async () => {
    const report = await orchestrateReview();

    if (report) {
      // Write full report to file
      const fs = require('fs/promises');
      const path = require('path');

      const outputDir = '.copilot/reports';
      await fs.mkdir(outputDir, { recursive: true });

      const outputFile = path.join(
        outputDir,
        `pr-review-${report.metadata.jiraId}-${Date.now()}.json`
      );

      await fs.writeFile(outputFile, JSON.stringify(report, null, 2));

      console.log(`\n✅ Full report written to: ${outputFile}\n`);
      process.exit(0);
    } else {
      process.exit(1);
    }
  })();
}
