---
name: fix-implementation-agent
description: Automatically applies code changes to fix issues identified in PR review report.
license: MIT
allowed-tools:
  - bash
---

# Fix Implementation Agent

## Purpose

Automatically generates and applies code changes to address findings from PR review.

## Input

Receives:
- `AggregatedReviewReport` with findings
- `SharedContext` with original diff and files

## Capabilities

### 1. Code Generation
Generates fixes for:
- Missing null checks
- Input validation
- Error handling
- Test files

### 2. File Modification
- Reads existing files
- Applies changes preserving style
- Maintains formatting consistency

### 3. Test Generation
- Creates missing test files
- Adds test cases for edge cases
- Ensures coverage for new code

## Execution Strategy

### Interactive Mode (Recommended)
1. Show proposed changes for each finding
2. Ask user for confirmation
3. Apply approved changes
4. Run tests after each change

### Automatic Mode (Dangerous)
1. Apply all non-breaking changes
2. Create git commit for each change
3. Run full test suite at end

## Safety Measures

- **Dry-run by default**: Show changes without applying
- **Git safety**: Create backup branch before changes
- **Rollback**: Easy undo if something breaks
- **Test validation**: Run tests after changes

## Output

```typescript
{
  applied: FixApplication[];
  skipped: FixApplication[];
  failed: FixApplication[];
  summary: {
    totalAttempted: number;
    successCount: number;
    failureCount: number;
    testsPass: boolean;
  };
}

interface FixApplication {
  findingId: string;
  status: 'success' | 'skipped' | 'failed';
  changes: FileChange[];
  reason?: string;
}
```

## Example Usage

```bash
# Interactive mode (default)
npm run pr-review-fix

# Dry run (show changes only)
npm run pr-review-fix --dry-run

# Auto-apply safe changes
npm run pr-review-fix --auto-safe
```

## Limitations

- Cannot fix complex logic issues (requires human reasoning)
- May not match exact code style in rare cases
- Requires review for critical changes

## Integration with GitHub Copilot

User triggers via: "Implement below issues in agent mode"

Agent will:
1. Parse findings from review report
2. Generate fixes using code generation
3. Present changes interactively
4. Apply upon approval
