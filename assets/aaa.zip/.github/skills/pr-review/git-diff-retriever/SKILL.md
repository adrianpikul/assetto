---
name: git-diff-retriever
description: Retrieves git diff with filesystem caching. Cache key includes repo, branch, jiraId, and commit hash to avoid recomputation.
license: MIT
allowed-tools:
  - bash
---

# Git Diff Retriever Skill

## Purpose

Retrieves git diff for the current branch with intelligent caching to avoid redundant computation.

## Caching Strategy

### Cache Key Components
- Repository path
- Branch name
- Jira ID
- Last commit hash

### Cache Location
`.copilot/cache/pr-review/{cacheKey}.json`

### Cache Invalidation
Automatic on new commits (commit hash change)

### Cache Structure
```json
{
  "diff": "...",
  "changedFiles": ["src/file1.ts", "src/file2.ts"],
  "timestamp": "2026-04-08T14:39:00Z",
  "commitHash": "a882f8f",
  "stats": {
    "additions": 150,
    "deletions": 45,
    "filesChanged": 8
  }
}
```

## Input

```typescript
{
  jiraId: string;
  branchName: string;
  baseBranch?: string; // default: "main"
  repoPath: string;
}
```

## Output

```typescript
{
  diff: string;
  changedFiles: string[];
  cacheHit: boolean;
  commitHash: string;
  stats: {
    additions: number;
    deletions: number;
    filesChanged: number;
  }
}
```

## Performance

- **Cached retrieval**: <5ms
- **Uncached retrieval**: <500ms (depends on diff size)

## Error Handling

### Empty Diff
If no changes detected:
- Returns error `code: "EMPTY_DIFF"`
- Orchestrator stops with explanation

### Git Command Failure
If git command fails:
- Returns error `code: "GIT_COMMAND_FAILED"`
- Includes stderr output for debugging

### Cache Corruption
If cache file is corrupted:
- Automatically clears corrupt entry
- Regenerates diff from git

## Implementation

See `git-diff-retriever.ts` for TypeScript implementation.

## Fallback Behavior

If Jira ID is not found in recent commits:
1. Falls back to comparing against base branch
2. Scans last 50 commits on current branch
3. If still no match, uses all commits from branch point

## Examples

### Example 1: Cache Hit
```typescript
Input: {
  jiraId: "C1234-43224",
  branchName: "feature/C1234-43224-add-auth",
  repoPath: "/c/projects/copilotAgents"
}

Output: {
  diff: "...",
  changedFiles: ["src/Auth.tsx"],
  cacheHit: true,
  commitHash: "a882f8f",
  stats: { additions: 50, deletions: 10, filesChanged: 1 }
}
```

### Example 2: Cache Miss (new commit)
```typescript
Input: {
  jiraId: "C1234-43224",
  branchName: "feature/C1234-43224-add-auth",
  repoPath: "/c/projects/copilotAgents"
}

Output: {
  diff: "...",
  changedFiles: ["src/Auth.tsx", "src/Login.tsx"],
  cacheHit: false,
  commitHash: "b992a8e",
  stats: { additions: 75, deletions: 15, filesChanged: 2 }
}
```
