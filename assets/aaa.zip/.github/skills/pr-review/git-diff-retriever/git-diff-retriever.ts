/**
 * Git Diff Retriever Implementation
 *
 * Retrieves git diff with intelligent filesystem caching.
 */

import { execSync } from 'child_process';
import * as path from 'path';
import type {
  DiffRetrievalResult,
  SkillResult,
  SkillError,
} from '../../../../src/agents/types/shared-context';
import {
  CacheManager,
  type CacheEntry,
} from '../../../../src/agents/cache/cache-manager';

export interface DiffRetrievalInput {
  jiraId: string;
  branchName: string;
  baseBranch?: string;
  repoPath: string;
}

export async function retrieveGitDiff(
  input: DiffRetrievalInput
): Promise<SkillResult<DiffRetrievalResult>> {
  const startTime = Date.now();
  const baseBranch = input.baseBranch || 'main';
  const cacheManager = new CacheManager();

  try {
    await cacheManager.initialize();

    // Get current commit hash
    const commitHash = execSync('git rev-parse HEAD', {
      cwd: input.repoPath,
      encoding: 'utf-8',
    }).trim();

    // Generate cache key
    const cacheKey = cacheManager.generateCacheKey({
      repo: path.basename(input.repoPath),
      branch: input.branchName,
      jiraId: input.jiraId,
      commitHash,
    });

    // Try cache first
    const cachedEntry = await cacheManager.get(cacheKey);
    if (cachedEntry) {
      return {
        success: true,
        data: {
          diff: cachedEntry.diff,
          changedFiles: cachedEntry.changedFiles,
          cacheHit: true,
          commitHash: cachedEntry.commitHash,
          stats: cachedEntry.stats,
        },
        metadata: {
          skillName: 'git-diff-retriever',
          executionTime: Date.now() - startTime,
          timestamp: new Date().toISOString(),
        },
      };
    }

    // Cache miss - retrieve diff from git
    const diffResult = await retrieveDiffFromGit(input, baseBranch);

    if (!diffResult.success) {
      return diffResult;
    }

    // Cache the result
    const cacheEntry: CacheEntry = {
      diff: diffResult.data!.diff,
      changedFiles: diffResult.data!.changedFiles,
      timestamp: new Date().toISOString(),
      commitHash,
      stats: diffResult.data!.stats,
    };

    await cacheManager.set(cacheKey, cacheEntry);

    return {
      success: true,
      data: {
        ...diffResult.data!,
        cacheHit: false,
      },
      metadata: {
        skillName: 'git-diff-retriever',
        executionTime: Date.now() - startTime,
        timestamp: new Date().toISOString(),
      },
    };
  } catch (error) {
    const skillError: SkillError = {
      code: 'DIFF_RETRIEVAL_ERROR',
      message: `Failed to retrieve git diff: ${error}`,
      recoverable: false,
    };

    return {
      success: false,
      error: skillError,
      metadata: {
        skillName: 'git-diff-retriever',
        executionTime: Date.now() - startTime,
        timestamp: new Date().toISOString(),
      },
    };
  }
}

async function retrieveDiffFromGit(
  input: DiffRetrievalInput,
  baseBranch: string
): Promise<SkillResult<DiffRetrievalResult>> {
  try {
    // Strategy 1: Try to find commits with Jira ID
    const commitsWithJiraId = execSync(
      `git log --all --grep="${input.jiraId}" --format=%H`,
      { cwd: input.repoPath, encoding: 'utf-8' }
    )
      .trim()
      .split('\n')
      .filter((hash) => hash.length > 0);

    let baseCommit: string | null = null;

    if (commitsWithJiraId.length > 0) {
      // Use the oldest commit with this Jira ID as the base
      baseCommit = commitsWithJiraId[commitsWithJiraId.length - 1];
    } else {
      // Fallback: find merge base with base branch
      try {
        baseCommit = execSync(`git merge-base HEAD origin/${baseBranch}`, {
          cwd: input.repoPath,
          encoding: 'utf-8',
        }).trim();
      } catch {
        // Fallback to comparing against base branch directly
        baseCommit = `origin/${baseBranch}`;
      }
    }

    // Get diff
    const diff = execSync(`git diff ${baseCommit}..HEAD`, {
      cwd: input.repoPath,
      encoding: 'utf-8',
      maxBuffer: 10 * 1024 * 1024, // 10MB
    });

    if (!diff || diff.trim().length === 0) {
      const error: SkillError = {
        code: 'EMPTY_DIFF',
        message: 'No changes detected in the current branch',
        details: { baseBranch, branchName: input.branchName },
        recoverable: false,
      };

      return {
        success: false,
        error,
        metadata: {
          skillName: 'git-diff-retriever',
          executionTime: 0,
          timestamp: new Date().toISOString(),
        },
      };
    }

    // Get changed files
    const changedFilesOutput = execSync(
      `git diff --name-only ${baseCommit}..HEAD`,
      { cwd: input.repoPath, encoding: 'utf-8' }
    );

    const changedFiles = changedFilesOutput
      .trim()
      .split('\n')
      .filter((f) => f.length > 0);

    // Get diff stats
    const statsOutput = execSync(
      `git diff --shortstat ${baseCommit}..HEAD`,
      { cwd: input.repoPath, encoding: 'utf-8' }
    );

    const stats = parseDiffStats(statsOutput);

    const result: DiffRetrievalResult = {
      diff,
      changedFiles,
      cacheHit: false,
      commitHash: execSync('git rev-parse HEAD', {
        cwd: input.repoPath,
        encoding: 'utf-8',
      }).trim(),
      stats,
    };

    return {
      success: true,
      data: result,
      metadata: {
        skillName: 'git-diff-retriever',
        executionTime: 0,
        timestamp: new Date().toISOString(),
      },
    };
  } catch (error) {
    const skillError: SkillError = {
      code: 'GIT_COMMAND_FAILED',
      message: `Git command failed: ${error}`,
      details: { stderr: (error as any).stderr?.toString() },
      recoverable: false,
    };

    return {
      success: false,
      error: skillError,
      metadata: {
        skillName: 'git-diff-retriever',
        executionTime: 0,
        timestamp: new Date().toISOString(),
      },
    };
  }
}

function parseDiffStats(statsOutput: string): {
  additions: number;
  deletions: number;
  filesChanged: number;
} {
  const match = statsOutput.match(
    /(\d+) files? changed(?:, (\d+) insertions?\(\+\))?(?:, (\d+) deletions?\(-\))?/
  );

  if (!match) {
    return { additions: 0, deletions: 0, filesChanged: 0 };
  }

  return {
    filesChanged: parseInt(match[1] || '0', 10),
    additions: parseInt(match[2] || '0', 10),
    deletions: parseInt(match[3] || '0', 10),
  };
}
