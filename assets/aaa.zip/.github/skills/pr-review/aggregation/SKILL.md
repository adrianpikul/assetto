---
name: aggregation
description: Collects findings from all review agents, deduplicates, and classifies by severity (Critical, NotImplemented, NiceToFix).
license: MIT
---

# Aggregation Layer

## Purpose

Combines outputs from all review agents into a single, deduplicated, severity-classified report.

## Responsibilities

1. **Collection**: Gather findings from all agents
2. **Deduplication**: Remove duplicate or overlapping findings
3. **Severity Classification**: Apply strict rules to classify findings
4. **Report Generation**: Create final structured output

## Input

Collects outputs from:
- Requirement Coverage Agent
- Code Quality Agent
- Business Logic Agent

## Output

```typescript
{
  metadata: {
    branchName: string;
    jiraId: string;
    timestamp: string;
    reviewDuration: string;
  };
  findings: {
    critical: Finding[];
    notImplemented: Finding[];
    niceToFix: Finding[];
  };
  summary: {
    totalFindings: number;
    criticalCount: number;
    notImplementedCount: number;
    niceToFixCount: number;
    filesAnalyzed: number;
    testCoverage: 'none' | 'partial' | 'good';
  };
  actions: PostReviewAction[];
}
```

## Deduplication Strategy

### 1. Exact Matches
Remove findings with identical:
- File + Line + Description

### 2. Semantic Similarity
Detect similar findings using:
- Content hash comparison
- File/line proximity (±5 lines)
- Category overlap

### 3. Priority Rules
When merging duplicates:
- Keep higher severity
- Merge recommendations
- Preserve most detailed description

## Severity Classification Rules

### Critical
✓ Breaking requirements
✓ Incorrect business logic
✓ Major security/data risks
✓ Missing error handling in critical paths
✓ Regression risks in shared utilities
✓ Concurrent modification issues
✓ Authentication/authorization gaps

### NotImplemented
✓ Explicitly missing functionality from Jira
✓ Required edge cases not covered
✓ Specified requirements absent
✓ Missing tests for new features
✓ Incomplete business rules

### NiceToFix
✓ Code style improvements
✓ Performance optimizations
✓ Non-blocking suggestions
✓ Better naming/structure
✓ UX enhancements (non-critical)
✓ Debug code cleanup (console.log, etc.)

## Override Rules

Agent-assigned severities can be overridden:

```typescript
Override Priority:
1. Security issues → Always Critical
2. Data loss risks → Always Critical
3. Missing Jira requirements → Always NotImplemented
4. Style/optimization → Always NiceToFix
```

## Test Coverage Assessment

Calculate overall test coverage:
- **None**: No test files in changes
- **Partial**: Some test files but missing coverage
- **Good**: Comprehensive test coverage

## Post-Review Actions

Always include these actions:
1. "Create Plan to Fix Below Issues" → fix-planning-agent
2. "Implement Below Issues in Agent Mode" → fix-implementation-agent

## Performance Target

Aggregation time: <100ms

## Example

### Input (from agents)
```javascript
RequirementCoverage: {
  missing: [{ requirement: "Password validation", status: "missing" }]
}

CodeQuality: {
  tests: [{ file: "Login.tsx", coverage: "none" }],
  edgeCases: [{ description: "No null check for user.email" }]
}

BusinessLogic: {
  assumptions: [{ description: "Assumes email is always populated" }]
}
```

### Output (aggregated)
```json
{
  "findings": {
    "critical": [
      {
        "id": "crit-001",
        "source": "business-logic-agent",
        "description": "Assumes email is always populated (merged with code-quality edge case)",
        "recommendation": "Add null check before accessing user.email",
        "file": "src/auth/Login.tsx"
      }
    ],
    "notImplemented": [
      {
        "id": "notimpl-001",
        "source": "requirement-coverage-agent",
        "description": "Password validation requirement missing",
        "recommendation": "Implement password validation (min 8 characters)"
      }
    ],
    "niceToFix": []
  },
  "summary": {
    "totalFindings": 2,
    "criticalCount": 1,
    "notImplementedCount": 1,
    "niceToFixCount": 0,
    "filesAnalyzed": 3,
    "testCoverage": "partial"
  }
}
```
