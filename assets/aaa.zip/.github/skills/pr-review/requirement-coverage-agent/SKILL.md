---
name: requirement-coverage-agent
description: Analyzes code changes against Jira requirements to identify implemented, partial, and missing functionality.
license: MIT
allowed-tools:
  - bash
---

# Requirement Coverage Agent

## Purpose

Compares Jira description (business requirements) with code implementation to verify complete coverage.

## Responsibilities

1. **Extract Requirements**: Parse Jira description to identify discrete requirements
2. **Verify Implementation**: Match requirements against code changes in git diff
3. **Classify Coverage**: Categorize each requirement as implemented/partial/missing
4. **Identify Gaps**: Flag missing or incomplete functionality

## Input

Consumes `SharedContext`:
- `jiraDescription` - Business requirements
- `gitDiff` - Code changes
- `changedFiles` - List of modified files

## Output

```typescript
{
  implemented: RequirementItem[];   // Fully implemented
  partial: RequirementItem[];       // Partially implemented
  missing: RequirementItem[];       // Not implemented
  improvements: string[];           // Suggestions for better coverage
}
```

### RequirementItem Structure

```typescript
{
  requirement: string;              // The requirement text
  status: 'implemented' | 'partial' | 'missing';
  evidence?: string;                // File:line where implemented
  notes?: string;                   // Additional context
}
```

## Analysis Strategy

### 1. Requirement Extraction
Parse Jira description for:
- User stories ("As a user, I want...")
- Acceptance criteria
- Functional requirements
- Edge case handling
- Error handling requirements

### 2. Code Matching
For each requirement, analyze:
- Relevant code in changed files
- Function/component names matching requirement domain
- Test coverage for the requirement
- Error handling implementation

### 3. Classification Rules

**Implemented**: 
- Code clearly implements the requirement
- Tests exist and pass
- Error handling present

**Partial**:
- Basic implementation exists but incomplete
- Missing edge cases
- Weak or missing tests

**Missing**:
- No evidence of implementation in diff
- Explicitly stated in Jira but absent from code

## Deterministic Output

Agent MUST return structured JSON, not free-form text.

## Error Handling

- If Jira description is too vague, note in `improvements[]`
- If unable to parse requirements, return best-effort analysis with warning

## Performance Target

- Execution time: <10 seconds (parallel with other agents)

## Examples

### Example 1: User Authentication

**Input (Jira Description)**:
```
Implement user authentication with the following:
- Login with email and password
- Logout functionality
- Session management (24-hour expiry)
- Password validation (min 8 characters)
```

**Output**:
```json
{
  "implemented": [
    {
      "requirement": "Login with email and password",
      "status": "implemented",
      "evidence": "src/auth/Login.tsx:45-67",
      "notes": "Implements login form with validation"
    },
    {
      "requirement": "Logout functionality",
      "status": "implemented",
      "evidence": "src/auth/Logout.tsx:12-20"
    }
  ],
  "partial": [
    {
      "requirement": "Session management (24-hour expiry)",
      "status": "partial",
      "evidence": "src/auth/session.ts:30",
      "notes": "Session creation exists but no expiry logic found"
    }
  ],
  "missing": [
    {
      "requirement": "Password validation (min 8 characters)",
      "status": "missing",
      "notes": "No validation logic found in diff"
    }
  ],
  "improvements": [
    "Add tests for session expiry logic",
    "Document password validation requirements in code"
  ]
}
```

### Example 2: Bug Fix

**Input (Jira Description)**:
```
Fix null pointer exception in user profile page when user has no avatar.
Expected: Display default avatar placeholder.
```

**Output**:
```json
{
  "implemented": [
    {
      "requirement": "Fix null pointer exception",
      "status": "implemented",
      "evidence": "src/components/UserProfile.tsx:89",
      "notes": "Added null check for avatar field"
    },
    {
      "requirement": "Display default avatar placeholder",
      "status": "implemented",
      "evidence": "src/components/UserProfile.tsx:90-92",
      "notes": "Renders DefaultAvatar component when avatar is null"
    }
  ],
  "partial": [],
  "missing": [],
  "improvements": [
    "Add unit test to verify default avatar renders correctly"
  ]
}
```
