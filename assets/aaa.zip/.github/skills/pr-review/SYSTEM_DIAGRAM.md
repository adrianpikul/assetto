# PR Review System - Visual Diagrams

## System Architecture

```
┌─────────────────────────────────────────────────────────────────────────────┐
│                                                                              │
│                         USER TRIGGERS PR REVIEW                              │
│                                                                              │
│  VSCode Terminal:              GitHub Copilot Chat:                          │
│  $ npm run pr-review           @workspace Review this PR                     │
│                                                                              │
└────────────────────────────────┬────────────────────────────────────────────┘
                                 │
┌────────────────────────────────▼────────────────────────────────────────────┐
│                                                                              │
│                           ORCHESTRATOR AGENT                                 │
│                       (Master Coordinator)                                   │
│                                                                              │
└─┬────────────────────────────────────────────────────────────────────────┬──┘
  │                                                                          │
  │ PHASE 1: CONTEXT ACQUISITION (Sequential)                               │
  │                                                                          │
  ├──► ┌──────────────────────────────────────────┐                         │
  │    │  Git Branch Parser Skill                 │                         │
  │    │  • Extracts: C1234-43224 from branch     │                         │
  │    │  • Regex patterns for format detection   │                         │
  │    │  • Fallback: Ask user for Jira ID        │                         │
  │    │  ⏱ <10ms                                  │                         │
  │    └──────────────────────────────────────────┘                         │
  │                     ↓                                                    │
  ├──► ┌──────────────────────────────────────────┐                         │
  │    │  Git Diff Retriever Skill                │                         │
  │    │  • Cache key: SHA256(repo+branch+hash)   │                         │
  │    │  • Cache location: .copilot/cache/       │                         │
  │    │  • Cache hit: <5ms | miss: <500ms        │                         │
  │    │  • Auto-invalidation on new commits      │                         │
  │    └──────────────────────────────────────────┘                         │
  │                     ↓                                                    │
  ├──► ┌──────────────────────────────────────────┐                         │
  │    │  Jira Context Skill                      │                         │
  │    │  • User prompt: "Enter Jira description" │                         │
  │    │  • Multiline input support               │                         │
  │    │  • Future: Jira REST API integration     │                         │
  │    └──────────────────────────────────────────┘                         │
  │                     ↓                                                    │
  │    ┌──────────────────────────────────────────┐                         │
  │    │         SHARED CONTEXT                   │                         │
  │    │  {                                        │                         │
  │    │    branchName: string                    │                         │
  │    │    projectCode: string                   │                         │
  │    │    jiraId: string                        │                         │
  │    │    gitDiff: string                       │                         │
  │    │    changedFiles: string[]                │                         │
  │    │    jiraDescription: string               │                         │
  │    │    metadata: {...}                       │                         │
  │    │  }                                        │                         │
  │    └──────────────────────────────────────────┘                         │
  │                                                                          │
  │ PHASE 2: CONTEXT VALIDATION                                              │
  │    ✓ Jira ID exists?                                                     │
  │    ✓ Diff not empty?                                                     │
  │    ✓ Jira description provided?                                          │
  │    ✓ Changed files detected?                                             │
  │                                                                          │
  ├──────────────────────────────────────────────────────────────────────────┤
  │                                                                          │
  │ PHASE 3: PARALLEL REVIEW (3 agents concurrently)                         │
  │                                                                          │
  │    ┌─────────────────────────────────────────────────────────────────┐  │
  │    │                                                                   │  │
  │    │   ┌────────────────────┐  ┌────────────────────┐  ┌───────────┐ │  │
  │    │   │ Requirement        │  │ Code Quality       │  │ Business  │ │  │
  │    │   │ Coverage Agent     │  │ Agent              │  │ Logic     │ │  │
  │    │   │                    │  │                    │  │ Agent     │ │  │
  │    │   │ • Parse Jira reqs  │  │ • Structure checks │  │ • Edge    │ │  │
  │    │   │ • Match vs code    │  │ • Pattern analysis │  │   cases   │ │  │
  │    │   │ • Classify:        │  │ • Test coverage    │  │ • Logical │ │  │
  │    │   │   - Implemented    │  │ • Regression risk  │  │   gaps    │ │  │
  │    │   │   - Partial        │  │ • Anti-patterns    │  │ • Invalid │ │  │
  │    │   │   - Missing        │  │                    │  │   assumes │ │  │
  │    │   │                    │  │                    │  │ • User    │ │  │
  │    │   │ ⏱ <10s             │  │ ⏱ <10s             │  │   flows   │ │  │
  │    │   │                    │  │                    │  │           │ │  │
  │    │   │                    │  │                    │  │ ⏱ <10s    │ │  │
  │    │   └────────────────────┘  └────────────────────┘  └───────────┘ │  │
  │    │              ↓                      ↓                     ↓      │  │
  │    │         RequirementCoverageReport  CodeQualityReport  BusinessLogicReport
  │    └─────────────────────────────────────────────────────────────────┘  │
  │                                    ↓                                     │
  ├──────────────────────────────────────────────────────────────────────────┤
  │                                                                          │
  │ PHASE 4: AGGREGATION                                                     │
  │                                                                          │
  │    ┌──────────────────────────────────────────┐                         │
  │    │  Aggregation Layer                       │                         │
  │    │                                           │                         │
  │    │  1. Collect all findings                 │                         │
  │    │     • From 3 agent reports               │                         │
  │    │     • Convert to unified format          │                         │
  │    │                                           │                         │
  │    │  2. Deduplicate                          │                         │
  │    │     • Generate content hash              │                         │
  │    │     • Merge similar (file+line+desc)     │                         │
  │    │     • Keep higher severity               │                         │
  │    │                                           │                         │
  │    │  3. Classify by Severity                 │                         │
  │    │     ┌─────────────────────────────────┐  │                         │
  │    │     │ Critical                        │  │                         │
  │    │     │ • Security issues               │  │                         │
  │    │     │ • Data integrity risks          │  │                         │
  │    │     │ • Breaking changes              │  │                         │
  │    │     │ • Null pointer exceptions       │  │                         │
  │    │     └─────────────────────────────────┘  │                         │
  │    │     ┌─────────────────────────────────┐  │                         │
  │    │     │ NotImplemented                  │  │                         │
  │    │     │ • Missing Jira requirements     │  │                         │
  │    │     │ • Incomplete features           │  │                         │
  │    │     │ • Missing tests                 │  │                         │
  │    │     └─────────────────────────────────┘  │                         │
  │    │     ┌─────────────────────────────────┐  │                         │
  │    │     │ NiceToFix                       │  │                         │
  │    │     │ • Code style                    │  │                         │
  │    │     │ • Optimizations                 │  │                         │
  │    │     │ • Better naming                 │  │                         │
  │    │     └─────────────────────────────────┘  │                         │
  │    │                                           │                         │
  │    │  ⏱ <100ms                                 │                         │
  │    └──────────────────────────────────────────┘                         │
  │                          ↓                                               │
  ├──────────────────────────────────────────────────────────────────────────┤
  │                                                                          │
  │ PHASE 5: FINALIZATION                                                    │
  │                                                                          │
  │    ┌──────────────────────────────────────────┐                         │
  │    │  AggregatedReviewReport                  │                         │
  │    │  {                                        │                         │
  │    │    metadata: {                            │                         │
  │    │      jiraId, branch, duration             │                         │
  │    │    },                                     │                         │
  │    │    findings: {                            │                         │
  │    │      critical: Finding[],                 │                         │
  │    │      notImplemented: Finding[],           │                         │
  │    │      niceToFix: Finding[]                 │                         │
  │    │    },                                     │                         │
  │    │    summary: {                             │                         │
  │    │      totalFindings, counts, coverage      │                         │
  │    │    },                                     │                         │
  │    │    actions: PostReviewAction[]            │                         │
  │    │  }                                        │                         │
  │    └──────────────────────────────────────────┘                         │
  │                          ↓                                               │
  │    ┌──────────────────────────────────────────┐                         │
  │    │  Outputs:                                 │                         │
  │    │  • Console report (formatted)             │                         │
  │    │  • JSON file: .copilot/reports/*.json    │                         │
  │    │  • Logs: .copilot/logs/*.json            │                         │
  │    └──────────────────────────────────────────┘                         │
  │                                                                          │
  └──────────────────────────────────────────────────────────────────────────┘
                                 ↓
┌────────────────────────────────────────────────────────────────────────────┐
│                                                                            │
│                    POST-REVIEW ACTIONS (User-triggered)                    │
│                                                                            │
│  ┌─────────────────────────────────┐  ┌────────────────────────────────┐ │
│  │  Fix Planning Agent              │  │  Fix Implementation Agent      │ │
│  │                                  │  │                                │ │
│  │  Input: AggregatedReviewReport   │  │  Input: AggregatedReviewReport │ │
│  │                                  │  │         SharedContext          │ │
│  │  Output:                         │  │                                │ │
│  │  • Prioritized fix plan          │  │  Output:                       │ │
│  │  • Step-by-step actions          │  │  • Applied changes             │ │
│  │  • Effort estimates              │  │  • Git commits                 │ │
│  │  • Dependency graph              │  │  • Test results                │ │
│  │                                  │  │  • Rollback support            │ │
│  └─────────────────────────────────┘  └────────────────────────────────┘ │
│                                                                            │
└────────────────────────────────────────────────────────────────────────────┘
```

## Data Flow

```
Git Branch
    ↓ (parse)
Jira ID (C1234-43224)
    ↓ (retrieve)
Git Diff + Changed Files
    ↓ (acquire)
Jira Description
    ↓ (merge)
SharedContext
    ↓ (distribute to 3 agents in parallel)
    ├─→ RequirementCoverageReport
    ├─→ CodeQualityReport
    └─→ BusinessLogicReport
    ↓ (aggregate)
All Findings (raw)
    ↓ (deduplicate)
Unique Findings
    ↓ (classify)
CategorizedFindings {critical, notImplemented, niceToFix}
    ↓ (format)
AggregatedReviewReport (JSON)
    ↓ (display)
Console + File Output
```

## Severity Classification Flow

```
Finding
    ↓
┌───────────────────────────────────────┐
│  Override Rules (Priority Order)      │
└───────────────────────────────────────┘
    ↓
    ├─► Contains "security" → CRITICAL
    ├─► Contains "data loss" → CRITICAL
    ├─► Contains "null-handling" → CRITICAL
    ├─► Regression in shared code → CRITICAL
    ├─► Missing Jira requirement → NOT_IMPLEMENTED
    ├─► Missing tests → NOT_IMPLEMENTED
    ├─► Style/debug code → NICE_TO_FIX
    └─► Use agent-assigned severity → As-is
    ↓
Categorized Finding
```

## Cache Flow

```
Git Diff Request
    ↓
Generate Cache Key
    SHA256(repo + branch + jiraId + commitHash)
    ↓
Check Cache
    ↓
    ├─► Cache Hit ─────────────────┐
    │   • <5ms response time        │
    │   • Return cached diff        │
    │                               ├─→ Return Diff
    └─► Cache Miss ────────────────┤
        • Execute git diff          │
        • <500ms response time      │
        • Store in cache            │
        • Return fresh diff ────────┘
    ↓
Cache Invalidation
    ↓
    ├─► New commit → Different hash → Cache miss
    ├─► Manual clear → rm -rf .copilot/cache/
    └─► Corruption → Auto-delete + regenerate
```

## Error Handling Flow

```
Skill/Agent Execution
    ↓
    ├─► Success ──────────────────────► Continue
    │
    └─► Error
        ↓
        Is Recoverable?
        ↓
        ├─► YES (recoverable: true)
        │   ↓
        │   Fallback Strategy
        │   ├─► Jira ID missing → Ask user
        │   ├─► Cache corrupt → Clear & regenerate
        │   └─► Agent timeout → Partial results + warning
        │   ↓
        │   Continue with fallback
        │
        └─► NO (recoverable: false)
            ↓
            Log Error
            ↓
            Stop Orchestration
            ↓
            Return Error Report
```

## Performance Timeline

```
Time (seconds)
0s ├──────────────────────────────────────────────────────────────────┤ 20s
   │
   ├► Parse Branch (<0.01s)
   ├► Retrieve Diff (0.005s cached / 0.5s uncached)
   ├► Acquire Jira (user input time varies)
   │
   ├──────────── Parallel Agent Execution (15s total) ────────────────┤
   │             │                                                     │
   │             ├► Requirement Coverage Agent                        │
   │             ├► Code Quality Agent                                │
   │             └► Business Logic Agent                              │
   │                                                                   │
   ├► Aggregation (0.1s)
   ├► Report Generation (0.05s)
   └► Display Output (instant)
```

## File System Structure

```
.copilot/
├── cache/
│   └── pr-review/
│       ├── {cacheKey1}.json   # Cached git diff
│       ├── {cacheKey2}.json
│       └── ...
│
├── logs/
│   └── pr-review/
│       ├── 2026-04-08T14-39-00.json   # Execution log
│       └── ...
│
└── reports/
    └── pr-review-C1234-43224-{timestamp}.json   # Final report
```

## Parallel Execution Model

```
Time →

T0: ──┬─ Spawn Requirement Coverage Agent ────────────────────┐
      ├─ Spawn Code Quality Agent ────────────────────────────┤
      └─ Spawn Business Logic Agent ──────────────────────────┘
                                                              ↓
T15:                                       All agents complete
                                                              ↓
                                                        Aggregation
                                                              ↓
                                                        Final Report

Sequential would be: 15s + 15s + 15s = 45s
Parallel execution:  max(15s, 15s, 15s) = 15s

Speedup: 3x
```

## TypeScript Type Hierarchy

```
SharedContext
    ├─► BranchParseResult
    ├─► DiffRetrievalResult
    └─► JiraContextResult
        ↓
    [Passed to agents]
        ↓
    ├─► RequirementCoverageReport
    │       └─► RequirementItem[]
    │
    ├─► CodeQualityReport
    │       ├─► Finding[]
    │       └─► TestCoverageItem[]
    │
    └─► BusinessLogicReport
            └─► Finding[]
        ↓
    [Aggregation]
        ↓
AggregatedReviewReport
    ├─► CategorizedFindings
    │       ├─► critical: Finding[]
    │       ├─► notImplemented: Finding[]
    │       └─► niceToFix: Finding[]
    │
    └─► ReviewSummary
```

## GitHub Copilot Integration

```
User types in Copilot Chat:
"@workspace Review this PR"
    ↓
Copilot Discovery Phase:
    ├─► Scans .github/skills/pr-review/
    ├─► Reads all SKILL.md files
    ├─► Matches descriptions to user intent
    └─► Selects relevant skills
    ↓
Context Injection:
    ├─► Loads SKILL.md content
    ├─► Loads supplementary files
    └─► Provides to LLM
    ↓
Execution:
    ├─► Copilot determines to run orchestrator
    ├─► Executes TypeScript orchestrator
    └─► Returns structured report
    ↓
Display:
    └─► Formatted output in Copilot Chat
```

---

**Visual reference for understanding the complete system architecture**
