# Skills Directory

Reusable capabilities for GitHub Copilot agents.

## Available Skills

### branch-parser
**Extract Jira ID from git branch names**

**Location**: `branch-parser/SKILL.md`

**Input**: Branch name string
**Output**: `{ projectCode, jiraId, branchName, branchType }`

**Supported formats**:
- `feature/C1234-43224-description`
- `bug/PROJ-123-fix`
- `C1234-43224-direct`

---

### diff-retriever
**Retrieve git diff with caching**

**Location**: `diff-retriever/SKILL.md`

**Input**: `{ jiraId, branchName, baseBranch, repoPath }`
**Output**: `{ diff, changedFiles, cacheHit, stats }`

**Performance**:
- Cache hit: <5ms
- Cache miss: <500ms

**Cache key**: SHA256(repo + branch + jiraId + commitHash)

---

### jira-context
**Acquire Jira issue description**

**Location**: `jira-context/SKILL.md`

**Input**: `{ jiraId }`
**Output**: `{ jiraId, description, source }`

**Current**: User prompt for description
**Future**: Jira REST API integration

---

### aggregator
**Aggregate and classify findings**

**Location**: `aggregator/SKILL.md`

**Input**: Findings from multiple agents
**Output**: `{ critical, notImplemented, niceToFix }`

**Process**:
1. Collect findings from all agents
2. Deduplicate using content hash
3. Classify by severity with strict rules

---

## Creating New Skills

1. Create directory: `your-skill/`
2. Add `SKILL.md` with frontmatter:
```yaml
---
name: your-skill
description: What the skill does
license: MIT
---
```
3. Document input/output contracts
4. Provide usage examples
5. Optional: Add implementation files

## Skill Format

Each skill folder contains:

- **SKILL.md** (required) - Skill definition and documentation
- Implementation files (optional) - TypeScript, Python, etc.
- Examples (optional) - Usage examples
- Tests (optional) - Validation tests

## Using Skills

Skills are referenced by agents in their agent.md files.

Example from pr-review.agent.md:
```markdown
## Skills You Use

- **`branch-parser`** - Extracts Jira ID from branch
- **`diff-retriever`** - Retrieves diff with caching
```

GitHub Copilot automatically discovers and loads skills when agents reference them.
