---
name: aggregator
description: Aggregates findings from multiple agents, deduplicates, and classifies by severity using strict rules.
license: MIT
---

# Aggregator Skill

Collects findings from review agents and produces categorized output.

## Input

Findings from three agents:
- Requirement Coverage Agent
- Code Quality Agent
- Business Logic Agent

## Output

```json
{
  "critical": [...],
  "notImplemented": [...],
  "niceToFix": [...]
}
```

## Process

### 1. Collection

Collect all findings from agent reports:
- Convert requirement coverage items to findings
- Extract code quality issues
- Extract business logic issues
- Normalize to unified `Finding` format

### 2. Deduplication

Remove duplicates using:
- Content hash (MD5 of file + line + category + description)
- Semantic similarity (same file, similar description, ±5 lines)

**Merge rules**:
- Keep higher severity
- Combine recommendations
- Preserve most detailed description

### 3. Severity Classification

Apply **strict rules** (in priority order):

#### Critical

- Security issues (auth, XSS, injection)
- Data integrity risks (null pointers, data loss)
- Breaking changes (API changes, shared utils)
- Regression in shared code
- Concurrent modification issues

#### NotImplemented

- Missing Jira requirements
- Incomplete features from Jira
- Missing tests for new code
- Required edge cases not covered

#### NiceToFix

- Code style (formatting, naming)
- Debug code (console.log, TODOs)
- Performance optimizations
- File length, function complexity

## Severity Override Rules

```typescript
// Priority 1: Security → Always Critical
if (finding.category.includes('security')) return 'critical';

// Priority 2: Data loss → Always Critical
if (finding.category.includes('null-handling')) return 'critical';

// Priority 3: Missing Jira requirement → NotImplemented
if (finding.source === 'requirement-coverage') return 'notImplemented';

// Priority 4: Style/debug → NiceToFix
if (finding.category.includes('debug-code')) return 'niceToFix';

// Default: Use agent-assigned severity
return finding.severity || 'niceToFix';
```

## Example

### Input (from agents)

```json
RequirementCoverage: {
  "missing": [{ "requirement": "Password validation" }]
}

CodeQuality: {
  "tests": [{ "file": "Login.tsx", "coverage": "none" }],
  "edgeCases": [{ "description": "No null check for user.email" }]
}

BusinessLogic: {
  "assumptions": [{ "description": "Assumes email always exists" }]
}
```

### Output (aggregated)

```json
{
  "critical": [
    {
      "id": "crit-001",
      "source": "business-logic",
      "description": "Assumes email always exists (merged with code-quality edge case)",
      "file": "src/auth/Login.tsx",
      "recommendation": "Add null check: user.email?."
    }
  ],
  "notImplemented": [
    {
      "id": "notimpl-001",
      "source": "requirement-coverage",
      "description": "Missing requirement: Password validation",
      "recommendation": "Implement from Jira"
    },
    {
      "id": "notimpl-002",
      "source": "code-quality",
      "description": "No tests for Login.tsx",
      "recommendation": "Add unit tests"
    }
  ],
  "niceToFix": []
}
```

## Test Coverage Assessment

Determine overall test coverage:

- **none**: No test files in changed files
- **partial**: Some test files but incomplete coverage
- **good**: Comprehensive test coverage

## Performance

- Execution time: <100ms
- Memory: O(n) where n = number of findings
