---
name: diff-retriever
description: Retrieves git diff with intelligent filesystem caching. Cache key includes repo, branch, jiraId, and commit hash.
license: MIT
---

# Diff Retriever Skill

Retrieves git diff for a branch with intelligent caching.

## Caching Strategy

**Cache Key**: `SHA256(repo + branch + jiraId + commitHash)`  
**Location**: `.copilot/cache/pr-review/{cacheKey}.json`  
**Invalidation**: Automatic on new commits (hash changes)

## Input

```json
{
  "jiraId": "C1234-43224",
  "branchName": "feature/C1234-43224-add-auth",
  "baseBranch": "main",
  "repoPath": "/path/to/repo",
  "skipCache": false
}
```

## Output

```json
{
  "diff": "...",
  "changedFiles": ["src/file1.ts", "src/file2.ts"],
  "cacheHit": true,
  "commitHash": "a882f8f",
  "stats": {
    "additions": 150,
    "deletions": 45,
    "filesChanged": 8
  }
}
```

## Performance

- **Cache hit**: <5ms
- **Cache miss**: <500ms (depends on diff size)

## Cache Structure

```json
{
  "diff": "full diff content",
  "changedFiles": ["file1.ts", "file2.ts"],
  "timestamp": "2026-04-08T14:39:00Z",
  "commitHash": "a882f8f",
  "stats": {
    "additions": 150,
    "deletions": 45,
    "filesChanged": 8
  }
}
```

## Error Handling

**Empty diff**:
- Return error `EMPTY_DIFF`
- Not recoverable (no changes to review)

**Git command failure**:
- Return error `GIT_COMMAND_FAILED`
- Include stderr for debugging

**Cache corruption**:
- Auto-delete corrupt entry
- Regenerate from git

## Git Strategy

1. Try to find commits with Jira ID in message
2. Use oldest commit with Jira ID as base
3. Fallback: merge-base with origin/baseBranch
4. Generate diff: `git diff {base}..HEAD`

## Usage

```bash
# First call (cache miss)
Retrieve diff for C1234-43224
→ Execute git diff (500ms)
→ Cache result
→ Return diff

# Second call (cache hit)
Retrieve diff for C1234-43224
→ Same commit hash
→ Load from cache (5ms)
→ Return diff
```
