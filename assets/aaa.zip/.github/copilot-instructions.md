# GitHub Copilot Instructions

## Repository Context

This repository contains a **PR Review Orchestration System** built using GitHub Copilot's multi-agent architecture.

## Agents Available

### @pr-review (Main Orchestrator)

Comprehensive PR review agent that coordinates multiple specialized review agents.

**When to use**:
- Before creating a pull request
- When you want comprehensive code review
- To validate requirements implementation

**How to invoke**:
```
@pr-review Review this PR
```

**What it does**:
1. Extracts Jira ID from branch name
2. Retrieves git diff (with caching)
3. Acquires Jira requirements from you
4. Spawns 3 review agents in parallel
5. Aggregates findings with severity classification
6. Generates structured report

### @requirement-coverage

Analyzes if code implements all Jira requirements.

**Focus**: Requirements vs implementation coverage

### @code-quality

Evaluates code structure, patterns, and test coverage.

**Focus**: Code quality, tests, regressions

### @business-logic

Validates business logic and identifies edge cases.

**Focus**: Business correctness, assumptions, user flows

### @fix-planning

Generates step-by-step resolution plan for issues.

**When to use**: After @pr-review to get actionable fix plan

### @fix-implementation

Automatically implements fixes for identified issues.

**When to use**: After @pr-review to auto-apply safe fixes

## Skills Available

Skills are reusable capabilities used by agents:

- **branch-parser**: Extracts Jira ID from branch names
- **diff-retriever**: Retrieves git diff with caching
- **jira-context**: Acquires Jira description
- **aggregator**: Deduplicates and classifies findings

## Typical Workflow

```
1. Create feature branch: feature/C1234-43224-add-authentication
2. Implement your changes
3. Commit your code
4. Invoke: @pr-review Review this PR
5. Provide Jira description when prompted
6. Review findings (Critical, NotImplemented, NiceToFix)
7. Optional: Get fix plan via @fix-planning handoff
8. Optional: Auto-fix issues via @fix-implementation handoff
9. Fix remaining issues manually
10. Re-review: @pr-review Review again after fixes
```

## Branch Naming Convention

To use the PR review system, follow this branch naming convention:

```
{type}/{PROJECT_CODE}-{ISSUE_NUMBER}-{description}
```

Examples:
- `feature/C1234-43224-add-authentication`
- `bug/PROJ-123-fix-login-issue`
- `hotfix/C1234-567-critical-fix`

If your branch doesn't match, you'll be prompted to provide the Jira ID manually.

## Coding Standards

When writing code in this repository:

1. **TypeScript Strict Mode**: All code must pass strict TypeScript checks
2. **Test Coverage**: Include tests for new functionality
3. **Error Handling**: Always handle edge cases and errors
4. **Documentation**: Document complex logic and business rules
5. **Commit Messages**: Include Jira ID in commit messages

## PR Review Severity Levels

### 🔴 Critical
- Security vulnerabilities
- Data integrity risks
- Breaking changes
- Must be fixed before merge

### 🟡 Not Implemented
- Missing Jira requirements
- Incomplete features
- Missing tests
- Should be addressed

### 🔵 Nice to Fix
- Code style improvements
- Optimizations
- Minor enhancements
- Optional improvements

## Cache Locations

The PR review system uses caching:

- **Git diffs**: `.copilot/cache/pr-review/`
- **Logs**: `.copilot/logs/pr-review/`
- **Reports**: `.copilot/reports/`

To clear cache:
```bash
rm -rf .copilot/cache/
```

## Example Usage

### Full PR Review

```
User: @pr-review Review this PR

You (provide when prompted):
Implement user authentication with:
- Login with email/password
- Logout functionality
- Session management (24h expiry)
- Password validation (min 8 chars)

Agent: [Performs review and shows findings]
```

### Check Specific Aspect

```
User: @code-quality Check test coverage

Agent: [Analyzes test coverage only]
```

```
User: @requirement-coverage Did I implement all Jira requirements?

Agent: [Compares Jira vs code]
```

## Configuration

### Environment Variables (Optional)

For Jira API integration (future):
```bash
JIRA_BASE_URL=https://your-domain.atlassian.net
JIRA_AUTH_TOKEN=your-api-token
JIRA_PROJECT_KEY=C1234
```

## Troubleshooting

### "Could not extract Jira ID from branch"
→ Ensure branch follows naming convention or provide ID manually

### "Empty git diff"
→ Ensure you have commits on your branch

### "Review taking too long"
→ Check diff size, consider reviewing smaller chunks

## Getting Help

- Ask: `@pr-review What can you do?`
- Documentation: See `.github/agents/*.agent.md` and `.github/skills/*/SKILL.md`
- Issues: Report problems in GitHub Issues

---

**Tip**: Always run `@pr-review` before creating a PR to catch issues early!
