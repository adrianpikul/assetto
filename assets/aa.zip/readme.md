`Lead → Auditor → Architect → Migrator → Reliability Reviewer`


Audit the current Cypress suite and prepare an incremental migration plan.

Start with repository-wide discovery, but pay particular attention to:
- Cypress configuration,
- custom commands and Node tasks,
- authentication and user roles,
- tenant or organization boundaries,
- test-data creation and cleanup,
- shared state between tests,
- duplicated scenarios,
- arbitrary waits,
- forced interactions,
- CI configuration and retries.

Do not edit code yet.

After the audit, design a prioritized migration backlog and select the first
small, deterministic migration slice that can establish the target Playwright
architecture.
